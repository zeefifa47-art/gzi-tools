/*
 * gzitouchd - penyetel sensitivitas sentuh (kode orisinal GZI TOOLS).
 * Dijalankan dengan hak shell (lewat Shizuku). Membaca touchscreen asli, mengambil alih (EVIOCGRAB),
 * lalu menulis ulang event ke touchscreen virtual (uinput) dengan delta gerak per jari dikali faktor X/Y.
 * Konfigurasi: /data/local/tmp/gzitouch.conf  ->  "<aktif 0/1> <faktorX*1000> <faktorY*1000>"
 * Aman: bila proses mati, kernel otomatis melepas grab dan menghapus device virtual. Bila file konfigurasi
 * tidak diperbarui > 15 detik (aplikasi mati), daemon melepas semuanya dan keluar.
 */
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <linux/uinput.h>

#define CONF "/data/local/tmp/gzitouch.conf"
#define LOGF "/data/local/tmp/gzitouchd.log"
#define MAXSLOT 20
#define OBUF 512
#define TB(b, a) ((a)[(b) / 8] & (1 << ((b) % 8)))

static volatile sig_atomic_t running = 1;
static int src = -1, dst = -1, nslots = 10;
static struct input_absinfo ainfo[2];
static int slot_cur = 0;
static int raw[MAXSLOT][2], out[MAXSLOT][2], rem[MAXSLOT][2], need[MAXSLOT][2], down[MAXSLOT];
static int fm[2] = {1000, 1000};
static struct input_event obuf[OBUF];
static int ocnt = 0;

static void say(const char *fmt, ...) {
    FILE *f = fopen(LOGF, "w");
    if (!f) return;
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a);
    fputc('\n', f); fclose(f);
}

static long now_ms(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000L + t.tv_nsec / 1000000L;
}

static void on_sig(int s) { (void)s; running = 0; }

static int any_down(void) { for (int i = 0; i < MAXSLOT; i++) if (down[i]) return 1; return 0; }

static int real_down(void) {
    int buf[1 + MAXSLOT];
    int n = nslots > MAXSLOT ? MAXSLOT : nslots;
    buf[0] = ABS_MT_TRACKING_ID;
    if (ioctl(src, EVIOCGMTSLOTS(sizeof(int) * (1 + n)), buf) < 0) return 0;
    for (int i = 0; i < n; i++) if (buf[1 + i] >= 0) return 1;
    return 0;
}

/* cari touchscreen: punya ABS_MT_POSITION_X/Y dan properti DIRECT */
static int find_touch(char *name_out) {
    DIR *d = opendir("/dev/input");
    if (!d) return -1;
    struct dirent *e;
    int found = -1;
    while (found < 0 && (e = readdir(d))) {
        if (strncmp(e->d_name, "event", 5)) continue;
        char p[64]; snprintf(p, sizeof p, "/dev/input/%s", e->d_name);
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        unsigned char ab[ABS_MAX / 8 + 1] = {0}, pr[INPUT_PROP_MAX / 8 + 1] = {0};
        char nm[80] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof ab), ab);
        ioctl(fd, EVIOCGPROP(sizeof pr), pr);
        ioctl(fd, EVIOCGNAME(sizeof nm - 1), nm);
        if (TB(ABS_MT_POSITION_X, ab) && TB(ABS_MT_POSITION_Y, ab) && TB(INPUT_PROP_DIRECT, pr) && strcmp(nm, "GZI Touch")) {
            snprintf(name_out, 80, "%s %s", p, nm);
            found = fd;
        } else close(fd);
    }
    closedir(d);
    return found;
}

static int make_uinput(void) {
    int u = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (u < 0) u = open("/dev/input/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (u < 0) { say("ERR uinput tidak bisa dibuka (errno %d)", errno); return -1; }
    unsigned char ev[EV_MAX / 8 + 1] = {0}, kb[KEY_MAX / 8 + 1] = {0}, ab[ABS_MAX / 8 + 1] = {0};
    ioctl(src, EVIOCGBIT(0, sizeof ev), ev);
    ioctl(src, EVIOCGBIT(EV_KEY, sizeof kb), kb);
    ioctl(src, EVIOCGBIT(EV_ABS, sizeof ab), ab);
    ioctl(u, UI_SET_EVBIT, EV_SYN);
    ioctl(u, UI_SET_EVBIT, EV_ABS);
    if (TB(EV_KEY, ev)) ioctl(u, UI_SET_EVBIT, EV_KEY);
    for (int c = 0; c < KEY_MAX; c++) if (TB(c, kb)) ioctl(u, UI_SET_KEYBIT, c);
    for (int a = 0; a < ABS_MAX; a++) if (TB(a, ab)) {
        struct uinput_abs_setup s; memset(&s, 0, sizeof s);
        s.code = a;
        ioctl(src, EVIOCGABS(a), &s.absinfo);
        ioctl(u, UI_SET_ABSBIT, a);
        ioctl(u, UI_ABS_SETUP, &s);
    }
    ioctl(u, UI_SET_PROPBIT, INPUT_PROP_DIRECT);
    struct uinput_setup us; memset(&us, 0, sizeof us);
    struct input_id id; memset(&id, 0, sizeof id);
    ioctl(src, EVIOCGID, &id);
    us.id = id; us.id.bustype = BUS_VIRTUAL;
    snprintf(us.name, sizeof us.name, "GZI Touch");
    if (ioctl(u, UI_DEV_SETUP, &us) < 0 || ioctl(u, UI_DEV_CREATE) < 0) {
        say("ERR gagal membuat touchscreen virtual (errno %d)", errno);
        close(u); return -1;
    }
    usleep(120000);
    return u;
}

static void flush_out(void) {
    if (ocnt > 0 && dst >= 0) { ssize_t r = write(dst, obuf, sizeof(obuf[0]) * ocnt); (void)r; }
    ocnt = 0;
}

static void emit(int type, int code, int value) {
    if (ocnt >= OBUF) flush_out();
    struct input_event *e = &obuf[ocnt++];
    memset(e, 0, sizeof *e);
    e->type = type; e->code = code; e->value = value;
}

static void stop_all(void) {
    if (dst >= 0) {
        /* lepas jari yang masih tertekan supaya tidak ada sentuhan "nyangkut" */
        for (int s = 0; s < MAXSLOT; s++) if (down[s]) {
            emit(EV_ABS, ABS_MT_SLOT, s); emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
        }
        if (ocnt) { emit(EV_SYN, SYN_REPORT, 0); flush_out(); }
        ioctl(dst, UI_DEV_DESTROY);
        close(dst); dst = -1;
    }
    if (src >= 0) { ioctl(src, EVIOCGRAB, 0); close(src); src = -1; }
    memset(down, 0, sizeof down);
    ocnt = 0;
}

/* return 0 ok, -1 gagal, -2 tunggu (masih ada jari di layar) */
static int start_all(void) {
    char nm[80];
    src = find_touch(nm);
    if (src < 0) { say("ERR touchscreen tidak ditemukan"); return -1; }
    if (ioctl(src, EVIOCGABS(ABS_MT_POSITION_X), &ainfo[0]) < 0 || ioctl(src, EVIOCGABS(ABS_MT_POSITION_Y), &ainfo[1]) < 0) {
        close(src); src = -1; return -1;
    }
    struct input_absinfo si;
    if (ioctl(src, EVIOCGABS(ABS_MT_SLOT), &si) == 0) nslots = si.maximum + 1;
    if (real_down()) { close(src); src = -1; return -2; }
    dst = make_uinput();
    if (dst < 0) { close(src); src = -1; return -1; }
    if (ioctl(src, EVIOCGRAB, 1) < 0) {
        say("ERR grab ditolak (errno %d)", errno);
        stop_all(); return -1;
    }
    for (int s = 0; s < MAXSLOT; s++) { need[s][0] = need[s][1] = 1; rem[s][0] = rem[s][1] = 0; down[s] = 0; }
    slot_cur = 0; ocnt = 0;
    say("READY %s", nm);
    return 0;
}

static int scale(int axis, int v) {
    int s = slot_cur;
    if (need[s][axis]) { need[s][axis] = 0; raw[s][axis] = v; out[s][axis] = v; rem[s][axis] = 0; return v; }
    int d = v - raw[s][axis];
    raw[s][axis] = v;
    long tot = (long)d * fm[axis] + rem[s][axis];
    long step = tot / 1000;
    rem[s][axis] = (int)(tot % 1000);
    long o = out[s][axis] + step;
    if (o < ainfo[axis].minimum) o = ainfo[axis].minimum;
    if (o > ainfo[axis].maximum) o = ainfo[axis].maximum;
    out[s][axis] = (int)o;
    return (int)o;
}

static void handle(void) {
    struct input_event ev[64];
    ssize_t n = read(src, ev, sizeof ev);
    if (n < 0) { if (errno == EAGAIN || errno == EINTR) return; stop_all(); return; }
    int cnt = (int)(n / sizeof ev[0]);
    for (int i = 0; i < cnt; i++) {
        struct input_event *e = &ev[i];
        if (e->type == EV_ABS) {
            switch (e->code) {
            case ABS_MT_SLOT: slot_cur = e->value < 0 ? 0 : (e->value >= MAXSLOT ? MAXSLOT - 1 : e->value); break;
            case ABS_MT_TRACKING_ID:
                if (e->value >= 0) { need[slot_cur][0] = need[slot_cur][1] = 1; down[slot_cur] = 1; }
                else down[slot_cur] = 0;
                break;
            case ABS_MT_POSITION_X: e->value = scale(0, e->value); break;
            case ABS_MT_POSITION_Y: e->value = scale(1, e->value); break;
            }
        } else if (e->type == EV_SYN && e->code == SYN_DROPPED) {
            for (int s = 0; s < MAXSLOT; s++) need[s][0] = need[s][1] = 1;
            ocnt = 0;
            continue;
        }
        emit(e->type, e->code, e->value);
        if (e->type == EV_SYN && e->code == SYN_REPORT) flush_out();
    }
}

static int read_conf(int *act, long *age) {
    struct stat st;
    if (stat(CONF, &st) < 0) return -1;
    *age = (long)(time(NULL) - st.st_mtime);
    FILE *f = fopen(CONF, "r");
    if (!f) return -1;
    int a = 0, x = 1000, y = 1000;
    if (fscanf(f, "%d %d %d", &a, &x, &y) == 3) {
        *act = a;
        if (x < 100) x = 100;
        if (x > 5000) x = 5000;
        if (y < 100) y = 100;
        if (y > 5000) y = 5000;
        fm[0] = x; fm[1] = y;
    }
    fclose(f);
    return 0;
}

int main(void) {
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, on_sig); signal(SIGINT, on_sig); signal(SIGHUP, on_sig);
    setpriority(PRIO_PROCESS, 0, -10);          /* bisa ditolak tanpa hak khusus; tidak masalah */
    struct sched_param sp; memset(&sp, 0, sizeof sp); sp.sched_priority = 1;
    sched_setscheduler(0, SCHED_FIFO, &sp);
    say("IDLE");
    int act = 0, was_idle_logged = 1;
    long last = 0;
    while (running) {
        long t = now_ms();
        if (t - last >= 100 || last == 0) {
            last = t;
            long age = 0;
            if (read_conf(&act, &age) < 0 || age > 15) break;
        }
        int want = act && !(fm[0] == 1000 && fm[1] == 1000);
        if (want && src < 0) {
            int r = start_all();
            if (r == -1) { usleep(1000000); continue; }
            if (r == -2) { usleep(60000); continue; }
            was_idle_logged = 0;
        } else if (!want && src >= 0) {
            if (any_down() && now_ms() - last < 1500) { /* tunggu jari diangkat */ }
            else { stop_all(); say("IDLE"); was_idle_logged = 1; }
        }
        if (src < 0) { usleep(150000); continue; }
        struct pollfd p = { src, POLLIN, 0 };
        int r = poll(&p, 1, 100);
        if (r > 0) {
            if (p.revents & (POLLERR | POLLHUP | POLLNVAL)) { stop_all(); continue; }
            if (p.revents & POLLIN) handle();
        }
    }
    stop_all();
    (void)was_idle_logged;
    say("EXIT");
    return 0;
}
