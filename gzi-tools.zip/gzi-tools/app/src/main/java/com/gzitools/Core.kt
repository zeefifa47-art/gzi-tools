package com.gzitools

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Base64
import rikka.shizuku.Shizuku

/** Konfigurasi tekstur per game. level 0..4 = Asli, Ringan, Retro, Kotak, Ekstrem */
data class TexCfg(
    val enabled: Boolean = false,
    val level: Int = 2,
    val sharp: Boolean = true,
    val hard: Boolean = true,
    val drv: Boolean = true
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gzi", Context.MODE_PRIVATE)

    var games: List<String>
        get() = (p.getString("games", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("games", v.joinToString(",")).apply() }

    var overlayOn: Boolean
        get() = p.getBoolean("ov", true)
        set(v) { p.edit().putBoolean("ov", v).apply() }
    var hy: Int
        get() = p.getInt("hy", -1)
        set(v) { p.edit().putInt("hy", v).apply() }
    var xhOn: Boolean
        get() = p.getBoolean("xh.on", false)
        set(v) { p.edit().putBoolean("xh.on", v).apply() }
    var xhStyle: Int
        get() = p.getInt("xh.st", 0)
        set(v) { p.edit().putInt("xh.st", v).apply() }
    var xhSize: Int
        get() = p.getInt("xh.sz", 60)
        set(v) { p.edit().putInt("xh.sz", v).apply() }
    var xhColor: Int
        get() = p.getInt("xh.co", 0)
        set(v) { p.edit().putInt("xh.co", v).apply() }

    var burikOn: Boolean
        get() = p.getBoolean("bk.on", false)
        set(v) { p.edit().putBoolean("bk.on", v).apply() }
    var burikLv: Int
        get() = p.getInt("bk.lv", 1)
        set(v) { p.edit().putInt("bk.lv", v).apply() }
    var sensiOn: Boolean
        get() = p.getBoolean("sn.on", false)
        set(v) { p.edit().putBoolean("sn.on", v).apply() }
    var sensiX: Int
        get() = p.getInt("sn.x", 5)
        set(v) { p.edit().putInt("sn.x", v).apply() }
    var sensiY: Int
        get() = p.getInt("sn.y", 5)
        set(v) { p.edit().putInt("sn.y", v).apply() }
    var resoPct: Int
        get() = p.getInt("rs.pct", 100)
        set(v) { p.edit().putInt("rs.pct", v).apply() }
    var resoBase: String
        get() = p.getString("rs.base", "") ?: ""
        set(v) { p.edit().putString("rs.base", v).apply() }
    var burikActive: Boolean
        get() = p.getBoolean("bk.act", false)
        set(v) { p.edit().putBoolean("bk.act", v).apply() }
    var focusOn: Boolean
        get() = p.getBoolean("fk.on", false)
        set(v) { p.edit().putBoolean("fk.on", v).apply() }
    var focusOrig: String
        get() = p.getString("fk.o", "") ?: ""
        set(v) { p.edit().putString("fk.o", v).apply() }
    var touchOn: Boolean
        get() = p.getBoolean("tc.on", false)
        set(v) { p.edit().putBoolean("tc.on", v).apply() }
    var touchX: Int
        get() = p.getInt("tc2.x", 0)
        set(v) { p.edit().putInt("tc2.x", v).apply() }
    var touchY: Int
        get() = p.getInt("tc2.y", 0)
        set(v) { p.edit().putInt("tc2.y", v).apply() }
    /** Fitur Spesial: Touch Optimize 15% — tambahan +15% di atas faktor Licin yang sedang dipakai. */
    var touchOptimizeOn: Boolean
        get() = p.getBoolean("to.on", false)
        set(v) { p.edit().putBoolean("to.on", v).apply() }
    var sensiOrig: String
        get() = p.getString("sn.o", "") ?: ""
        set(v) { p.edit().putString("sn.o", v).apply() }

    /** Makro: tap berulang di satu titik (daemon native gzimacrod, terpisah dari sensi). */
    var macroOn: Boolean
        get() = p.getBoolean("mk.on", false)
        set(v) { p.edit().putBoolean("mk.on", v).apply() }
    var macroX: Int
        get() = p.getInt("mk.x", -1)
        set(v) { p.edit().putInt("mk.x", v).apply() }
    var macroY: Int
        get() = p.getInt("mk.y", -1)
        set(v) { p.edit().putInt("mk.y", v).apply() }
    var macroMs: Int
        get() = p.getInt("mk.ms", 80)
        set(v) { p.edit().putInt("mk.ms", v.coerceIn(2, 2000)).apply() }

    /** Jendela Mengambang: daftar paket apk yang ditambahkan user (mis. TikTok), disimpan "pkg1,pkg2,...". */
    var floatApps: List<String>
        get() = (p.getString("fw.apps", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("fw.apps", v.distinct().joinToString(",")).apply() }
    var fwy: Int
        get() = p.getInt("fw.y", -1)
        set(v) { p.edit().putInt("fw.y", v).apply() }

    fun has(pkg: String) = p.contains("$pkg.lvl")

    fun cfg(pkg: String) = TexCfg(
        p.getBoolean("$pkg.en", false),
        p.getInt("$pkg.lvl", 2),
        p.getBoolean("$pkg.sh", true),
        p.getBoolean("$pkg.hd", true),
        p.getBoolean("$pkg.an", true)
    )

    fun save(pkg: String, c: TexCfg) {
        p.edit()
            .putBoolean("$pkg.en", c.enabled)
            .putInt("$pkg.lvl", c.level)
            .putBoolean("$pkg.sh", c.sharp)
            .putBoolean("$pkg.hd", c.hard)
            .putBoolean("$pkg.an", c.drv)
            .apply()
    }
}

/** Akses shell (uid 2000) lewat Shizuku. */
object Sz {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Throwable) { false }

    fun perms(ctx: Context): Boolean =
        Settings.System.canWrite(ctx) && Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = perms(ctx) && alive() && granted()

    /** Tulis byte ke file lewat shell (untuk memasang komponen native). Panggil dari thread background. */
    fun push(bytes: ByteArray, path: String): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "cat > '$path' && chmod 755 '$path' && echo PUSH_OK"), null, null) as Process
        p.outputStream.use { it.write(bytes) }
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.contains("PUSH_OK")
    } catch (e: Throwable) { false }

    /** Jalankan perintah shell lewat Shizuku. Panggil dari thread background. */
    fun sh(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERROR: " + (e.cause?.message ?: e.message)
    }
}

/** Mesin grafis. Hanya didukung Android 15+ (SDK 35). */
object Engine {
    val LEVELS = listOf("Normal", "Lembut", "8-Bit", "Blok", "Mozaik")
    val supported: Boolean get() = Build.VERSION.SDK_INT >= 35

    private fun d(s: String) = String(Base64.decode(s, Base64.NO_WRAP))
    private val K1 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl9wa2dz")
    private val K2 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl92YWx1ZXM=")
    private val K3 = d("YW5nbGU=")
    private val K4 = d("YW5nbGVfZWdsX2ZlYXR1cmVz")
    private val K5 = d("ZGVidWcuYW5nbGUuZmVhdHVyZV9vdmVycmlkZXNfZW5hYmxlZA==")
    private val F1 = d("Zm9yY2VOZWFyZXN0RmlsdGVyaW5n")
    private val F2 = d("Zm9yY2VOZWFyZXN0TWlwRmlsdGVyaW5n")
    private val F3 = d("Zm9yY2VUZXh0dXJlTG9kT2Zmc2V0")

    private fun features(c: TexCfg): String {
        val l = mutableListOf<String>()
        if (c.sharp) l += F1
        if (c.hard) l += F2
        if (c.level in 1..4) l += "$F3${c.level}"
        return l.joinToString(":")
    }

    private fun featureCmd(f: String): String =
        if (f.isEmpty()) "settings delete global $K4\nsetprop $K5 ''\n"
        else "settings put global $K4 '$f'\nsetprop $K5 '$f'\n"

    /** Terapkan konfigurasi. Panggil dari thread background. */
    fun apply(ctx: Context, pkg: String, c: TexCfg): String {
        if (!Guard.genuine(ctx)) return ""
        if (!supported) return ""
        val sb = StringBuilder()
        if (c.enabled) {
            val pk = (Store(ctx).games + pkg).distinct()
            sb.append("settings put global $K1 ${pk.joinToString(",")}\n")
            sb.append("settings put global $K2 ${pk.joinToString(",") { K3 }}\n")
            sb.append(featureCmd(features(c)))
        } else {
            sb.append(featureCmd(""))
        }
        return Sz.sh(sb.toString())
    }

    fun reset(): String = if (!supported) "" else Sz.sh(featureCmd(""))

    // ---------- Grafik Burik (Android 11+) ----------
    val BURIK = listOf("Asli", "Ringan", "Extrem")
    val BURIK_F = floatArrayOf(1f, 0.7f, 0.5f)
    val burikSupported: Boolean get() = Build.VERSION.SDK_INT >= 30

    /** HP mendukung downscale game (layanan game mode ada). Panggil dari thread background. */
    fun checkDownscale(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        val o = Sz.sh("cmd game help")
        if (o.startsWith("ERROR") || o.contains("find service", true)) return false
        return o.contains("mode", true)
    }
    private val BK = arrayOf("DOWNSCALE_90", "DOWNSCALE_80", "DOWNSCALE_70", "DOWNSCALE_60", "DOWNSCALE_50", "DOWNSCALE_40")

    /** FPS tertinggi yang didukung layar, dibulatkan ke nilai yang diterima sistem (30/45/60/90/120). */
    fun maxFps(ctx: Context): Int = try {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager).getDisplay(0)
        val m = d.supportedModes.maxOf { Math.round(it.refreshRate) }
        listOf(120, 90, 60, 45, 30).firstOrNull { it <= m + 1 } ?: 60
    } catch (e: Throwable) { 60 }

    private fun bad(o: String) = o.startsWith("ERROR") ||
        Regex("error|exception|unknown|usage|invalid|not found|denied|unsupported", RegexOption.IGNORE_CASE).containsMatchIn(o)

    /** Cara yang dipakai terakhir: "game" (downscale per-game) atau "layar" (ukuran layar). */
    @Volatile var burikMethod = ""
    private val DS = floatArrayOf(1f, 0.7f, 0.5f)

    /**
     * Downscale per-game, TANPA mengubah layar/DPI. Dua jalur dipasang sekaligus untuk faktor yang sama
     * (keduanya memakai perubahan kompatibilitas yang sama, jadi tidak menumpuk):
     *  - cmd game set --downscale X --fps Y <paket>   (Android 12+)
     *  - am compat enable DOWNSCALE_xx <paket>        (Android 11+)
     * level 0 = asli, 1 = ringan (0.7), 2 = extrem (0.5).
     */
    fun applyBurik(ctx: Context, pkg: String, level: Int): Boolean {
        if (!Guard.genuine(ctx)) return false
        if (!burikSupported) return false
        val st = Store(ctx)
        if (level !in 1..2) { resetBurik(ctx, listOf(pkg)); return true }
        // sisa cara lama (ubah layar) dikembalikan dulu
        if (st.burikActive) { restoreBase(ctx); st.burikActive = false }
        Sz.sh("cmd game reset $pkg\n" + BK.joinToString("\n") { "am compat reset $it $pkg" })

        val f = DS[level]
        val fps = maxFps(ctx)
        var o1 = Sz.sh("cmd game set --downscale $f --fps $fps $pkg")
        if (bad(o1)) o1 = Sz.sh("cmd game set --mode 2 --downscale $f --fps $fps $pkg")
        val gameOk = !bad(o1)
        val id = if (level == 1) "DOWNSCALE_70" else "DOWNSCALE_50"
        val compatOk = Sz.sh("am compat enable $id $pkg").contains("Enabled", true)
        if (gameOk || compatOk) burikMethod = "game"
        return gameOk || compatOk
    }

    fun resetBurik(ctx: Context, pkgs: List<String>) {
        if (!burikSupported) return
        val st = Store(ctx)
        // bersihkan sisa cara lama (kalau pernah terpasang)
        Sz.sh(pkgs.distinct().joinToString("\n") { p ->
            "cmd game reset $p\n" + BK.joinToString("\n") { "am compat reset $it $p" }
        })
        if (st.burikActive) { restoreBase(ctx); st.burikActive = false }
    }

    fun resetSensi(ctx: Context) {
        try {
            val st = Store(ctx)
            val o = st.sensiOrig.toIntOrNull() ?: return
            Settings.System.putInt(ctx.contentResolver, "pointer_speed", o)
            st.sensiOrig = ""
        } catch (e: Throwable) {}
    }

    // ---------- Resolusi layar (wm size) ----------
    private fun physSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(Sz.sh("wm size")) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    /** pct 50..99 = turunkan, 100 = asli. Mengembalikan teks resolusi bila berhasil, null bila gagal. */
    fun setReso(pct: Int): String? {
        if (pct >= 100) { resetReso(); return "Asli" }
        val (w, h) = physSize() ?: return null
        val nw = (w * pct / 100) / 2 * 2
        val nh = (h * pct / 100) / 2 * 2
        Sz.sh("wm size ${nw}x${nh}")
        return if (Sz.sh("wm size").contains("${nw}x${nh}")) "${nw}x${nh}" else null
    }

    fun resetReso() { Sz.sh("wm size reset\nwm density reset") }

    /** [lebar, tinggi, density] yang sedang aktif. */
    fun readDisplay(): List<String>? {
        val o = Sz.sh("wm size; wm density")
        val sz = Regex("Override size: (\\d+)x(\\d+)").find(o) ?: Regex("Physical size: (\\d+)x(\\d+)").find(o) ?: return null
        val dn = Regex("Override density: (\\d+)").find(o) ?: Regex("Physical density: (\\d+)").find(o)
        return listOf(sz.groupValues[1], sz.groupValues[2], dn?.groupValues?.get(1) ?: "")
    }

    /** Kembali ke keadaan sebelum aplikasi mengubah resolusi (mis. DPI yang kamu atur sendiri). Null bila tidak ada / gagal. */
    fun restoreBase(ctx: Context): String? {
        val st = Store(ctx)
        val b = st.resoBase.split(",")
        if (b.size < 3 || b[0].isEmpty()) return null
        val good = restoreDisplay(b[0].toInt(), b[1].toInt(), b[2].toIntOrNull() ?: 0)
        if (good) st.resoBase = ""
        return if (good) "${b[0]}x${b[1]}" + (if (b[2].isNotEmpty()) " · ${b[2]} dpi" else "") else null
    }

    /** Pulihkan nilai W x H dan density persis seperti sebelumnya. */
    fun restoreDisplay(w: Int, h: Int, d: Int): Boolean {
        Sz.sh("wm size ${w}x${h}" + if (d > 0) "\nwm density $d" else "")
        val o = Sz.sh("wm size; wm density")
        return o.contains("${w}x${h}") && (d <= 0 || o.contains("density: $d"))
    }

    /** Atur resolusi W x H dan density (d = 0: density tidak diubah). Pair(berhasil, pesan). */
    fun setCustom(w0: Int, h0: Int, d: Int): Pair<Boolean, String> {
        val (pw, ph) = physSize() ?: return false to "Gagal membaca layar. Pastikan Shizuku aktif."
        var w = w0; var h = h0
        if ((pw < ph) != (w < h)) { val t = w; w = h; h = t }
        if (w < 240 || h < 240) return false to "Resolusi terlalu kecil (minimal 240)"
        if (w > pw || h > ph) return false to "Maksimal ${pw}x${ph} (resolusi asli HP)"
        if (d != 0 && (d < 120 || d > 900)) return false to "Density harus 120 sampai 900"
        Sz.sh("wm size ${w}x${h}")
        if (d > 0) Sz.sh("wm density $d")
        val o = Sz.sh("wm size; wm density")
        val good = o.contains("${w}x${h}") && (d <= 0 || o.contains("density: $d"))
        return if (good) true to ("${w}x${h}" + (if (d > 0) " · $d dpi" else "")) else false to "Ditolak sistem"
    }

    // ---------- Mode Fokus (Jangan Ganggu + tanpa pop-up) ----------
    fun focus(ctx: Context, on: Boolean): Boolean {
        if (!Guard.genuine(ctx)) return false
        val st = Store(ctx)
        if (!on) return restoreFocus(ctx)
        if (st.focusOrig.isEmpty()) {
            val z = Sz.sh("settings get global zen_mode").trim().toIntOrNull() ?: 0
            val h = Sz.sh("settings get global heads_up_notifications_enabled").trim().toIntOrNull() ?: 1
            st.focusOrig = "$z,$h"
        }
        Sz.sh("settings put global zen_mode 1\nsettings put global heads_up_notifications_enabled 0")
        val good = Sz.sh("settings get global zen_mode").trim() == "1"
        if (good) st.focusOn = true
        return good
    }

    fun restoreFocus(ctx: Context): Boolean {
        val st = Store(ctx)
        if (st.focusOrig.isEmpty()) { st.focusOn = false; return true }
        val p = st.focusOrig.split(",")
        Sz.sh("settings put global zen_mode ${p[0]}\nsettings put global heads_up_notifications_enabled ${p.getOrElse(1) { "1" }}")
        st.focusOrig = ""; st.focusOn = false
        return true
    }

    // ---------- Sensitivitas Sentuh (daemon native gzitouchd) ----------
    private const val TD = "/data/local/tmp/gzitouchd"
    private const val TC = "/data/local/tmp/gzitouch.conf"
    private const val TL = "/data/local/tmp/gzitouchd.log"

    fun touchAvailable(ctx: Context): Boolean = try { ctx.assets.open("gzitouchd").close(); true } catch (e: Throwable) { false }

    /** Skala 0..10 -> faktor: 0 = 1.0x (normal), 10 = 3.0x (dalam seperseribu). boost = Touch Optimize 15% nyala. */
    fun touchMilli(v: Int, boost: Boolean = false): Int {
        val m = 1000 + v.coerceIn(0, 10) * 200
        return if (boost) (m * 1.15).toInt().coerceAtMost(5000) else m
    }

    /** Perbarui konfigurasi (sekaligus tanda hidup). active = grab hanya saat game di depan. */
    fun touchConf(active: Boolean, x: Int, y: Int, boost: Boolean = false) {
        Sz.sh("echo '${if (active) 1 else 0} ${touchMilli(x, boost)} ${touchMilli(y, boost)}' > $TC")
    }

    /** Pasang dan jalankan daemon. Mengembalikan "" bila sukses, selain itu pesan kesalahan. */
    fun touchStart(ctx: Context, x: Int, y: Int, active: Boolean, boost: Boolean = false): String {
        if (!Guard.genuine(ctx)) return "Build tidak resmi"
        if (!touchAvailable(ctx)) return "Komponen sentuh tidak ikut terbangun di build ini"
        Sz.sh("pkill gzitouchd || killall gzitouchd")
        val bytes = try { ctx.assets.open("gzitouchd").use { it.readBytes() } } catch (e: Throwable) { return "Gagal membaca komponen sentuh" }
        if (!Sz.push(bytes, TD)) return "Gagal memasang komponen sentuh (Shizuku aktif?)"
        Sz.sh("echo '${if (active) 1 else 0} ${touchMilli(x, boost)} ${touchMilli(y, boost)}' > $TC\nrm -f $TL\n(setsid nohup $TD </dev/null >/dev/null 2>&1 &)")
        if (!active) return ""
        // Licin masih di 0 (netral) = daemon-nya SENGAJA diam, gak ada yang perlu di-grab sampai
        // slidernya digeser. Ini bukan kegagalan — dulu kode ini nunggu "READY" yang gak akan pernah
        // muncul selama masih netral, jadi switch-nya ketendang balik OFF padahal daemon-nya sehat.
        if (touchMilli(x, boost) == 1000 && touchMilli(y, boost) == 1000) return ""
        repeat(12) {
            try { Thread.sleep(300) } catch (e: InterruptedException) {}
            val l = Sz.sh("cat $TL")
            if (l.startsWith("READY")) return ""
            if (l.startsWith("ERR")) return l.removePrefix("ERR").trim()
        }
        return "Belum aktif. Coba lagi saat game sedang dibuka."
    }

    fun touchStop() {
        Sz.sh("echo '0 1000 1000' > $TC\nsleep 0.3\npkill gzitouchd || killall gzitouchd\nrm -f $TC")
    }

    // ---------- Makro: tap berulang di satu titik (daemon native gzimacrod) ----------
    // Beda dari gzitouchd: ini TIDAK nge-grab touchscreen asli, jadi jari pengguna tetap bisa
    // dipakai normal berbarengan. Ketukannya disuntik langsung lewat uinput (bukan spawn proses
    // `input tap` tiap ketuk) supaya interval kecil (dalam milidetik) bisa benar-benar dikejar,
    // dijadwalkan pakai CLOCK_MONOTONIC di sisi native (lihat native/gzimacrod.c).
    private const val MD = "/data/local/tmp/gzimacrod"
    private const val MC = "/data/local/tmp/gzimacro.conf"
    private const val ML = "/data/local/tmp/gzimacrod.log"

    fun macroAvailable(ctx: Context): Boolean = try { ctx.assets.open("gzimacrod").close(); true } catch (e: Throwable) { false }

    /** Perbarui target & kecepatan (sekaligus tanda hidup). active = tap jalan hanya saat game di depan & panel ketutup. */
    fun macroConf(active: Boolean, x: Int, y: Int, intervalMs: Int) {
        Sz.sh("echo '${if (active) 1 else 0} $x $y ${intervalMs.coerceIn(2, 2000)}' > $MC")
    }

    /** Pasang dan jalankan daemon makro. Mengembalikan "" bila sukses, selain itu pesan kesalahan. */
    fun macroStart(ctx: Context, x: Int, y: Int, intervalMs: Int): String {
        if (!Guard.genuine(ctx)) return "Build tidak resmi"
        if (!macroAvailable(ctx)) return "Komponen makro tidak ikut terbangun di build ini"
        Sz.sh("pkill gzimacrod || killall gzimacrod")
        val bytes = try { ctx.assets.open("gzimacrod").use { it.readBytes() } } catch (e: Throwable) { return "Gagal membaca komponen makro" }
        if (!Sz.push(bytes, MD)) return "Gagal memasang komponen makro (Shizuku aktif?)"
        Sz.sh("echo '1 $x $y ${intervalMs.coerceIn(2, 2000)}' > $MC\nrm -f $ML\n(setsid nohup $MD </dev/null >/dev/null 2>&1 &)")
        repeat(10) {
            try { Thread.sleep(200) } catch (e: InterruptedException) {}
            val l = Sz.sh("cat $ML")
            if (l.startsWith("READY")) return ""
            if (l.startsWith("ERR")) return l.removePrefix("ERR").trim()
        }
        return ""
    }

    fun macroStop() {
        Sz.sh("echo '0 0 0 1000' > $MC\nsleep 0.2\npkill gzimacrod || killall gzimacrod\nrm -f $MC")
    }

    /** Kembalikan semua ke asli (dipanggil saat > 5 menit di luar game). */
    fun revertAll(ctx: Context, pkg: String) {
        reset()
        resetBurik(ctx, Store(ctx).games + pkg)
        restoreBase(ctx)
        restoreFocus(ctx)
        touchStop()
        Store(ctx).touchOn = false
        Store(ctx).resoPct = 100
    }

    fun forceStop(pkg: String) = Sz.sh("am force-stop $pkg")
}
