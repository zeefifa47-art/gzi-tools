/*
 * gzimacrod - ketuk berulang di satu titik (fitur MAKRO, kode orisinal GZI TOOLS).
 * Beda dari gzitouchd: daemon ini TIDAK meng-grab touchscreen asli (EVIOCGRAB) — jadi sentuhan
 * jari pengguna tetap jalan normal, bersamaan dengan ketukan palsu yang disuntik lewat touchscreen
 * virtual (/dev/uinput). Dipakai lewat shell (Shizuku).
 * Konfigurasi: /data/local/tmp/gzimacro.conf  ->  "<aktif 0/1> <x> <y> <interval_ms>"
 * Timing pakai CLOCK_MONOTONIC + penjadwalan "target waktu berikutnya" (bukan cuma sleep(interval)
 * sesudah tiap ketukan) supaya rata-rata interval tetap akurat walau ada jitter kecil, dan TANPA
 * nge-spawn proses baru tiap ketuk (beda dari dulu yang lewat command `input tap` berulang — itu
 * yang jadi plafon ~puluhan ms karena biaya bikin proses baru tiap panggilan).
 * Catatan jujur: ini nyuntik event di level kernel secepat yang diminta, tapi kalau game-nya cuma
 * baca input sekali per frame (mis. ~16ms di 60fps), ketukan yang lebih rapat dari itu bisa aja
 * "ketelan" jadi satu tindakan oleh game-nya — itu batas di sisi game, bukan di daemon ini.
 * Aman: kalau proses mati, kernel otomatis hapus device virtual. Kalau file konfigurasi tidak
 * diperbarui > 15 detik (aplikasi mati), daemon keluar sendiri.
 */
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sched.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <linux/uinput.h>

#define CONF "/data/local/tmp/gzimacro.conf"
#define LOGF "/data/local/tmp/gzimacrod.log"
#define TB(b, a) ((a)[(b) / 8] & (1 << ((b) % 8)))

static volatile sig_atomic_t running = 1;
static int dst = -1;
static int xmin = 0, xmax = 0, ymin = 0, ymax = 0;
static int next_tid = 9000;
static struct input_event obuf[16];
static int ocnt = 0;

static void say(const char *fmt, ...) {
    FILE *f = fopen(LOGF, "w");
    if (!f) return;
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a);
    fputc('\n', f); fclose(f);
}

static long now_ms(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000L + t.tv_nsec / 1000000L;
}

static void on_sig(int s) { (void)s; running = 0; }

/* cari touchscreen asli cuma buat nyontek rentang koordinat mentahnya (biar target x/y presisi) */
static int find_touch_range(void) {
    DIR *d = opendir("/dev/input");
    if (!d) return -1;
    struct dirent *e;
    int ok = -1;
    while (ok < 0 && (e = readdir(d))) {
        if (strncmp(e->d_name, "event", 5)) continue;
        char p[64]; snprintf(p, sizeof p, "/dev/input/%s", e->d_name);
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        unsigned char ab[ABS_MAX / 8 + 1] = {0}, pr[INPUT_PROP_MAX / 8 + 1] = {0};
        char nm[80] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof ab), ab);
        ioctl(fd, EVIOCGPROP(sizeof pr), pr);
        ioctl(fd, EVIOCGNAME(sizeof nm - 1), nm);
        if (TB(ABS_MT_POSITION_X, ab) && TB(ABS_MT_POSITION_Y, ab) && TB(INPUT_PROP_DIRECT, pr) && strcmp(nm, "GZI Touch") && strcmp(nm, "GZI Macro")) {
            struct input_absinfo ax, ay;
            if (ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &ax) == 0 && ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay) == 0) {
                xmin = ax.minimum; xmax = ax.maximum; ymin = ay.minimum; ymax = ay.maximum;
                ok = 0;
            }
        }
        close(fd);
    }
    closedir(d);
    return ok;
}

static int make_uinput(void) {
    int u = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (u < 0) u = open("/dev/input/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (u < 0) { say("ERR uinput tidak bisa dibuka (errno %d)", errno); return -1; }
    ioctl(u, UI_SET_EVBIT, EV_SYN);
    ioctl(u, UI_SET_EVBIT, EV_ABS);
    ioctl(u, UI_SET_ABSBIT, ABS_MT_SLOT);
    ioctl(u, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    ioctl(u, UI_SET_ABSBIT, ABS_MT_POSITION_X);
    ioctl(u, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    ioctl(u, UI_SET_PROPBIT, INPUT_PROP_DIRECT);
    struct uinput_abs_setup s;
    memset(&s, 0, sizeof s); s.code = ABS_MT_SLOT; s.absinfo.minimum = 0; s.absinfo.maximum = 9; ioctl(u, UI_ABS_SETUP, &s);
    memset(&s, 0, sizeof s); s.code = ABS_MT_TRACKING_ID; s.absinfo.minimum = 0; s.absinfo.maximum = 65535; ioctl(u, UI_ABS_SETUP, &s);
    memset(&s, 0, sizeof s); s.code = ABS_MT_POSITION_X; s.absinfo.minimum = xmin; s.absinfo.maximum = xmax; ioctl(u, UI_ABS_SETUP, &s);
    memset(&s, 0, sizeof s); s.code = ABS_MT_POSITION_Y; s.absinfo.minimum = ymin; s.absinfo.maximum = ymax; ioctl(u, UI_ABS_SETUP, &s);
    struct uinput_setup us; memset(&us, 0, sizeof us);
    us.id.bustype = BUS_VIRTUAL; us.id.vendor = 0x1; us.id.product = 0x1; us.id.version = 1;
    snprintf(us.name, sizeof us.name, "GZI Macro");
    if (ioctl(u, UI_DEV_SETUP, &us) < 0 || ioctl(u, UI_DEV_CREATE) < 0) {
        say("ERR gagal membuat touchscreen virtual (errno %d)", errno);
        close(u); return -1;
    }
    usleep(120000);
    return u;
}

static void emit(int type, int code, int value) {
    struct input_event *e = &obuf[ocnt++];
    memset(e, 0, sizeof *e);
    e->type = type; e->code = code; e->value = value;
    if (ocnt >= 16) { write(dst, obuf, sizeof(obuf[0]) * ocnt); ocnt = 0; }
}

static void flush_out(void) {
    if (ocnt > 0 && dst >= 0) write(dst, obuf, sizeof(obuf[0]) * ocnt);
    ocnt = 0;
}

static void do_tap(int x, int y) {
    int tid = next_tid++;
    if (x < xmin) x = xmin; if (x > xmax) x = xmax;
    if (y < ymin) y = ymin; if (y > ymax) y = ymax;
    emit(EV_ABS, ABS_MT_SLOT, 0);
    emit(EV_ABS, ABS_MT_TRACKING_ID, tid);
    emit(EV_ABS, ABS_MT_POSITION_X, x);
    emit(EV_ABS, ABS_MT_POSITION_Y, y);
    emit(EV_SYN, SYN_REPORT, 0);
    flush_out();
    emit(EV_ABS, ABS_MT_SLOT, 0);
    emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
    emit(EV_SYN, SYN_REPORT, 0);
    flush_out();
}

static void stop_all(void) {
    if (dst >= 0) { ioctl(dst, UI_DEV_DESTROY); close(dst); dst = -1; }
}

static int read_conf(int *act, int *x, int *y, int *ms, long *age) {
    struct stat st;
    if (stat(CONF, &st) < 0) return -1;
    *age = (long)(time(NULL) - st.st_mtime);
    FILE *f = fopen(CONF, "r");
    if (!f) return -1;
    int a = 0, px = 0, py = 0, iv = 1000;
    if (fscanf(f, "%d %d %d %d", &a, &px, &py, &iv) == 4) {
        *act = a; *x = px; *y = py;
        if (iv < 2) iv = 2;
        if (iv > 5000) iv = 5000;
        *ms = iv;
    }
    fclose(f);
    return 0;
}

int main(void) {
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, on_sig); signal(SIGINT, on_sig); signal(SIGHUP, on_sig);
    setpriority(PRIO_PROCESS, 0, -10);
    struct sched_param sp; memset(&sp, 0, sizeof sp); sp.sched_priority = 1;
    sched_setscheduler(0, SCHED_FIFO, &sp);

    if (find_touch_range() < 0) { xmin = 0; xmax = 4096; ymin = 0; ymax = 4096; }

    int act = 0, x = 0, y = 0, ms = 1000;
    long next_tap = 0;
    int was_active = 0;
    long last_conf = 0;
    say("READY");
    while (running) {
        long t = now_ms();
        if (t - last_conf >= 50 || last_conf == 0) {
            last_conf = t;
            long age = 0;
            if (read_conf(&act, &x, &y, &ms, &age) < 0 || age > 15) break;
        }
        if (act && dst < 0) {
            dst = make_uinput();
            if (dst < 0) { usleep(1000000); continue; }
            next_tap = now_ms();
            was_active = 1;
        } else if (!act && dst >= 0) {
            stop_all(); was_active = 0;
        }
        if (dst < 0) { usleep(30000); continue; }
        long tm = now_ms();
        if (tm >= next_tap) {
            do_tap(x, y);
            next_tap += ms;
            if (next_tap < tm) next_tap = tm + ms;
        }
        long wait_ms = next_tap - now_ms();
        if (wait_ms > 20) wait_ms = 20; /* biar tetap sering ngecek file konfigurasi */
        if (wait_ms > 0) usleep((useconds_t)(wait_ms * 1000));
    }
    stop_all();
    (void)was_active;
    say("EXIT");
    return 0;
}
