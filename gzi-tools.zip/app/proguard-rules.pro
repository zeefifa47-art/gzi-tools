# GZI TOOLS - aturan R8/ProGuard
# Shizuku dipanggil lewat refleksi (Sz.sh -> newProcess) dan AIDL, jangan diubah/dibuang.
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keepclassmembers class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**

# Komponen aplikasi sendiri tetap boleh diacak namanya (R8 default sudah menjaga yang dideklarasikan
# di manifest). Guard.kt sengaja TIDAK di-keep supaya ikut diacak dan lebih sulit ditemukan.

-keepattributes *Annotation*
-keepattributes Signature
