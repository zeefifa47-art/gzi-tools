package com.gzitools

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Base64
import rikka.shizuku.Shizuku

/** Konfigurasi tekstur per game. level 0..4 = Asli, Ringan, Retro, Kotak, Ekstrem */
data class TexCfg(
    val enabled: Boolean = false,
    val level: Int = 2,
    val sharp: Boolean = true,
    val hard: Boolean = true,
    val drv: Boolean = true
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gzi", Context.MODE_PRIVATE)

    var games: List<String>
        get() = (p.getString("games", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("games", v.joinToString(",")).apply() }

    var overlayOn: Boolean
        get() = p.getBoolean("ov", true)
        set(v) { p.edit().putBoolean("ov", v).apply() }
    var hy: Int
        get() = p.getInt("hy", -1)
        set(v) { p.edit().putInt("hy", v).apply() }
    var xhOn: Boolean
        get() = p.getBoolean("xh.on", false)
        set(v) { p.edit().putBoolean("xh.on", v).apply() }
    var xhStyle: Int
        get() = p.getInt("xh.st", 0)
        set(v) { p.edit().putInt("xh.st", v).apply() }
    var xhSize: Int
        get() = p.getInt("xh.sz", 60)
        set(v) { p.edit().putInt("xh.sz", v).apply() }
    var xhColor: Int
        get() = p.getInt("xh.co", 0)
        set(v) { p.edit().putInt("xh.co", v).apply() }

    fun has(pkg: String) = p.contains("$pkg.lvl")

    fun cfg(pkg: String) = TexCfg(
        p.getBoolean("$pkg.en", false),
        p.getInt("$pkg.lvl", 2),
        p.getBoolean("$pkg.sh", true),
        p.getBoolean("$pkg.hd", true),
        p.getBoolean("$pkg.an", true)
    )

    fun save(pkg: String, c: TexCfg) {
        p.edit()
            .putBoolean("$pkg.en", c.enabled)
            .putInt("$pkg.lvl", c.level)
            .putBoolean("$pkg.sh", c.sharp)
            .putBoolean("$pkg.hd", c.hard)
            .putBoolean("$pkg.an", c.drv)
            .apply()
    }
}

/** Akses shell (uid 2000) lewat Shizuku. */
object Sz {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Throwable) { false }

    fun perms(ctx: Context): Boolean =
        Settings.System.canWrite(ctx) && Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = perms(ctx) && alive() && granted()

    /** Jalankan perintah shell lewat Shizuku. Panggil dari thread background. */
    fun sh(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERROR: " + (e.cause?.message ?: e.message)
    }
}

/** Mesin grafis. Hanya didukung Android 15+ (SDK 35). */
object Engine {
    val LEVELS = listOf("Asli", "Ringan", "Retro", "Kotak", "Ekstrem")
    val supported: Boolean get() = Build.VERSION.SDK_INT >= 35

    private fun d(s: String) = String(Base64.decode(s, Base64.NO_WRAP))
    private val K1 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl9wa2dz")
    private val K2 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl92YWx1ZXM=")
    private val K3 = d("YW5nbGU=")
    private val K4 = d("YW5nbGVfZWdsX2ZlYXR1cmVz")
    private val K5 = d("ZGVidWcuYW5nbGUuZmVhdHVyZV9vdmVycmlkZXNfZW5hYmxlZA==")
    private val F1 = d("Zm9yY2VOZWFyZXN0RmlsdGVyaW5n")
    private val F2 = d("Zm9yY2VOZWFyZXN0TWlwRmlsdGVyaW5n")
    private val F3 = d("Zm9yY2VUZXh0dXJlTG9kT2Zmc2V0")

    private fun features(c: TexCfg): String {
        val l = mutableListOf<String>()
        if (c.sharp) l += F1
        if (c.hard) l += F2
        if (c.level in 1..4) l += "$F3${c.level}"
        return l.joinToString(":")
    }

    private fun featureCmd(f: String): String =
        if (f.isEmpty()) "settings delete global $K4\nsetprop $K5 ''\n"
        else "settings put global $K4 '$f'\nsetprop $K5 '$f'\n"

    /** Terapkan konfigurasi. Panggil dari thread background. */
    fun apply(ctx: Context, pkg: String, c: TexCfg): String {
        if (!supported) return ""
        val sb = StringBuilder()
        if (c.enabled) {
            val pk = (Store(ctx).games + pkg).distinct()
            sb.append("settings put global $K1 ${pk.joinToString(",")}\n")
            sb.append("settings put global $K2 ${pk.joinToString(",") { K3 }}\n")
            sb.append(featureCmd(features(c)))
        } else {
            sb.append(featureCmd(""))
        }
        return Sz.sh(sb.toString())
    }

    fun reset(): String = if (!supported) "" else Sz.sh(featureCmd(""))

    fun forceStop(pkg: String) = Sz.sh("am force-stop $pkg")
}
