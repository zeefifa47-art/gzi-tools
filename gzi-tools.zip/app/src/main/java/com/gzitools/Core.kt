package com.gzitools

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Base64
import rikka.shizuku.Shizuku

/** Konfigurasi tekstur per game. level 0..4 = Asli, Ringan, Retro, Kotak, Ekstrem */
data class TexCfg(
    val enabled: Boolean = false,
    val level: Int = 2,
    val sharp: Boolean = true,
    val hard: Boolean = true,
    val drv: Boolean = true
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gzi", Context.MODE_PRIVATE)

    var games: List<String>
        get() = (p.getString("games", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("games", v.joinToString(",")).apply() }

    var overlayOn: Boolean
        get() = p.getBoolean("ov", true)
        set(v) { p.edit().putBoolean("ov", v).apply() }
    var hy: Int
        get() = p.getInt("hy", -1)
        set(v) { p.edit().putInt("hy", v).apply() }
    var xhOn: Boolean
        get() = p.getBoolean("xh.on", false)
        set(v) { p.edit().putBoolean("xh.on", v).apply() }
    var xhStyle: Int
        get() = p.getInt("xh.st", 0)
        set(v) { p.edit().putInt("xh.st", v).apply() }
    var xhSize: Int
        get() = p.getInt("xh.sz", 60)
        set(v) { p.edit().putInt("xh.sz", v).apply() }
    var xhColor: Int
        get() = p.getInt("xh.co", 0)
        set(v) { p.edit().putInt("xh.co", v).apply() }

    var burikOn: Boolean
        get() = p.getBoolean("bk.on", false)
        set(v) { p.edit().putBoolean("bk.on", v).apply() }
    var burikLv: Int
        get() = p.getInt("bk.lv", 1)
        set(v) { p.edit().putInt("bk.lv", v).apply() }
    var sensiOn: Boolean
        get() = p.getBoolean("sn.on", false)
        set(v) { p.edit().putBoolean("sn.on", v).apply() }
    var sensiX: Int
        get() = p.getInt("sn.x", 5)
        set(v) { p.edit().putInt("sn.x", v).apply() }
    var sensiY: Int
        get() = p.getInt("sn.y", 5)
        set(v) { p.edit().putInt("sn.y", v).apply() }
    var resoPct: Int
        get() = p.getInt("rs.pct", 100)
        set(v) { p.edit().putInt("rs.pct", v).apply() }
    var resoBase: String
        get() = p.getString("rs.base", "") ?: ""
        set(v) { p.edit().putString("rs.base", v).apply() }
    var burikActive: Boolean
        get() = p.getBoolean("bk.act", false)
        set(v) { p.edit().putBoolean("bk.act", v).apply() }
    var sensiOrig: String
        get() = p.getString("sn.o", "") ?: ""
        set(v) { p.edit().putString("sn.o", v).apply() }

    fun has(pkg: String) = p.contains("$pkg.lvl")

    fun cfg(pkg: String) = TexCfg(
        p.getBoolean("$pkg.en", false),
        p.getInt("$pkg.lvl", 2),
        p.getBoolean("$pkg.sh", true),
        p.getBoolean("$pkg.hd", true),
        p.getBoolean("$pkg.an", true)
    )

    fun save(pkg: String, c: TexCfg) {
        p.edit()
            .putBoolean("$pkg.en", c.enabled)
            .putInt("$pkg.lvl", c.level)
            .putBoolean("$pkg.sh", c.sharp)
            .putBoolean("$pkg.hd", c.hard)
            .putBoolean("$pkg.an", c.drv)
            .apply()
    }
}

/** Akses shell (uid 2000) lewat Shizuku. */
object Sz {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Throwable) { false }

    fun perms(ctx: Context): Boolean =
        Settings.System.canWrite(ctx) && Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = perms(ctx) && alive() && granted()

    /** Jalankan perintah shell lewat Shizuku. Panggil dari thread background. */
    fun sh(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERROR: " + (e.cause?.message ?: e.message)
    }
}

/** Mesin grafis. Hanya didukung Android 15+ (SDK 35). */
object Engine {
    val LEVELS = listOf("Normal", "Lembut", "8-Bit", "Blok", "Mozaik")
    val supported: Boolean get() = Build.VERSION.SDK_INT >= 35

    private fun d(s: String) = String(Base64.decode(s, Base64.NO_WRAP))
    private val K1 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl9wa2dz")
    private val K2 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl92YWx1ZXM=")
    private val K3 = d("YW5nbGU=")
    private val K4 = d("YW5nbGVfZWdsX2ZlYXR1cmVz")
    private val K5 = d("ZGVidWcuYW5nbGUuZmVhdHVyZV9vdmVycmlkZXNfZW5hYmxlZA==")
    private val F1 = d("Zm9yY2VOZWFyZXN0RmlsdGVyaW5n")
    private val F2 = d("Zm9yY2VOZWFyZXN0TWlwRmlsdGVyaW5n")
    private val F3 = d("Zm9yY2VUZXh0dXJlTG9kT2Zmc2V0")

    private fun features(c: TexCfg): String {
        val l = mutableListOf<String>()
        if (c.sharp) l += F1
        if (c.hard) l += F2
        if (c.level in 1..4) l += "$F3${c.level}"
        return l.joinToString(":")
    }

    private fun featureCmd(f: String): String =
        if (f.isEmpty()) "settings delete global $K4\nsetprop $K5 ''\n"
        else "settings put global $K4 '$f'\nsetprop $K5 '$f'\n"

    /** Terapkan konfigurasi. Panggil dari thread background. */
    fun apply(ctx: Context, pkg: String, c: TexCfg): String {
        if (!supported) return ""
        val sb = StringBuilder()
        if (c.enabled) {
            val pk = (Store(ctx).games + pkg).distinct()
            sb.append("settings put global $K1 ${pk.joinToString(",")}\n")
            sb.append("settings put global $K2 ${pk.joinToString(",") { K3 }}\n")
            sb.append(featureCmd(features(c)))
        } else {
            sb.append(featureCmd(""))
        }
        return Sz.sh(sb.toString())
    }

    fun reset(): String = if (!supported) "" else Sz.sh(featureCmd(""))

    // ---------- Grafik Burik (Android 11+) ----------
    val BURIK = listOf("Asli", "Ringan", "Extrem")
    val BURIK_F = floatArrayOf(1f, 0.7f, 0.5f)
    val burikSupported: Boolean get() = Build.VERSION.SDK_INT >= 30
    private val BK = arrayOf("DOWNSCALE_80", "DOWNSCALE_60", "DOWNSCALE_50", "DOWNSCALE_40")

    /** FPS tertinggi yang didukung layar, dibulatkan ke nilai yang diterima sistem (30/45/60/90/120). */
    fun maxFps(ctx: Context): Int = try {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager).getDisplay(0)
        val m = d.supportedModes.maxOf { Math.round(it.refreshRate) }
        listOf(120, 90, 60, 45, 30).firstOrNull { it <= m + 1 } ?: 60
    } catch (e: Throwable) { 60 }

    private fun bad(o: String) = o.startsWith("ERROR") ||
        Regex("error|exception|unknown|usage|invalid|not found|denied|unsupported", RegexOption.IGNORE_CASE).containsMatchIn(o)

    /** Cara yang dipakai terakhir: "game" (downscale per-game) atau "layar" (ukuran layar). */
    @Volatile var burikMethod = ""
    private val DS = floatArrayOf(1f, 0.7f, 0.5f)

    /**
     * Cara 1: downscale per-game (cmd game) bila HP menerima perintahnya.
     * Cara 2 (otomatis bila cara 1 tidak didukung): turunkan ukuran layar (wm size).
     * level 0 = asli, 1 = ringan, 2 = extrem.
     */
    fun applyBurik(ctx: Context, pkg: String, level: Int): Boolean {
        if (!burikSupported) return false
        val st = Store(ctx)
        if (level !in 1..2) { resetBurik(ctx, listOf(pkg)); return true }

        // bersihkan sisa downscale game lama supaya tidak menumpuk
        Sz.sh("cmd game reset $pkg")

        // satu cara untuk semua Android 11+: turunkan ukuran layar (pasti terlihat)
        val (pw, ph) = physSize() ?: return false
        if (st.resoBase.isEmpty()) readDisplay()?.let { st.resoBase = it.joinToString(",") }
        val k = BURIK_F[level]
        val nw = (pw * k).toInt() / 2 * 2
        val nh = (ph * k).toInt() / 2 * 2
        Sz.sh("wm size ${nw}x${nh}")
        val good = Sz.sh("wm size").contains("${nw}x${nh}")
        if (good) { st.burikActive = true; burikMethod = "layar ${nw}x${nh}" }
        return good
    }

    fun resetBurik(ctx: Context, pkgs: List<String>) {
        if (!burikSupported) return
        val st = Store(ctx)
        // bersihkan sisa cara lama (kalau pernah terpasang)
        Sz.sh(pkgs.distinct().joinToString("\n") { p ->
            "cmd game reset $p\n" + BK.joinToString("\n") { "am compat reset $it $p" }
        })
        if (st.burikActive) { restoreBase(ctx); st.burikActive = false }
    }

    // ---------- Sensi (setelan sistem saja) ----------
    fun sensiValue(x: Int, y: Int): Int = Math.round(((x + y) / 2f - 5f) / 5f * 7f).coerceIn(-7, 7)

    fun applySensi(ctx: Context, x: Int, y: Int): Boolean = try {
        val st = Store(ctx)
        val cr = ctx.contentResolver
        if (st.sensiOrig.isEmpty()) st.sensiOrig = Settings.System.getInt(cr, "pointer_speed", 0).toString()
        val v = sensiValue(x, y)
        Settings.System.putInt(cr, "pointer_speed", v)
        Settings.System.getInt(cr, "pointer_speed", 99) == v
    } catch (e: Throwable) { false }

    fun resetSensi(ctx: Context) {
        try {
            val st = Store(ctx)
            val o = st.sensiOrig.toIntOrNull() ?: return
            Settings.System.putInt(ctx.contentResolver, "pointer_speed", o)
            st.sensiOrig = ""
        } catch (e: Throwable) {}
    }

    // ---------- Resolusi layar (wm size) ----------
    private fun physSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(Sz.sh("wm size")) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    /** pct 50..99 = turunkan, 100 = asli. Mengembalikan teks resolusi bila berhasil, null bila gagal. */
    fun setReso(pct: Int): String? {
        if (pct >= 100) { resetReso(); return "Asli" }
        val (w, h) = physSize() ?: return null
        val nw = (w * pct / 100) / 2 * 2
        val nh = (h * pct / 100) / 2 * 2
        Sz.sh("wm size ${nw}x${nh}")
        return if (Sz.sh("wm size").contains("${nw}x${nh}")) "${nw}x${nh}" else null
    }

    fun resetReso() { Sz.sh("wm size reset\nwm density reset") }

    /** [lebar, tinggi, density] yang sedang aktif. */
    fun readDisplay(): List<String>? {
        val o = Sz.sh("wm size; wm density")
        val sz = Regex("Override size: (\\d+)x(\\d+)").find(o) ?: Regex("Physical size: (\\d+)x(\\d+)").find(o) ?: return null
        val dn = Regex("Override density: (\\d+)").find(o) ?: Regex("Physical density: (\\d+)").find(o)
        return listOf(sz.groupValues[1], sz.groupValues[2], dn?.groupValues?.get(1) ?: "")
    }

    /** Kembali ke keadaan sebelum aplikasi mengubah resolusi (mis. DPI yang kamu atur sendiri). Null bila tidak ada / gagal. */
    fun restoreBase(ctx: Context): String? {
        val st = Store(ctx)
        val b = st.resoBase.split(",")
        if (b.size < 3 || b[0].isEmpty()) return null
        val good = restoreDisplay(b[0].toInt(), b[1].toInt(), b[2].toIntOrNull() ?: 0)
        if (good) st.resoBase = ""
        return if (good) "${b[0]}x${b[1]}" + (if (b[2].isNotEmpty()) " · ${b[2]} dpi" else "") else null
    }

    /** Pulihkan nilai W x H dan density persis seperti sebelumnya. */
    fun restoreDisplay(w: Int, h: Int, d: Int): Boolean {
        Sz.sh("wm size ${w}x${h}" + if (d > 0) "\nwm density $d" else "")
        val o = Sz.sh("wm size; wm density")
        return o.contains("${w}x${h}") && (d <= 0 || o.contains("density: $d"))
    }

    /** Atur resolusi W x H dan density (d = 0: density tidak diubah). Pair(berhasil, pesan). */
    fun setCustom(w0: Int, h0: Int, d: Int): Pair<Boolean, String> {
        val (pw, ph) = physSize() ?: return false to "Gagal membaca layar. Pastikan Shizuku aktif."
        var w = w0; var h = h0
        if ((pw < ph) != (w < h)) { val t = w; w = h; h = t }
        if (w < 240 || h < 240) return false to "Resolusi terlalu kecil (minimal 240)"
        if (w > pw || h > ph) return false to "Maksimal ${pw}x${ph} (resolusi asli HP)"
        if (d != 0 && (d < 120 || d > 900)) return false to "Density harus 120 sampai 900"
        Sz.sh("wm size ${w}x${h}")
        if (d > 0) Sz.sh("wm density $d")
        val o = Sz.sh("wm size; wm density")
        val good = o.contains("${w}x${h}") && (d <= 0 || o.contains("density: $d"))
        return if (good) true to ("${w}x${h}" + (if (d > 0) " · $d dpi" else "")) else false to "Ditolak sistem"
    }

    /** Kembalikan semua ke asli (dipanggil saat > 5 menit di luar game). */
    fun revertAll(ctx: Context, pkg: String) {
        reset()
        resetBurik(ctx, Store(ctx).games + pkg)
        restoreBase(ctx)
        Store(ctx).resoPct = 100
    }

    fun forceStop(pkg: String) = Sz.sh("am force-stop $pkg")
}
