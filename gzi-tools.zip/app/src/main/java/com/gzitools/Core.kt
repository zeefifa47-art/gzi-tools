package com.gzitools

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Base64
import rikka.shizuku.Shizuku

/** Konfigurasi tekstur per game. level 0..4 = Asli, Ringan, Retro, Kotak, Ekstrem */
data class TexCfg(
    val enabled: Boolean = false,
    val level: Int = 2,
    val sharp: Boolean = true,
    val hard: Boolean = true,
    val drv: Boolean = true
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gzi", Context.MODE_PRIVATE)

    var games: List<String>
        get() = (p.getString("games", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("games", v.joinToString(",")).apply() }

    var overlayOn: Boolean
        get() = p.getBoolean("ov", true)
        set(v) { p.edit().putBoolean("ov", v).apply() }
    var hy: Int
        get() = p.getInt("hy", -1)
        set(v) { p.edit().putInt("hy", v).apply() }
    var xhOn: Boolean
        get() = p.getBoolean("xh.on", false)
        set(v) { p.edit().putBoolean("xh.on", v).apply() }
    var xhStyle: Int
        get() = p.getInt("xh.st", 0)
        set(v) { p.edit().putInt("xh.st", v).apply() }
    var xhSize: Int
        get() = p.getInt("xh.sz", 60)
        set(v) { p.edit().putInt("xh.sz", v).apply() }
    var xhColor: Int
        get() = p.getInt("xh.co", 0)
        set(v) { p.edit().putInt("xh.co", v).apply() }

    var burikOn: Boolean
        get() = p.getBoolean("bk.on", false)
        set(v) { p.edit().putBoolean("bk.on", v).apply() }
    var burikLv: Int
        get() = p.getInt("bk.lv", 1)
        set(v) { p.edit().putInt("bk.lv", v).apply() }
    var sensiOn: Boolean
        get() = p.getBoolean("sn.on", false)
        set(v) { p.edit().putBoolean("sn.on", v).apply() }
    var sensiX: Int
        get() = p.getInt("sn.x", 5)
        set(v) { p.edit().putInt("sn.x", v).apply() }
    var sensiY: Int
        get() = p.getInt("sn.y", 5)
        set(v) { p.edit().putInt("sn.y", v).apply() }
    var sensiOrig: String
        get() = p.getString("sn.o", "") ?: ""
        set(v) { p.edit().putString("sn.o", v).apply() }

    fun has(pkg: String) = p.contains("$pkg.lvl")

    fun cfg(pkg: String) = TexCfg(
        p.getBoolean("$pkg.en", false),
        p.getInt("$pkg.lvl", 2),
        p.getBoolean("$pkg.sh", true),
        p.getBoolean("$pkg.hd", true),
        p.getBoolean("$pkg.an", true)
    )

    fun save(pkg: String, c: TexCfg) {
        p.edit()
            .putBoolean("$pkg.en", c.enabled)
            .putInt("$pkg.lvl", c.level)
            .putBoolean("$pkg.sh", c.sharp)
            .putBoolean("$pkg.hd", c.hard)
            .putBoolean("$pkg.an", c.drv)
            .apply()
    }
}

/** Akses shell (uid 2000) lewat Shizuku. */
object Sz {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Throwable) { false }

    fun perms(ctx: Context): Boolean =
        Settings.System.canWrite(ctx) && Settings.canDrawOverlays(ctx)

    fun ready(ctx: Context): Boolean = perms(ctx) && alive() && granted()

    /** Jalankan perintah shell lewat Shizuku. Panggil dari thread background. */
    fun sh(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERROR: " + (e.cause?.message ?: e.message)
    }
}

/** Mesin grafis. Hanya didukung Android 15+ (SDK 35). */
object Engine {
    val LEVELS = listOf("Normal", "Lembut", "8-Bit", "Blok", "Mozaik")
    val supported: Boolean get() = Build.VERSION.SDK_INT >= 35

    private fun d(s: String) = String(Base64.decode(s, Base64.NO_WRAP))
    private val K1 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl9wa2dz")
    private val K2 = d("YW5nbGVfZ2xfZHJpdmVyX3NlbGVjdGlvbl92YWx1ZXM=")
    private val K3 = d("YW5nbGU=")
    private val K4 = d("YW5nbGVfZWdsX2ZlYXR1cmVz")
    private val K5 = d("ZGVidWcuYW5nbGUuZmVhdHVyZV9vdmVycmlkZXNfZW5hYmxlZA==")
    private val F1 = d("Zm9yY2VOZWFyZXN0RmlsdGVyaW5n")
    private val F2 = d("Zm9yY2VOZWFyZXN0TWlwRmlsdGVyaW5n")
    private val F3 = d("Zm9yY2VUZXh0dXJlTG9kT2Zmc2V0")

    private fun features(c: TexCfg): String {
        val l = mutableListOf<String>()
        if (c.sharp) l += F1
        if (c.hard) l += F2
        if (c.level in 1..4) l += "$F3${c.level}"
        return l.joinToString(":")
    }

    private fun featureCmd(f: String): String =
        if (f.isEmpty()) "settings delete global $K4\nsetprop $K5 ''\n"
        else "settings put global $K4 '$f'\nsetprop $K5 '$f'\n"

    /** Terapkan konfigurasi. Panggil dari thread background. */
    fun apply(ctx: Context, pkg: String, c: TexCfg): String {
        if (!supported) return ""
        val sb = StringBuilder()
        if (c.enabled) {
            val pk = (Store(ctx).games + pkg).distinct()
            sb.append("settings put global $K1 ${pk.joinToString(",")}\n")
            sb.append("settings put global $K2 ${pk.joinToString(",") { K3 }}\n")
            sb.append(featureCmd(features(c)))
        } else {
            sb.append(featureCmd(""))
        }
        return Sz.sh(sb.toString())
    }

    fun reset(): String = if (!supported) "" else Sz.sh(featureCmd(""))

    // ---------- Grafik Burik (Android 11+) ----------
    val BURIK = listOf("Asli", "Ringan", "Extrem")
    val BURIK_F = floatArrayOf(1f, 0.8f, 0.6f)
    val burikSupported: Boolean get() = Build.VERSION.SDK_INT >= 30
    private val BK = arrayOf("", "DOWNSCALE_80", "DOWNSCALE_60")

    /** level 0 = asli (hapus), 1 = ringan, 2 = extrem. true bila sistem menerima. */
    fun applyBurik(pkg: String, level: Int): Boolean {
        if (!burikSupported) return false
        val sb = StringBuilder()
        sb.append("am compat reset ${BK[1]} $pkg\nam compat reset ${BK[2]} $pkg\n")
        if (level in 1..2) sb.append("am compat enable ${BK[level]} $pkg\n")
        val out = Sz.sh(sb.toString())
        return level == 0 || out.contains("Enabled", true)
    }

    fun resetBurik(pkgs: List<String>) {
        if (!burikSupported) return
        Sz.sh(pkgs.distinct().joinToString("\n") { "am compat reset ${BK[1]} $it\nam compat reset ${BK[2]} $it" })
    }

    // ---------- Sensi (setelan sistem saja) ----------
    fun sensiValue(x: Int, y: Int): Int = Math.round(((x + y) / 2f - 5.5f) / 4.5f * 7f).coerceIn(-7, 7)

    fun applySensi(ctx: Context, x: Int, y: Int): Boolean = try {
        val st = Store(ctx)
        val cr = ctx.contentResolver
        if (st.sensiOrig.isEmpty()) st.sensiOrig = Settings.System.getInt(cr, "pointer_speed", 0).toString()
        val v = sensiValue(x, y)
        Settings.System.putInt(cr, "pointer_speed", v)
        Settings.System.getInt(cr, "pointer_speed", 99) == v
    } catch (e: Throwable) { false }

    fun resetSensi(ctx: Context) {
        try {
            val st = Store(ctx)
            val o = st.sensiOrig.toIntOrNull() ?: return
            Settings.System.putInt(ctx.contentResolver, "pointer_speed", o)
            st.sensiOrig = ""
        } catch (e: Throwable) {}
    }

    /** Kembalikan semua ke asli (dipanggil saat > 5 menit di luar game). */
    fun revertAll(ctx: Context, pkg: String) {
        reset()
        resetBurik(Store(ctx).games + pkg)
        resetSensi(ctx)
    }

    fun forceStop(pkg: String) = Sz.sh("am force-stop $pkg")
}
