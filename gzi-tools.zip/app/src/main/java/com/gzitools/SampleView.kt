package com.gzitools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.max

/** Sampel Sebelum/Sesudah (geser garis). Mensimulasikan LOD offset + filter nearest. */
class SampleView(ctx: Context) : View(ctx) {
    private val src: Bitmap = makeSample()
    private var after: Bitmap = src
    private var sharp = false
    private var split = 0.5f
    private val paint = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = ctx.dp(2).toFloat() }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.GREEN }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = ctx.dp(11).toFloat(); typeface = ctx.head() }
    private val chipBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
    private val clip = Path()

    fun update(level: Int, sharp: Boolean) {
        this.sharp = sharp
        val s = 1 shl level
        after = if (level == 0) src
        else Bitmap.createScaledBitmap(src, max(2, src.width / s), max(2, src.height / s), true)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        clip.reset(); clip.addRoundRect(RectF(0f, 0f, w, h), context.dp(16).toFloat(), context.dp(16).toFloat(), Path.Direction.CW)
        c.save(); c.clipPath(clip)
        val dst = RectF(0f, 0f, w, h)
        val x = w * split
        c.save(); c.clipRect(0f, 0f, x, h)
        paint.isFilterBitmap = true; c.drawBitmap(src, null, dst, paint)
        c.restore()
        c.save(); c.clipRect(x, 0f, w, h)
        paint.isFilterBitmap = !sharp; c.drawBitmap(after, null, dst, paint)
        c.restore()
        c.drawLine(x, 0f, x, h, line)
        c.drawCircle(x, h / 2, context.dp(16).toFloat(), knob)
        label.color = Pal.ON_GREEN; c.drawText("<>", x - context.dp(8), h / 2 + context.dp(4), label)
        label.color = Color.WHITE
        val pad = context.dp(8).toFloat()
        c.drawRoundRect(pad, pad, pad + context.dp(66), pad + context.dp(22), 12f, 12f, chipBg)
        c.drawText("ASLI", pad + context.dp(7), pad + context.dp(15), label)
        c.drawRoundRect(w - pad - context.dp(66), pad, w - pad, pad + context.dp(22), 12f, 12f, chipBg)
        c.drawText("HASIL", w - pad - context.dp(59), pad + context.dp(15), label)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        split = (e.x / width).coerceIn(0.05f, 0.95f)
        invalidate()
        return true
    }

    private fun makeSample(): Bitmap {
        val n = 256
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = Random(7)
        val p = Paint()
        c.drawColor(Color.rgb(196, 190, 180))
        // dinding bata
        val bh = 16; val bw = 32; val wallH = (n * 0.55f).toInt()
        var row = 0; var y = 0
        while (y < wallH) {
            var x = -(if (row % 2 == 0) 0 else bw / 2)
            while (x < n) {
                val j = r.nextInt(40) - 20
                p.color = Color.rgb(150 + j, 112 + j, 98 + j)
                c.drawRect((x + 2).toFloat(), (y + 2).toFloat(), (x + bw - 1).toFloat(), (y + bh - 1).toFloat(), p)
                if (r.nextInt(3) == 0) { // lumut
                    p.color = Color.argb(150, 80 + r.nextInt(40), 130 + r.nextInt(40), 60)
                    c.drawRect((x + 2).toFloat(), (y + 2).toFloat(), (x + bw - 1 - r.nextInt(14)).toFloat(), (y + 2 + r.nextInt(bh - 4) + 3).toFloat(), p)
                }
                x += bw
            }
            y += bh; row++
        }
        // tanah + rumput
        for (yy in wallH until n step 3) for (xx in 0 until n step 3) {
            val g = r.nextInt(100) < 45 + (yy - wallH) / 6
            p.color = if (g) Color.rgb(60 + r.nextInt(40), 110 + r.nextInt(50), 40 + r.nextInt(30))
            else Color.rgb(112 + r.nextInt(30), 88 + r.nextInt(25), 62 + r.nextInt(20))
            c.drawRect(xx.toFloat(), yy.toFloat(), (xx + 3).toFloat(), (yy + 3).toFloat(), p)
        }
        // marka jalan putus-putus
        p.color = Color.rgb(225, 225, 215)
        for (k in 0 until 4) c.drawRect((120 + k * 3).toFloat(), (wallH + 20 + k * 45).toFloat(), (126 + k * 3).toFloat(), (wallH + 34 + k * 45).toFloat(), p)
        return bmp
    }
}
