package com.gzitools

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.VideoView

/** Video pembuka sebelum Arena. Tap = lewati. Selesai / dilewati = transisi hijau ke Arena. */
class IntroActivity : Activity() {
    private var done = false
    private var pkg = ""
    private val ui = Handler(Looper.getMainLooper())
    private var vv: VideoView? = null
    private var flash: View? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pkg = intent.getStringExtra("pkg") ?: run { finish(); return }
        val id = resources.getIdentifier("intro", "raw", packageName)
        if (id == 0) { next(); return }

        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        val v = VideoView(this)
        vv = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        val hint = tx("TAP UNTUK LEWATI  ▸▸", 11f, Pal.GREEN, true).apply {
            letterSpacing = 0.2f
            background = shape(Color_BLACK_A, dp(10).toFloat())
            setPadding(dp(14), dp(7), dp(14), dp(7))
        }
        root.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(16)) })
        val f = View(this).apply { setBackgroundColor(Pal.GREEN); alpha = 0f }
        flash = f
        root.addView(f, FrameLayout.LayoutParams(MATCH, MATCH))
        root.setOnClickListener { go() }
        setContentView(root)

        v.setOnPreparedListener { it.isLooping = false; v.start() }
        v.setOnCompletionListener { go() }
        v.setOnErrorListener { _, _, _ -> go(); true }
        v.setVideoURI(Uri.parse("android.resource://$packageName/$id"))
        ui.postDelayed({ if (!done && vv?.isPlaying != true) go() }, 6000)
    }

    /** Transisi: kilat hijau lalu masuk Arena. */
    private fun go() {
        if (done) return
        done = true
        try { vv?.stopPlayback() } catch (e: Exception) {}
        val f = flash
        if (f == null) { next(); return }
        f.animate().alpha(1f).setDuration(240).withEndAction { next() }.start()
    }

    private fun next() {
        startActivity(Intent(this, GameSpaceActivity::class.java).putExtra("pkg", pkg).putExtra("fromIntro", true))
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { go() }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }

    private companion object { const val Color_BLACK_A = 0x99000000.toInt() }
}
