package com.gzitools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    val BG = Color.parseColor("#040A07")
    val CARD = Color.parseColor("#0B1712")
    val CARD2 = Color.parseColor("#10211A")
    val LINE = Color.parseColor("#1D3A2D")
    val GREEN = Color.parseColor("#39FF88")
    val GREEN_D = Color.parseColor("#0F6B3A")
    val ON_GREEN = Color.parseColor("#02140A")
    val TEXT = Color.parseColor("#EAFBF1")
    val MUTED = Color.parseColor("#7FA391")
    val WARN = Color.parseColor("#FFC24D")
    val BAD = Color.parseColor("#FF6B6B")
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.head(): Typeface = resources.getFont(R.font.oxanium_bold)
fun Context.body(): Typeface = resources.getFont(R.font.chakra_petch_medium)

fun shape(fill: Int, radius: Float, stroke: Int = 0, sw: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius
        if (stroke != 0) setStroke(sw, stroke)
    }

fun Context.tx(s: String, sp: Float, color: Int = Pal.TEXT, heading: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        typeface = if (heading) head() else body()
    }

fun Context.btn(label: String, primary: Boolean = true, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        textSize = 14f
        typeface = head()
        gravity = Gravity.CENTER
        setTextColor(if (primary) Pal.ON_GREEN else Pal.TEXT)
        background = shape(
            if (primary) Pal.GREEN else Pal.CARD2, dp(24).toFloat(),
            if (primary) 0 else Pal.LINE, dp(1)
        )
        setPadding(dp(20), dp(12), dp(20), dp(12))
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = shape(Pal.CARD, dp(20).toFloat(), Pal.LINE, dp(1))
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
) {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply {
        setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    })
}

fun drawableToBitmap(d: Drawable, size: Int = 256): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    d.setBounds(0, 0, size, size)
    d.draw(c)
    return bmp
}
