package com.gzitools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    val BG = Color.parseColor("#030806")
    val CARD = Color.parseColor("#0A1510")
    val CARD2 = Color.parseColor("#0F2018")
    val LINE = Color.parseColor("#1D3A2D")
    val GREEN = Color.parseColor("#39FF88")
    val GREEN_D = Color.parseColor("#0F6B3A")
    val ON_GREEN = Color.parseColor("#02140A")
    val TEXT = Color.parseColor("#EAFBF1")
    val MUTED = Color.parseColor("#7FA391")
    val WARN = Color.parseColor("#FFC24D")
    val BAD = Color.parseColor("#FF6B6B")
    val GREEN_SOFT = Color.argb(38, 57, 255, 136)
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// Dikunci ke kepadatan referensi TETAP (bukan resources.displayMetrics.density device/live) supaya
// ukuran panel & semua elemen overlay gak ikut berubah kalau setelan "ukuran tampilan/font" sistem
// (MIUI dkk) diubah — mau DPI berapa pun di HP, hasil pikselnya tetap sama persis. Nilainya juga
// sengaja lebih kecil dari kepadatan rata-rata HP (xxhdpi ~2.75-3.5) biar panelnya kelihatan lebih kecil.
private const val REF_DENSITY = 1.8f
fun Context.dp(v: Int): Int = (v * REF_DENSITY + 0.5f).toInt()
fun Context.head(): Typeface = resources.getFont(R.font.oxanium_bold)
fun Context.body(): Typeface = resources.getFont(R.font.chakra_petch_medium)

/** Poligon sudut potong. diag=true: hanya kiri-atas & kanan-bawah (ciri khas GZI). */
fun chamferPath(l: Float, t: Float, r: Float, b: Float, cut: Float, diag: Boolean): Path {
    val p = Path()
    if (diag) {
        p.moveTo(l + cut, t); p.lineTo(r, t); p.lineTo(r, b - cut)
        p.lineTo(r - cut, b); p.lineTo(l, b); p.lineTo(l, t + cut)
    } else {
        p.moveTo(l + cut, t); p.lineTo(r - cut, t); p.lineTo(r, t + cut); p.lineTo(r, b - cut)
        p.lineTo(r - cut, b); p.lineTo(l + cut, b); p.lineTo(l, b - cut); p.lineTo(l, t + cut)
    }
    p.close()
    return p
}

fun chamferOutline(cut: Float, diag: Boolean): ViewOutlineProvider = object : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setConvexPath(chamferPath(0f, 0f, view.width.toFloat(), view.height.toFloat(), cut, diag))
    }
}

class ChamferBg(
    private val cut: Float,
    private val sw: Float,
    fillColor: Int = Color.argb(236, 4, 14, 10),
    private val strokeColor: Int = Pal.GREEN,
    private val glowOn: Boolean = true,
    private val diag: Boolean = false,
    /** Kilau halus di pojok kiri-atas — kesan kaca/premium tipis, aman dipakai di kartu mana pun. */
    private val sheen: Boolean = false
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor; style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 57, 255, 136); style = Paint.Style.STROKE; strokeWidth = sw * 4 }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = strokeColor; style = Paint.Style.STROKE; strokeWidth = sw }
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun draw(c: Canvas) {
        val ins = if (glowOn) sw * 2 else sw / 2f
        val b = bounds
        val p = chamferPath(b.left + ins, b.top + ins, b.right - ins, b.bottom - ins, cut, diag)
        if (Color.alpha(fill.color) > 0) c.drawPath(p, fill)
        if (glowOn) c.drawPath(p, glow)
        if (sheen && b.width() > 0 && b.height() > 0) {
            sheenPaint.shader = RadialGradient(
                b.left + b.width() * 0.18f, b.top.toFloat(), b.width() * 0.75f,
                Color.argb(46, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
            c.save(); c.clipPath(p); c.drawPaint(sheenPaint); c.restore()
        }
        if (strokeColor != 0 && sw > 0f) c.drawPath(p, line)
    }

    override fun getOutline(outline: Outline) {
        val b = bounds
        outline.setConvexPath(chamferPath(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), cut, diag))
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Latar grid + cahaya hijau. */
class GridBg(ctx: Context) : View(ctx) {
    private val gp = Paint().apply { color = Color.argb(20, 57, 255, 136); strokeWidth = 1f }
    private val glow = Paint()
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Pal.BG)
        val step = context.dp(30).toFloat()
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, gp); x += step }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, gp); y += step }
        glow.shader = RadialGradient(w * 0.95f, 0f, w * 0.9f, Color.argb(75, 57, 255, 136), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, glow)
        glow.shader = RadialGradient(0f, h, w * 0.7f, Color.argb(40, 57, 255, 136), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, glow)
    }
}

/** Garis diagonal tipis (aksen banner). */
class Stripes(ctx: Context) : View(ctx) {
    private val p = Paint().apply { color = Color.argb(26, 57, 255, 136); strokeWidth = ctx.dp(2).toFloat() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val step = context.dp(16).toFloat()
        var x = -h
        while (x < w) { c.drawLine(x, h, x + h, 0f, p); x += step }
    }
}

fun shape(fill: Int, radius: Float, stroke: Int = 0, sw: Int = 0): Drawable =
    ChamferBg(radius * 0.5f, sw.toFloat(), fill, stroke, false, true)

fun Context.tx(s: String, sp: Float, color: Int = Pal.TEXT, heading: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        typeface = if (heading) head() else body()
    }

/** Animasi kecil pas ditekan — zoom-out tipis lalu balik. Dipakai otomatis di btn()/card(). */
fun View.pressFx() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false // biarkan tetap diteruskan ke OnClickListener normal
    }
}

fun Context.btn(label: String, primary: Boolean = true, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        textSize = 13f
        typeface = head()
        letterSpacing = 0.06f
        gravity = Gravity.CENTER
        setTextColor(if (primary) Pal.ON_GREEN else Pal.TEXT)
        background = ChamferBg(
            dp(9).toFloat(), dp(1).toFloat(),
            if (primary) Pal.GREEN else Pal.CARD2,
            if (primary) 0 else Pal.GREEN_D, primary, true
        )
        setPadding(dp(20), dp(12), dp(20), dp(12))
        isClickable = true
        pressFx()
        setOnClickListener { onClick() }
    }

fun Context.card(sheen: Boolean = false): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = ChamferBg(dp(14).toFloat(), dp(1).toFloat(), Pal.CARD, Pal.LINE, false, true, sheen)
    setPadding(dp(18), dp(16), dp(18), dp(16))
    pressFx()
}

/**
 * Toggle custom bergaya chamfer (ganti Switch bawaan Android) — kotak potong-sudut + geser animasi,
 * biar seragam sama tema hijau GZI TOOLS di semua layar. Set `checked` buat ubah tampilan tanpa
 * mentrigger `onChange` (dipakai pas isi ulang nilai dari penyimpanan); `onChange` cuma jalan pas
 * ditekan user.
 */
class GziToggle(ctx: Context) : FrameLayout(ctx) {
    private val trackW = ctx.dp(54)
    private val trackH = ctx.dp(30)
    private val thumbSz = ctx.dp(22)
    private val margin = ctx.dp(4)
    private val onX = (trackW - thumbSz - margin * 2).toFloat()
    private val track = View(ctx)
    private val thumb = View(ctx)
    var onChange: ((Boolean) -> Unit)? = null
    var checked: Boolean = false
        set(v) { field = v; render(isAttachedToWindow) }

    init {
        track.background = ChamferBg(ctx.dp(8).toFloat(), ctx.dp(1).toFloat(), Pal.CARD2, Pal.LINE, false, true)
        addView(track, FrameLayout.LayoutParams(trackW, trackH, Gravity.CENTER_VERTICAL))
        thumb.background = ChamferBg(ctx.dp(5).toFloat(), 0f, Pal.MUTED, 0, false, true)
        addView(thumb, FrameLayout.LayoutParams(thumbSz, thumbSz, Gravity.CENTER_VERTICAL).apply { leftMargin = margin })
        isClickable = true
        pressFx()
        setOnClickListener { checked = !checked; onChange?.invoke(checked) }
        render(false)
    }

    private fun render(animate: Boolean) {
        val tx = if (checked) onX else 0f
        if (animate) thumb.animate().translationX(tx).setDuration(160).start() else thumb.translationX = tx
        track.background = ChamferBg(context.dp(8).toFloat(), context.dp(1).toFloat(), if (checked) Pal.GREEN_SOFT else Pal.CARD2, if (checked) Pal.GREEN else Pal.LINE, false, true)
        thumb.background = ChamferBg(context.dp(5).toFloat(), 0f, if (checked) Pal.GREEN else Pal.MUTED, 0, false, true)
    }
}

/** Bikin GziToggle siap pakai: `initial` nilai awal (gak mentrigger onChange), `onChange` dipanggil cuma pas user menekan. */
fun Context.toggle(initial: Boolean, onChange: (Boolean) -> Unit): GziToggle = GziToggle(this).apply {
    this.onChange = onChange
    checked = initial
}

/** Badge status kecil — pengganti teks "● LABEL" biasa, dipakai di MainActivity & panel in-game. */
fun Context.pill(text: String, on: Boolean): TextView = tx("●  $text", 11f, if (on) Pal.GREEN else Pal.WARN, true).apply {
    letterSpacing = 0.04f
    gravity = Gravity.CENTER
    background = ChamferBg(dp(8).toFloat(), dp(1).toFloat(), if (on) Pal.GREEN_SOFT else Color.argb(32, 255, 194, 77), if (on) Pal.GREEN else Pal.WARN, false, true)
    setPadding(dp(10), dp(5), dp(10), dp(5))
}

/** Badge ikon kotak kecil (emoji/simbol) buat kepala kartu fitur — dipakai di semua layar. */
fun Context.iconBadge(glyph: String): TextView = tx(glyph, 18f, Pal.GREEN, true).apply {
    gravity = Gravity.CENTER
    background = ChamferBg(dp(10).toFloat(), dp(1).toFloat(), Pal.GREEN_SOFT, Pal.GREEN_D, false, true)
}

/**
 * Bracket sudut ala HUD sci-fi (cuma garis-L di 4 pojok, BUKAN kotak penuh) — dipasang NEMPEL di
 * atas background biasa sebuah view lewat View.hudCorners(), bukan gantiin. Ciri khas "rombakan"
 * v3: kartu-kartu penting sekarang kelihatan kayak jendela radar/targeting, bukan kartu polos.
 */
class HudCorner(private val color: Int = Pal.GREEN, private val lenPx: Float = 0f, private val swPx: Float = 0f) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    override fun draw(c: Canvas) {
        val b = bounds
        val l = if (lenPx > 0f) lenPx else minOf(b.width(), b.height()) * 0.12f
        p.color = color
        p.strokeWidth = if (swPx > 0f) swPx else 3f
        val L = b.left.toFloat(); val T = b.top.toFloat(); val R = b.right.toFloat(); val B = b.bottom.toFloat()
        c.drawLine(L, T + l, L, T, p); c.drawLine(L, T, L + l, T, p)
        c.drawLine(R - l, T, R, T, p); c.drawLine(R, T, R, T + l, p)
        c.drawLine(L, B - l, L, B, p); c.drawLine(L, B, L + l, B, p)
        c.drawLine(R - l, B, R, B, p); c.drawLine(R, B - l, R, B, p)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Tempel bracket HUD di 4 sudut view ini, di LAPISAN DEPAN (foreground) — background aslinya tetap kepakai. */
fun View.hudCorners(color: Int = Pal.GREEN) { foreground = HudCorner(color, context.dp(14).toFloat(), context.dp(2).toFloat()) }

/** Garis pembatas tipis — dipakai berulang di bawah judul kartu di semua layar. */
fun Context.divider(): View = View(this).apply { setBackgroundColor(Pal.LINE) }

/**
 * Chip status buat strip horizontal di kartu hero (ganti baris SHIZUKU/IZIN SISTEM/GRAFIK yang
 * lama) — gaya "readout" HUD: label kecil di atas, nilai gede di bawah. Return kartu + TextView
 * nilainya (buat diupdate lewat setStatChip()).
 */
fun Context.statChip(label: String): Pair<LinearLayout, TextView> {
    val c = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = ChamferBg(dp(10).toFloat(), dp(1).toFloat(), Pal.CARD2, Pal.LINE, false, true)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        hudCorners()
    }
    c.add(tx(label, 9f, Pal.MUTED, true).apply { letterSpacing = 0.1f })
    val v = tx("—", 13f, Pal.GREEN, true)
    c.add(v, WRAP, WRAP, 0f, 0, 5)
    return c to v
}

/** Update isi statChip() — dipanggil tiap refresh status, teks + warnanya ikut nilai ok/tidaknya. */
fun setStatChip(v: TextView, ok: Boolean, s: String) {
    v.text = s
    v.setTextColor(if (ok) Pal.GREEN else Pal.WARN)
}

/** Label section dengan bar aksen di kiri — dipakai berulang buat judul grup di semua layar. */
fun Context.sectionTag(text: String): LinearLayout {
    val ctx = this
    return LinearLayout(ctx).apply {
        gravity = Gravity.CENTER_VERTICAL
        add(View(ctx).apply { setBackgroundColor(Pal.GREEN) }, ctx.dp(4), ctx.dp(16), 0f, 0, 0, 10)
        add(ctx.tx(text, 13f, Pal.TEXT, true).apply { letterSpacing = 0.1f }, WRAP)
    }
}

fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
) {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply {
        setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    })
}

fun drawableToBitmap(d: Drawable, size: Int = 256): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    d.setBounds(0, 0, size, size)
    d.draw(c)
    return bmp
}

/** Notifikasi hijau "SUCCES" yang muncul di atas layar lalu hilang sendiri. */
fun FrameLayout.banner(msg: String) {
    val ctx = context
    val t = ctx.tx("✔  SUCCES  ·  $msg", 12f, Pal.ON_GREEN, true)
    t.gravity = Gravity.CENTER
    t.background = ChamferBg(ctx.dp(8).toFloat(), 0f, Pal.GREEN, 0, false, true)
    t.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
    t.alpha = 0f
    addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ctx.dp(14) })
    t.animate().alpha(1f).setDuration(160).withEndAction {
        t.animate().alpha(0f).setStartDelay(2200).setDuration(300).withEndAction { removeView(t) }.start()
    }.start()
}
