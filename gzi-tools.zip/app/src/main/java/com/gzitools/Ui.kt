package com.gzitools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    val BG = Color.parseColor("#030806")
    val CARD = Color.parseColor("#0A1510")
    val CARD2 = Color.parseColor("#0F2018")
    val LINE = Color.parseColor("#1D3A2D")
    val GREEN = Color.parseColor("#39FF88")
    val GREEN_D = Color.parseColor("#0F6B3A")
    val ON_GREEN = Color.parseColor("#02140A")
    val TEXT = Color.parseColor("#EAFBF1")
    val MUTED = Color.parseColor("#7FA391")
    val WARN = Color.parseColor("#FFC24D")
    val BAD = Color.parseColor("#FF6B6B")
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.head(): Typeface = resources.getFont(R.font.oxanium_bold)
fun Context.body(): Typeface = resources.getFont(R.font.chakra_petch_medium)

/** Poligon sudut potong. diag=true: hanya kiri-atas & kanan-bawah (ciri khas GZI). */
fun chamferPath(l: Float, t: Float, r: Float, b: Float, cut: Float, diag: Boolean): Path {
    val p = Path()
    if (diag) {
        p.moveTo(l + cut, t); p.lineTo(r, t); p.lineTo(r, b - cut)
        p.lineTo(r - cut, b); p.lineTo(l, b); p.lineTo(l, t + cut)
    } else {
        p.moveTo(l + cut, t); p.lineTo(r - cut, t); p.lineTo(r, t + cut); p.lineTo(r, b - cut)
        p.lineTo(r - cut, b); p.lineTo(l + cut, b); p.lineTo(l, b - cut); p.lineTo(l, t + cut)
    }
    p.close()
    return p
}

fun chamferOutline(cut: Float, diag: Boolean): ViewOutlineProvider = object : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setConvexPath(chamferPath(0f, 0f, view.width.toFloat(), view.height.toFloat(), cut, diag))
    }
}

class ChamferBg(
    private val cut: Float,
    private val sw: Float,
    fillColor: Int = Color.argb(236, 4, 14, 10),
    private val strokeColor: Int = Pal.GREEN,
    private val glowOn: Boolean = true,
    private val diag: Boolean = false
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor; style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 57, 255, 136); style = Paint.Style.STROKE; strokeWidth = sw * 4 }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = strokeColor; style = Paint.Style.STROKE; strokeWidth = sw }

    override fun draw(c: Canvas) {
        val ins = if (glowOn) sw * 2 else sw / 2f
        val b = bounds
        val p = chamferPath(b.left + ins, b.top + ins, b.right - ins, b.bottom - ins, cut, diag)
        if (Color.alpha(fill.color) > 0) c.drawPath(p, fill)
        if (glowOn) c.drawPath(p, glow)
        if (strokeColor != 0 && sw > 0f) c.drawPath(p, line)
    }

    override fun getOutline(outline: Outline) {
        val b = bounds
        outline.setConvexPath(chamferPath(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), cut, diag))
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Latar grid + cahaya hijau. */
class GridBg(ctx: Context) : View(ctx) {
    private val gp = Paint().apply { color = Color.argb(20, 57, 255, 136); strokeWidth = 1f }
    private val glow = Paint()
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Pal.BG)
        val step = context.dp(30).toFloat()
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, gp); x += step }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, gp); y += step }
        glow.shader = RadialGradient(w * 0.95f, 0f, w * 0.9f, Color.argb(75, 57, 255, 136), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, glow)
        glow.shader = RadialGradient(0f, h, w * 0.7f, Color.argb(40, 57, 255, 136), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, glow)
    }
}

/** Garis diagonal tipis (aksen banner). */
class Stripes(ctx: Context) : View(ctx) {
    private val p = Paint().apply { color = Color.argb(26, 57, 255, 136); strokeWidth = ctx.dp(2).toFloat() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val step = context.dp(16).toFloat()
        var x = -h
        while (x < w) { c.drawLine(x, h, x + h, 0f, p); x += step }
    }
}

fun shape(fill: Int, radius: Float, stroke: Int = 0, sw: Int = 0): Drawable =
    ChamferBg(radius * 0.5f, sw.toFloat(), fill, stroke, false, true)

fun Context.tx(s: String, sp: Float, color: Int = Pal.TEXT, heading: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        typeface = if (heading) head() else body()
    }

fun Context.btn(label: String, primary: Boolean = true, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = label
        textSize = 13f
        typeface = head()
        letterSpacing = 0.06f
        gravity = Gravity.CENTER
        setTextColor(if (primary) Pal.ON_GREEN else Pal.TEXT)
        background = ChamferBg(
            dp(9).toFloat(), dp(1).toFloat(),
            if (primary) Pal.GREEN else Pal.CARD2,
            if (primary) 0 else Pal.GREEN_D, false, true
        )
        setPadding(dp(20), dp(12), dp(20), dp(12))
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = ChamferBg(dp(14).toFloat(), dp(1).toFloat(), Pal.CARD, Pal.LINE, false, true)
    setPadding(dp(18), dp(16), dp(18), dp(16))
}

fun LinearLayout.add(
    v: View, w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
) {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply {
        setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    })
}

fun drawableToBitmap(d: Drawable, size: Int = 256): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    d.setBounds(0, 0, size, size)
    d.draw(c)
    return bmp
}

/** Notifikasi hijau "SUCCES" yang muncul di atas layar lalu hilang sendiri. */
fun FrameLayout.banner(msg: String) {
    val ctx = context
    val t = ctx.tx("✔  SUCCES  ·  $msg", 12f, Pal.ON_GREEN, true)
    t.gravity = Gravity.CENTER
    t.background = ChamferBg(ctx.dp(8).toFloat(), 0f, Pal.GREEN, 0, false, true)
    t.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
    t.alpha = 0f
    addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ctx.dp(14) })
    t.animate().alpha(1f).setDuration(160).withEndAction {
        t.animate().alpha(0f).setStartDelay(2200).setDuration(300).withEndAction { removeView(t) }.start()
    }.start()
}
