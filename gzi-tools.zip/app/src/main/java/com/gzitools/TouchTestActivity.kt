package com.gzitools

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/** Papan uji sentuh: titik + jejak jari secara real time, untuk membandingkan sebelum/sesudah sensitivitas. */
class TouchTestActivity : Activity() {
    private val store by lazy { Store(this) }
    private val ui = Handler(Looper.getMainLooper())
    private var testOn = false
    private lateinit var pad: PadView
    private lateinit var info: TextView
    private val beat = object : Runnable {
        override fun run() {
            if (testOn) {
                val x = store.touchX; val y = store.touchY
                Thread { Engine.touchConf(true, x, y) }.start()
                ui.postDelayed(this, 3000)
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this).apply { setBackgroundColor(Pal.BG) }
        pad = PadView(this)
        root.addView(pad, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xE60A1510.toInt(), dp(14).toFloat(), Pal.GREEN_D, dp(1))
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val r1 = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
        r1.add(btn("←", false) { finish() }.apply { setPadding(dp(14), dp(6), dp(14), dp(6)) }, WRAP, WRAP, 0f, 0, 0, 10)
        r1.add(tx("UJI SENTUH", 16f, Pal.TEXT, true), 0, WRAP, 1f)
        val sw = Switch(this)
        r1.add(tx("Pakai sensitivitas", 11f, Pal.MUTED), WRAP, WRAP, 0f, 0, 0, 6)
        r1.add(sw, WRAP)
        bar.add(r1)
        info = tx("Sentuh layar untuk melihat titik dan jejak. Nyalakan 'Pakai sensitivitas' lalu bandingkan jarak jejak dengan gerakan jarimu.", 10f, Pal.MUTED)
        bar.add(info, t = 4)
        fun line(name: String, init: Int, isX: Boolean) {
            val l = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            l.add(tx("SENSI $name", 11f, Pal.GREEN, true), dp(64), WRAP)
            val tv = tx(init.toString(), 13f, Pal.GREEN, true)
            val sb = SeekBar(this).apply {
                max = 10; progress = init
                val g = android.content.res.ColorStateList.valueOf(Pal.GREEN)
                progressTintList = g; thumbTintList = g
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { tv.text = p.toString(); if (isX) store.touchX = p else store.touchY = p }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { if (testOn) { val x = store.touchX; val y = store.touchY; Thread { Engine.touchConf(true, x, y) }.start() } }
                })
            }
            l.add(sb, 0, WRAP, 1f)
            l.add(tv, dp(26), WRAP, 0f, 6)
            bar.add(l, t = 2)
        }
        line("X", store.touchX, true)
        line("Y", store.touchY, false)
        root.addView(bar, FrameLayout.LayoutParams(dp(360), WRAP, android.view.Gravity.TOP or android.view.Gravity.START).apply { setMargins(dp(16), dp(12), 0, 0) })
        setContentView(root)

        sw.setOnCheckedChangeListener { _, v ->
            if (v) {
                toast("Mengaktifkan...")
                Thread {
                    val err = Engine.touchStart(this, store.touchX, store.touchY, true)
                    runOnUiThread {
                        if (err.isEmpty()) { testOn = true; ui.post(beat); root.banner("Sensitivitas sentuh aktif untuk uji") }
                        else { sw.isChecked = false; toast(err) }
                    }
                }.start()
            } else stopTest()
        }
    }

    private fun stopTest() {
        if (!testOn) return
        testOn = false
        ui.removeCallbacks(beat)
        Thread { if (store.touchOn) Engine.touchConf(false, store.touchX, store.touchY) else Engine.touchStop() }.start()
    }

    override fun onPause() { stopTest(); super.onPause() }

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private class PadView(ctx: Context) : View(ctx) {
        private val trails = HashMap<Int, Path>()
        private val last = HashMap<Int, FloatArray>()
        private val dist = HashMap<Int, Float>()
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(3).toFloat(); color = Pal.GREEN; strokeCap = Paint.Cap.ROUND }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT; textSize = ctx.dp(11).toFloat(); typeface = ctx.head() }
        private val grid = Paint().apply { color = 0x221D3A2D; strokeWidth = 1f }
        private val down = HashSet<Int>()

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex; val id = e.getPointerId(i)
                    trails[id] = Path().apply { moveTo(e.getX(i), e.getY(i)) }
                    last[id] = floatArrayOf(e.getX(i), e.getY(i)); dist[id] = 0f; down += id
                }
                MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val l = last[id] ?: continue
                    trails[id]?.lineTo(e.getX(i), e.getY(i))
                    dist[id] = (dist[id] ?: 0f) + hypot(e.getX(i) - l[0], e.getY(i) - l[1])
                    l[0] = e.getX(i); l[1] = e.getY(i)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> down -= e.getPointerId(e.actionIndex)
                MotionEvent.ACTION_CANCEL -> down.clear()
            }
            invalidate()
            return true
        }

        override fun onDraw(c: Canvas) {
            val step = context.dp(40)
            var x = 0; while (x < width) { c.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), grid); x += step }
            var y = 0; while (y < height) { c.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), grid); y += step }
            for ((id, p) in trails) {
                c.drawPath(p, line)
                val l = last[id] ?: continue
                if (id in down) {
                    c.drawCircle(l[0], l[1], context.dp(14).toFloat(), dot)
                    c.drawText("#$id  ${l[0].toInt()},${l[1].toInt()}  Σ${(dist[id] ?: 0f).toInt()}px", l[0] + context.dp(20), l[1] - context.dp(10), txt)
                }
            }
        }
    }
}
