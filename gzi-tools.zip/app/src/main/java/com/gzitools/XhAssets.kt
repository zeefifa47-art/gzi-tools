package com.gzitools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * Crosshair gambar: assets/crosshair/crosshair1.png, crosshair2.png, ...
 * (juga dibaca dari folder app: Android/data/com.gzitools/files/crosshair/)
 * Id gaya = 100 + nomor file.
 */
object XhAssets {
    private var cache: Map<Int, Bitmap>? = null

    fun all(ctx: Context): Map<Int, Bitmap> {
        cache?.let { return it }
        val out = sortedMapOf<Int, Bitmap>()
        val ok = Regex(".*\\.(png|webp|jpg|jpeg)$", RegexOption.IGNORE_CASE)
        fun idOf(name: String, fallback: Int): Int =
            Regex("(\\d+)").find(name)?.value?.toIntOrNull()?.let { 100 + it } ?: (1000 + fallback)

        try {
            ctx.assets.list("crosshair")?.filter { ok.matches(it) }?.forEachIndexed { i, n ->
                ctx.assets.open("crosshair/$n").use { ins ->
                    decode(ins.readBytes())?.let { out[idOf(n, i)] = it }
                }
            }
        } catch (e: Throwable) {}
        try {
            ctx.getExternalFilesDir("crosshair")?.listFiles()?.filter { ok.matches(it.name) }?.forEachIndexed { i, f: File ->
                decode(f.readBytes())?.let { out[idOf(f.name, 500 + i)] = it }
            }
        } catch (e: Throwable) {}
        cache = out
        return out
    }

    private fun decode(b: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 512) s *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }
}
