package com.gzitools

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * Hitung device yang lagi buka GZI TOOLS secara real-time lewat Firebase Realtime Database —
 * buat badge "Pengguna Online" di Beranda. Tiap proses app yang hidup bikin satu node sesi di
 * /presence/{key} (key acak per-sesi dari push(), BUKAN ID device) — jadi ini ngitung "sesi yang
 * lagi kebuka sekarang", bukan "total user unik pernah install", dan gak nyimpen data pribadi
 * apa pun. Node otomatis kehapus sendiri kalau koneksi device putus (app ditutup paksa/di-force
 * stop, HP mati, sinyal ilang) lewat onDisconnect() bawaan Firebase — gak perlu proses logout
 * manual.
 *
 * Semua dibungkus try/catch: kalau Firebase belum disetup (google-services.json belum ada/belum
 * valid) atau device lagi offline, ini cuma gagal diam-diam — fitur lain di app tetap jalan normal,
 * cuma badge online-nya jadi nggak nongol/nggak update.
 */
object Presence {
    private var node: DatabaseReference? = null

    fun start() {
        try {
            val n = FirebaseDatabase.getInstance().getReference("presence").push()
            node = n
            n.setValue(true)
            n.onDisconnect().removeValue()
        } catch (e: Throwable) {
            // Firebase belum siap / offline — biarin, fitur lain tetap jalan.
        }
    }

    fun stop() {
        try { node?.removeValue() } catch (e: Throwable) {}
        node = null
    }

    /** onChange(null) = lagi gagal baca (BUKAN berarti 0 orang online) — tampilkan placeholder, jangan 0. */
    fun listenCount(onChange: (Long?) -> Unit): ValueEventListener? = try {
        val l = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) = onChange(s.childrenCount)
            override fun onCancelled(e: DatabaseError) = onChange(null)
        }
        FirebaseDatabase.getInstance().getReference("presence").addValueEventListener(l)
        l
    } catch (e: Throwable) { null }

    fun removeListener(l: ValueEventListener?) {
        if (l == null) return
        try { FirebaseDatabase.getInstance().getReference("presence").removeEventListener(l) } catch (e: Throwable) {}
    }
}
