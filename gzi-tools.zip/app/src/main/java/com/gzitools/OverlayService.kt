package com.gzitools

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.hardware.display.DisplayManager
import android.view.Display
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/** Crosshair di tengah layar. */
class CrosshairView(ctx: Context) : View(ctx) {
    var style = 0
    var sizeDp = 60
    var colorIdx = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val half = context.dp(sizeDp) / 2f
        val col = COLORS[colorIdx.coerceIn(0, COLORS.size - 1)]
        val sw = context.dp(2).toFloat()
        for (pass in 0..1) {
            p.color = if (pass == 0) Color.argb(200, 0, 0, 0) else col
            p.strokeWidth = if (pass == 0) sw + context.dp(2) else sw
            p.style = Paint.Style.STROKE
            when (style) {
                0 -> {
                    val g = half * 0.25f
                    c.drawLine(cx - half, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + half, cy, p)
                    c.drawLine(cx, cy - half, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + half, p)
                }
                1 -> { p.style = Paint.Style.FILL; c.drawCircle(cx, cy, max(context.dp(3), (half * 0.12f).toInt()).toFloat(), p) }
                else -> {
                    c.drawCircle(cx, cy, half * 0.7f, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy, context.dp(2).toFloat(), p)
                }
            }
        }
    }

    companion object {
        val COLORS = intArrayOf(Color.parseColor("#39FF88"), Color.parseColor("#FF3B3B"), Color.WHITE, Color.parseColor("#FFE24D"))
    }
}

/** Latar panel bergaya p3: sudut terpotong + garis hijau menyala. */
class ChamferBg(private val cut: Float, private val sw: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(236, 4, 14, 10); style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 57, 255, 136); style = Paint.Style.STROKE; strokeWidth = sw * 4 }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.GREEN; style = Paint.Style.STROKE; strokeWidth = sw }
    private val path = Path()
    override fun draw(c: Canvas) {
        val r = RectF(bounds); r.inset(sw * 2, sw * 2)
        path.reset()
        path.moveTo(r.left + cut, r.top); path.lineTo(r.right - cut, r.top); path.lineTo(r.right, r.top + cut)
        path.lineTo(r.right, r.bottom - cut); path.lineTo(r.right - cut, r.bottom); path.lineTo(r.left + cut, r.bottom)
        path.lineTo(r.left, r.bottom - cut); path.lineTo(r.left, r.top + cut); path.close()
        c.drawPath(path, fill); c.drawPath(path, glow); c.drawPath(path, line)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Gauge FPS setengah-lingkaran seperti p3. */
class FpsGauge(ctx: Context) : View(ctx) {
    var fps = -1
    var maxFps = 120
    var note = ""
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.LINE; strokeWidth = ctx.dp(8).toFloat() }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.GREEN; strokeWidth = ctx.dp(8).toFloat() }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(34).toFloat() }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.MUTED; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(10).toFloat() }

    override fun onDraw(c: Canvas) {
        val pad = context.dp(10).toFloat()
        val size = minOf(width.toFloat(), height.toFloat()) - pad * 2
        val l = (width - size) / 2f; val t = (height - size) / 2f
        val rect = RectF(l, t, l + size, t + size)
        c.drawArc(rect, 135f, 270f, false, bg)
        if (fps > 0) c.drawArc(rect, 135f, 270f * (fps.toFloat() / maxFps).coerceIn(0f, 1f), false, fg)
        val cx = width / 2f; val cy = height / 2f
        c.drawText("FPS", cx, cy - size * 0.28f, small)
        c.drawText(if (fps >= 0) fps.toString() else "--", cx, cy + context.dp(10), big)
        val st = when {
            fps < 0 -> note
            fps >= maxFps * 0.85f -> "STABIL"
            else -> "TURUN"
        }
        c.drawText(st, cx, cy + size * 0.36f, small)
    }
}

/** Panel overlay bergaya p3: banner tengah-atas. FPS, CPU, Audio, Kecerahan, Refresh Rate, Crosshair. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var am: AudioManager
    private lateinit var dm: DisplayManager
    private val ui = Handler(Looper.getMainLooper())
    private var pkg = ""
    private var handle: View? = null
    private var panel: View? = null
    private var xh: CrosshairView? = null
    private var open = false
    private var panelAdded = false
    private var started = false
    @Volatile private var running = true
    private lateinit var gauge: FpsGauge
    private lateinit var cpuTv: TextView
    private lateinit var cpuBar: ProgressBar
    private val styleChips = mutableListOf<TextView>()
    private val colorDots = mutableListOf<View>()
    private val hzTiles = mutableListOf<Pair<Int, TextView>>()
    private var rates = setOf<Int>()
    private var curHz = 60
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var layer = ""
    private var fpsMiss = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        store = Store(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (started) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        started = true
        pkg = i?.getStringExtra("pkg") ?: ""
        buildHandle()
        buildPanel()
        refreshCrosshair()
        startLoop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { handle?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { if (panelAdded) wm.removeView(panel) } catch (e: Exception) {}
        try { xh?.let { wm.removeView(it) } } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gzi", "GZI Panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "gzi")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("GZI TOOLS")
            .setContentText("Panel game aktif")
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun lp(w: Int, h: Int, flags: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

    // ---------- Pegangan tepi kiri ----------
    private fun buildHandle() {
        val r = dp(8).toFloat()
        val h = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Pal.GREEN)
                cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
            alpha = 0.4f
        }
        var downX = 0f
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> downX = e.rawX
                MotionEvent.ACTION_MOVE -> if (e.rawX - downX > dp(28)) openPanel()
                MotionEvent.ACTION_UP -> if (abs(e.rawX - downX) < dp(8)) openPanel()
            }
            true
        }
        handle = h
        wm.addView(h, lp(dp(18), dp(120), 0, Gravity.START or Gravity.CENTER_VERTICAL))
    }

    // ---------- Panel ----------
    private fun label(s: String) = tx(s, 10f, Pal.MUTED, true).apply { letterSpacing = 0.15f }

    private fun tint(sb: SeekBar) {
        val g = ColorStateList.valueOf(Pal.GREEN)
        sb.progressTintList = g; sb.thumbTintList = g
        sb.progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
    }

    private fun seek(maxV: Int, cur: Int, on: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        max = maxV; progress = cur.coerceIn(0, maxV); tint(this)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun chip(s: String, onClick: () -> Unit) = tx(s, 15f, Pal.TEXT, true).apply {
        gravity = Gravity.CENTER; setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        rates = dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes.map { Math.round(it.refreshRate) }.toSet()

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(18), dp(30), dp(14))
        }

        // ===== Baris A: audio/kecerahan | gauge FPS + CPU | refresh rate =====
        val rowA = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.add(label("AUDIO"))
        left.add(seek(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) } catch (e: Exception) {}
        }, t = 2)
        left.add(label("KECERAHAN"), t = 12)
        val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
        left.add(seek(255, cur) {
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(1, it))
            } catch (e: Exception) {}
        }, t = 2)
        rowA.add(left, 0, WRAP, 1f, 0, 0, 14)

        val cen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        gauge = FpsGauge(this)
        gauge.maxFps = max(60, rates.maxOrNull() ?: 60)
        cen.add(gauge, dp(150), dp(104))
        cpuTv = tx("CPU --%", 12f, Pal.TEXT, true)
        cen.add(cpuTv, WRAP, WRAP, 0f, 0, 2)
        cpuBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(Pal.GREEN)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
        }
        cen.add(cpuBar, dp(130), dp(5), 0f, 0, 4)
        rowA.add(cen, dp(160), WRAP)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.add(label("REFRESH RATE"))
        val tr = LinearLayout(this)
        listOf(60, 90, 120, 144).forEachIndexed { i, hz ->
            val ok = rates.any { abs(it - hz) <= 1 }
            val t = tx(if (ok) "$hz\nHz" else "$hz\n🔒", 13f, Pal.TEXT, true).apply {
                gravity = Gravity.CENTER
                alpha = if (ok) 1f else 0.4f
                setOnClickListener {
                    if (ok) setRate(hz) else Toast.makeText(this@OverlayService, "$hz Hz tidak didukung HP ini", Toast.LENGTH_SHORT).show()
                }
            }
            hzTiles += hz to t
            tr.add(t, 0, dp(52), 1f, if (i == 0) 0 else 6)
        }
        right.add(tr, t = 6)
        rowA.add(right, 0, WRAP, 1f, 14)
        body.add(rowA)

        // ===== Baris B: crosshair =====
        val rowB = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        rowB.add(label("CROSSHAIR"), WRAP, WRAP, 0f, 0, 0, 8)
        val sw = Switch(this).apply {
            isChecked = store.xhOn
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN, Pal.MUTED))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN_D, Pal.LINE))
            setOnCheckedChangeListener { _, v -> store.xhOn = v; refreshCrosshair() }
        }
        rowB.add(sw, WRAP, WRAP, 0f, 0, 0, 12)
        listOf("＋", "•", "◎").forEachIndexed { i, s ->
            val c = chip(s) { store.xhStyle = i; renderXh(); refreshCrosshair() }
            styleChips += c
            rowB.add(c, dp(38), dp(34), 0f, 0, 0, 6)
        }
        rowB.add(label("UKURAN"), WRAP, WRAP, 0f, 10, 0, 4)
        rowB.add(seek(200, store.xhSize - 20) { store.xhSize = it + 20; refreshCrosshair() }, dp(150), WRAP)
        CrosshairView.COLORS.forEachIndexed { i, colr ->
            val d = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colr) }
                setOnClickListener { store.xhColor = i; renderXh(); refreshCrosshair() }
            }
            colorDots += d
            rowB.add(d, dp(24), dp(24), 0f, if (i == 0) 12 else 8)
        }
        rowB.add(View(this), 0, 1, 1f)
        val off = tx("⏻  Matikan", 12f, Pal.TEXT, true).apply {
            gravity = Gravity.CENTER
            background = shape(Pal.CARD2, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { stopSelf() }
        }
        rowB.add(off, WRAP)
        body.add(rowB, t = 10)

        renderXh()
        renderHz()

        val root = FrameLayout(this).apply {
            background = ChamferBg(dp(22).toFloat(), dp(2).toFloat())
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
            val x = tx("✕", 16f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#C62828")) }
                setOnClickListener { closePanel() }
            }
            addView(x, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(10), dp(16), 0) })
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel(); false }
        }
        panel = root
    }

    private fun renderXh() {
        styleChips.forEachIndexed { i, c ->
            val on = i == store.xhStyle
            c.background = if (on) shape(Pal.GREEN, dp(12).toFloat()) else shape(Pal.CARD2, dp(12).toFloat(), Pal.LINE, dp(1))
            c.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
        colorDots.forEachIndexed { i, d ->
            (d.background as GradientDrawable).setStroke(if (i == store.xhColor) dp(3) else 0, Color.WHITE)
        }
    }

    private fun renderHz() {
        for ((hz, t) in hzTiles) {
            val on = abs(hz - curHz) <= 1
            t.background = if (on) shape(Pal.GREEN, dp(12).toFloat()) else shape(Pal.CARD2, dp(12).toFloat(), Pal.LINE, dp(1))
            t.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
    }

    private fun setRate(hz: Int) {
        curHz = hz; renderHz()
        Thread {
            Sz.sh(
                "settings put system min_refresh_rate $hz.0\n" +
                "settings put system peak_refresh_rate $hz.0\n" +
                "settings put system user_refresh_rate $hz\n" +
                "settings put secure user_refresh_rate $hz"
            )
        }.start()
    }

    private fun openPanel() {
        if (open) return
        val pnl = panel ?: return
        open = true
        curHz = Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate)
        renderHz()
        val w = minOf(resources.displayMetrics.widthPixels - dp(24), dp(860))
        pnl.translationY = -dp(320).toFloat()
        try {
            val p = lp(w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            p.y = dp(4)
            wm.addView(pnl, p)
            panelAdded = true
        } catch (e: Exception) { open = false; return }
        handle?.visibility = View.INVISIBLE
        ValueAnimator.ofFloat(-dp(320).toFloat(), 0f).apply {
            duration = 200
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            start()
        }
    }

    private fun closePanel() {
        if (!open) return
        open = false
        val pnl = panel ?: return
        ValueAnimator.ofFloat(0f, -dp(320).toFloat()).apply {
            duration = 160
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    try { if (panelAdded) wm.removeView(pnl) } catch (e: Exception) {}
                    panelAdded = false
                    handle?.visibility = View.VISIBLE
                }
            })
            start()
        }
    }

    private fun refreshCrosshair() {
        if (!store.xhOn) {
            xh?.let { try { wm.removeView(it) } catch (e: Exception) {} }
            xh = null
            return
        }
        val v = xh ?: CrosshairView(this).also {
            xh = it
            wm.addView(it, lp(dp(240), dp(240), WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, Gravity.CENTER))
        }
        v.style = store.xhStyle; v.sizeDp = store.xhSize; v.colorIdx = store.xhColor
        v.invalidate()
    }

    // ---------- FPS / CPU ----------
    private fun startLoop() {
        Thread {
            val t0 = System.currentTimeMillis()
            var tick = 0
            var misses = 0
            while (running) {
                try {
                    if (open) poll()
                    tick++
                    if (tick % 10 == 0 && System.currentTimeMillis() - t0 > 30000 && pkg.isNotEmpty()) {
                        val r = Sz.sh("pidof $pkg")
                        if (r.isBlank()) misses++ else if (!r.startsWith("ERROR")) misses = 0
                        if (misses >= 2) { ui.post { stopSelf() }; break }
                    }
                    Thread.sleep(1000)
                } catch (e: Throwable) {}
            }
        }.start()
    }

    private fun parseTs(lines: List<String>): List<Long> = lines.mapNotNull {
        val p = it.trim().split(Regex("\\s+"))
        if (p.size == 3) p[1].toLongOrNull() else null
    }.filter { it > 0 && it < Long.MAX_VALUE / 2 }

    /** Uji semua layer milik game, pilih yang paling banyak punya frame. */
    private fun detect() {
        val out = Sz.sh(
            "dumpsys SurfaceFlinger --list | grep -F '$pkg' | while IFS= read -r l; do " +
            "echo \"@L\$l\"; dumpsys SurfaceFlinger --latency \"\$l\"; done"
        ).lines()
        var best = ""
        var bestN = 0
        var name = ""
        val buf = mutableListOf<String>()
        fun flush() {
            if (name.isNotEmpty()) {
                val n = parseTs(buf).size
                if (n >= 2 && n > bestN) { best = name; bestN = n }
            }
        }
        for (ln in out) {
            if (ln.startsWith("@L")) { flush(); name = ln.substring(2); buf.clear() } else buf += ln
        }
        flush()
        layer = best
    }

    private fun poll() {
        if (layer.isEmpty() && pkg.isNotEmpty()) detect()
        val q = layer.replace("'", "'\\''")
        val lat = if (layer.isNotEmpty()) "dumpsys SurfaceFlinger --latency '$q'" else "true"
        val out = Sz.sh("echo @S; head -n1 /proc/stat; echo @F; $lat").lines()
        val si = out.indexOf("@S"); val fi = out.indexOf("@F")
        if (si < 0 || fi < 0) return

        var cpu = -1
        val nums = out.getOrNull(si + 1)?.trim()?.split(Regex("\\s+"))?.drop(1)?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        if (nums.size >= 5) {
            val total = nums.take(8).sum()
            val idle = nums[3] + nums[4]
            if (prevTotal > 0 && total > prevTotal) {
                cpu = (100 * (1.0 - (idle - prevIdle).toDouble() / (total - prevTotal))).toInt().coerceIn(0, 100)
            }
            prevTotal = total; prevIdle = idle
        }

        val ts = parseTs(out.drop(fi + 2))
        var fps = -1
        if (ts.size >= 2) {
            val mx = ts.max()
            fps = ts.count { it >= mx - 1_000_000_000L }
            fpsMiss = 0
        } else if (layer.isNotEmpty()) {
            fpsMiss++
            if (fpsMiss >= 3) { layer = ""; fpsMiss = 0 }
        }

        val note = if (layer.isEmpty()) "MENCARI" else "--"
        ui.post {
            gauge.fps = fps; gauge.note = note; gauge.invalidate()
            cpuTv.text = if (cpu >= 0) "CPU $cpu%" else "CPU --%"
            if (cpu >= 0) cpuBar.progress = cpu
        }
    }
}
