package com.gzitools

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.content.IntentFilter
import android.media.MediaScannerConnection
import android.os.BatteryManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Path
import android.graphics.Point
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.hardware.display.DisplayManager
import android.view.Display
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/** Crosshair di tengah layar. Gaya 0..7 bawaan, >=100 = gambar dari folder crosshair. */
class CrosshairView(ctx: Context) : View(ctx) {
    var style = 0
    var sizeDp = 60
    var colorIdx = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val half = minOf(context.dp(sizeDp) / 2f, minOf(width, height) / 2f - 2f)
        if (style >= 100) {
            val b = XhAssets.all(context)[style] ?: return
            val k = (half * 2f) / maxOf(b.width, b.height)
            val w = b.width * k / 2f; val h = b.height * k / 2f
            c.drawBitmap(b, null, RectF(cx - w, cy - h, cx + w, cy + h), bp)
            return
        }
        val col = COLORS[colorIdx.coerceIn(0, COLORS.size - 1)]
        val sw = context.dp(2).toFloat()
        for (pass in 0..1) {
            p.color = if (pass == 0) Color.argb(200, 0, 0, 0) else col
            p.strokeWidth = if (pass == 0) sw + context.dp(2) else sw
            p.style = Paint.Style.STROKE
            when (style) {
                0 -> {
                    val g = half * 0.25f
                    c.drawLine(cx - half, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + half, cy, p)
                    c.drawLine(cx, cy - half, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + half, p)
                }
                1 -> { p.style = Paint.Style.FILL; c.drawCircle(cx, cy, max(context.dp(3), (half * 0.12f).toInt()).toFloat(), p) }
                2 -> {
                    c.drawCircle(cx, cy, half * 0.7f, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy, context.dp(2).toFloat(), p)
                }
                3 -> { // chevron ^
                    val a = half * 0.6f
                    c.drawLine(cx - a, cy + a * 0.5f, cx, cy - a * 0.5f, p); c.drawLine(cx + a, cy + a * 0.5f, cx, cy - a * 0.5f, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy + a * 0.7f, context.dp(2).toFloat(), p)
                }
                4 -> { // belah ketupat
                    val a = half * 0.6f
                    val d = Path(); d.moveTo(cx, cy - a); d.lineTo(cx + a, cy); d.lineTo(cx, cy + a); d.lineTo(cx - a, cy); d.close()
                    c.drawPath(d, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy, context.dp(2).toFloat(), p)
                }
                5 -> { // cincin + garis pendek
                    val r = half * 0.55f
                    c.drawCircle(cx, cy, r, p)
                    c.drawLine(cx - half, cy, cx - r - half * 0.1f, cy, p); c.drawLine(cx + r + half * 0.1f, cy, cx + half, cy, p)
                    c.drawLine(cx, cy - half, cx, cy - r - half * 0.1f, p); c.drawLine(cx, cy + r + half * 0.1f, cx, cy + half, p)
                }
                6 -> { // bentuk T (tanpa garis atas)
                    val g = half * 0.2f
                    c.drawLine(cx - half, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + half, cy, p)
                    c.drawLine(cx, cy + g, cx, cy + half, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy, context.dp(2).toFloat(), p)
                }
                else -> { // silang X
                    val a = half * 0.55f; val g = half * 0.15f
                    c.drawLine(cx - a, cy - a, cx - g, cy - g, p); c.drawLine(cx + a, cy + a, cx + g, cy + g, p)
                    c.drawLine(cx + a, cy - a, cx + g, cy - g, p); c.drawLine(cx - a, cy + a, cx - g, cy + g, p)
                }
            }
        }
    }

    companion object {
        val COLORS = intArrayOf(Color.parseColor("#39FF88"), Color.parseColor("#FF3B3B"), Color.WHITE, Color.parseColor("#FFE24D"))
        const val BUILTIN = 8
    }
}

/** Gauge FPS setengah-lingkaran seperti p3. */
class FpsGauge(ctx: Context) : View(ctx) {
    var fps = -1
    var maxFps = 120
    var note = ""
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.LINE; strokeWidth = ctx.dp(8).toFloat() }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.GREEN; strokeWidth = ctx.dp(8).toFloat() }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(34).toFloat() }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.MUTED; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(10).toFloat() }

    override fun onDraw(c: Canvas) {
        val pad = context.dp(10).toFloat()
        val size = minOf(width.toFloat(), height.toFloat()) - pad * 2
        val l = (width - size) / 2f; val t = (height - size) / 2f
        val rect = RectF(l, t, l + size, t + size)
        c.drawArc(rect, 135f, 270f, false, bg)
        if (fps > 0) c.drawArc(rect, 135f, 270f * (fps.toFloat() / maxFps).coerceIn(0f, 1f), false, fg)
        val cx = width / 2f; val cy = height / 2f
        c.drawText("FPS", cx, cy - size * 0.28f, small)
        c.drawText(if (fps >= 0) fps.toString() else "--", cx, cy + context.dp(10), big)
        val st = when {
            fps < 0 -> note
            fps >= maxFps * 0.85f -> "STABIL"
            else -> "TURUN"
        }
        c.drawText(st, cx, cy + size * 0.36f, small)
    }
}

/** Tile segi enam bergaya p3. */
class HexTile(ctx: Context, var glyph: String, var sub: String) : View(ctx) {
    var lit = false
        set(v) { field = v; invalidate() }
    var locked = false
        set(v) { field = v; alpha = if (v) 0.45f else 1f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Pal.GREEN }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(90, 57, 255, 136) }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dp(17).toFloat(); color = Pal.TEXT; typeface = ctx.head() }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dp(9).toFloat(); color = Pal.MUTED; typeface = ctx.head() }
    private val path = Path()
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val r = w / 2f - context.dp(3)
        val hh = r * 0.866f
        val cx = w / 2f
        val cy = hh + context.dp(3)
        path.reset()
        path.moveTo(cx - r, cy); path.lineTo(cx - r / 2, cy - hh); path.lineTo(cx + r / 2, cy - hh)
        path.lineTo(cx + r, cy); path.lineTo(cx + r / 2, cy + hh); path.lineTo(cx - r / 2, cy + hh)
        path.close()
        fill.color = if (lit) Color.argb(255, 15, 107, 58) else Pal.CARD2
        c.drawPath(path, fill)
        if (lit) { glow.strokeWidth = context.dp(5).toFloat(); c.drawPath(path, glow) }
        ln.strokeWidth = context.dp(if (lit) 2 else 1).toFloat()
        c.drawPath(path, ln)
        c.drawText(glyph, cx, cy + gp.textSize * 0.35f, gp)
        c.drawText(sub, cx, cy + hh + context.dp(13), sp)
    }
}

/**
 * Panel overlay bergaya p3: banner tengah-atas dengan tile segi enam.
 * Hanya tampil saat game di depan; kalau game ditinggal > 5 menit, grafis dikembalikan ke asli.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var am: AudioManager
    private lateinit var dm: DisplayManager
    private val ui = Handler(Looper.getMainLooper())
    private var pkg = ""
    private var handle: View? = null
    private var panel: View? = null
    private var xh: CrosshairView? = null
    private var open = false
    private var panelAdded = false
    private var started = false
    private var hasUi = false
    @Volatile private var running = true
    @Volatile private var inGame = false
    private var awaySince = 0L
    private lateinit var gauge: FpsGauge
    private lateinit var cpuTv: TextView
    private lateinit var cpuBar: ProgressBar
    private lateinit var detail: LinearLayout
    private lateinit var audioRow: View
    private lateinit var brightRow: View
    private lateinit var xhRow: View
    private lateinit var sensiRow: View
    private lateinit var notice: TextView
    private lateinit var resoTv: TextView
    private lateinit var focusTile: HexTile
    private lateinit var recTile: HexTile
    private lateinit var infoTv: TextView
    private lateinit var pingTv: TextView
    private var recording = false
    private var recFile = ""
    private var pollN = 0
    private lateinit var edW: android.widget.EditText
    private lateinit var edH: android.widget.EditText
    private lateinit var edD: android.widget.EditText
    private var resoLabel = ""
    private var panelLp: WindowManager.LayoutParams? = null
    private var focusMiss = 0
    private val tiles = mutableListOf<HexTile>()
    private val styleChips = mutableListOf<Pair<Int, View>>()
    private val colorDots = mutableListOf<View>()
    private val hzTiles = mutableListOf<Pair<Int, HexTile>>()
    private var sel = -1
    private var rates = setOf<Int>()
    private var curHz = 60
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var layer = ""
    private var fpsMiss = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        store = Store(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (started) return START_NOT_STICKY
        started = true
        pkg = i?.getStringExtra("pkg") ?: ""
        val wantUi = i?.getBooleanExtra("ov", true) ?: true
        if (wantUi && Settings.canDrawOverlays(this)) {
            try {
                buildHandle()
                buildPanel()
                hasUi = true
                refreshCrosshair()
            } catch (e: Throwable) { hasUi = handle != null && panel != null }
        }
        awaySince = System.currentTimeMillis()
        startLoop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { handle?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { if (panelAdded) wm.removeView(panel) } catch (e: Exception) {}
        try { xh?.let { wm.removeView(it) } } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gzi", "GZI Panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "gzi")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("GZI TOOLS")
            .setContentText("Panel game aktif")
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, n)
        } catch (e: Throwable) {}
    }

    private fun screen(): Point {
        val p = Point()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealSize(p)
        return p
    }

    private fun lp(w: Int, h: Int, flags: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

    // ---------- Pegangan: mentok kiri, agak atas, bisa digeser naik-turun ----------
    private fun buildHandle() {
        val hH = dp(76)
        val r = dp(7).toFloat()
        val h = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Pal.GREEN)
                cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
            alpha = 0.35f
            visibility = View.GONE
        }
        val hp = lp(dp(14), hH, 0, Gravity.START or Gravity.TOP)
        hp.x = 0
        hp.y = if (store.hy >= 0) store.hy else (screen().y * 0.16f).toInt()
        var downX = 0f; var downY = 0f; var startY = 0; var moving = false
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = hp.y; moving = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (dx > dp(28) && abs(dy) < dp(40)) {
                        if (!moving) openPanel()
                    } else if (abs(dy) > dp(12) && abs(dx) < dp(28)) {
                        moving = true
                        hp.y = (startY + dy).toInt().coerceIn(0, max(0, screen().y - hH))
                        try { wm.updateViewLayout(h, hp) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moving) store.hy = hp.y
                    else if (abs(e.rawX - downX) < dp(8) && abs(e.rawY - downY) < dp(8)) openPanel()
                }
            }
            true
        }
        handle = h
        wm.addView(h, hp)
    }

    // ---------- Panel ----------
    private fun label(s: String) = tx(s, 10f, Pal.MUTED, true).apply { letterSpacing = 0.15f }

    private fun tint(sb: SeekBar) {
        val g = ColorStateList.valueOf(Pal.GREEN)
        sb.progressTintList = g; sb.thumbTintList = g
        sb.progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
    }

    private fun seek(maxV: Int, cur: Int, done: (Int) -> Unit = {}, on: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        max = maxV; progress = cur.coerceIn(0, maxV); tint(this)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { done(s?.progress ?: 0) }
        })
    }

    /** Notifikasi sukses: toast + baris hijau di dalam panel. */
    private fun ok(msg: String) {
        ui.post {
            Toast.makeText(this, "✔ SUCCES · $msg", Toast.LENGTH_SHORT).show()
            if (::notice.isInitialized) {
                notice.text = "✔  SUCCES  ·  $msg"
                notice.visibility = View.VISIBLE
                ui.removeCallbacks(hideNotice)
                ui.postDelayed(hideNotice, 2300)
            }
        }
    }
    private val hideNotice = Runnable { if (::notice.isInitialized) notice.visibility = View.GONE }

    private fun rowBox(vertical: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = shape(Pal.CARD2, dp(16).toFloat(), Pal.LINE, dp(1))
        setPadding(dp(14), dp(8), dp(14), dp(8))
        visibility = View.GONE
    }

    private fun tile(g: String, s: String): HexTile = HexTile(this, g, s)

    private fun buildPanel() {
        val disp = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val cm = disp.mode
        val same = disp.supportedModes.filter { it.physicalWidth == cm.physicalWidth && it.physicalHeight == cm.physicalHeight }
        rates = (if (same.isEmpty()) disp.supportedModes.toList() else same).map { Math.round(it.refreshRate) }.toSet()
        val tw = dp(58); val th = dp(76)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(34), dp(30), dp(12))
        }

        // ===== Baris tile: [Audio][Kecerahan][Crosshair][Sensi] | gauge | [60][90][120][144] =====
        val rowA = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val l1 = LinearLayout(this)
        val defs = listOf("🔊" to "AUDIO", "☀" to "KECERAHAN", "⊕" to "CROSSHAIR", "📐" to "RESO")
        defs.forEachIndexed { i, (g, s) ->
            val t = tile(g, s)
            t.setOnClickListener { sel = if (sel == i) -1 else i; renderSel() }
            tiles += t
            l1.add(t, tw, th, 0f, 0, 0, 4)
        }
        left.add(l1)
        val l2 = LinearLayout(this)
        focusTile = tile("🔕", "FOKUS").apply { lit = store.focusOn; setOnClickListener { toggleFocus() } }
        val ramTile = tile("🧹", "RAM").apply { setOnClickListener { cleanRam() } }
        val shotTile = tile("📸", "FOTO").apply { setOnClickListener { screenshot() } }
        recTile = tile("⏺", "REKAM").apply { setOnClickListener { toggleRec() } }
        for (t in listOf(focusTile, ramTile, shotTile, recTile)) l2.add(t, tw, th, 0f, 0, 0, 4)
        left.add(l2, t = 2)
        rowA.add(left, WRAP, WRAP)
        rowA.add(View(this), 0, 1, 1f)

        val cen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        gauge = FpsGauge(this)
        gauge.maxFps = max(60, rates.maxOrNull() ?: 60)
        cen.add(gauge, dp(140), dp(92))
        cpuTv = tx("CPU --%", 12f, Pal.TEXT, true)
        cen.add(cpuTv, WRAP, WRAP, 0f, 0, 0)
        cpuBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(Pal.GREEN)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
        }
        cen.add(cpuBar, dp(120), dp(5), 0f, 0, 4)
        infoTv = tx("", 10f, Pal.TEXT, true).apply { gravity = Gravity.CENTER }
        pingTv = tx("PING --", 10f, Pal.MUTED, true).apply { gravity = Gravity.CENTER }
        cen.add(infoTv, WRAP, WRAP, 0f, 0, 6)
        cen.add(pingTv, WRAP, WRAP, 0f, 0, 2)
        rowA.add(cen, WRAP, WRAP, 0f, 8, 0, 8)
        rowA.add(View(this), 0, 1, 1f)

        val right = LinearLayout(this)
        listOf(60, 90, 120, 144).forEach { hz ->
            val ok = rates.any { abs(it - hz) <= 1 }
            val t = if (ok) tile("$hz", "Hz") else tile("🔒", "$hz Hz")
            t.locked = !ok
            t.setOnClickListener {
                if (ok) setRate(hz)
                else toast("$hz Hz tidak didukung HP ini")
            }
            hzTiles += hz to t
            right.add(t, tw, th, 0f, 4, 0, 0)
        }
        rowA.add(right, WRAP, WRAP)
        body.add(rowA)

        // ===== Detail (muncul setelah tile ditekan) =====
        detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        val ar = rowBox()
        ar.add(tx("🔊", 16f), WRAP, WRAP, 0f, 0, 0, 10)
        ar.add(seek(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC), {
            ok("Volume ${it * 100 / max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))}%")
        }) {
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) } catch (e: Exception) {}
        }, 0, WRAP, 1f)
        audioRow = ar; detail.add(ar)

        val br = rowBox()
        br.add(tx("☀", 16f), WRAP, WRAP, 0f, 0, 0, 10)
        val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
        br.add(seek(255, cur, { ok("Kecerahan ${it * 100 / 255}%") }) {
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(1, it))
            } catch (e: Exception) {}
        }, 0, WRAP, 1f)
        brightRow = br; detail.add(br)

        // ----- crosshair: baris 1 = switch + pilihan gaya, baris 2 = ukuran + warna -----
        val xr = rowBox(true)
        val x1 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        x1.add(label("CROSSHAIR"), WRAP, WRAP, 0f, 0, 0, 8)
        val sw = Switch(this).apply {
            isChecked = store.xhOn
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN, Pal.MUTED))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN_D, Pal.LINE))
            setOnCheckedChangeListener { _, v -> store.xhOn = v; refreshCrosshair(); ok(if (v) "Crosshair aktif" else "Crosshair dimatikan") }
        }
        x1.add(sw, WRAP, WRAP, 0f, 0, 0, 10)
        val strip = LinearLayout(this)
        val ids = (0 until CrosshairView.BUILTIN).toList() + XhAssets.all(this).keys.toList()
        ids.forEach { id ->
            val cv = CrosshairView(this).apply { style = id; sizeDp = 24; colorIdx = 0 }
            val chip = FrameLayout(this).apply {
                addView(cv, FrameLayout.LayoutParams(MATCH, MATCH))
                setOnClickListener { store.xhStyle = id; renderXh(); refreshCrosshair(); ok("Crosshair gaya ${if (id >= 100) "gambar " + (id - 100) else (id + 1).toString()}") }
            }
            styleChips += id to chip
            strip.add(chip, dp(42), dp(34), 0f, 0, 0, 6)
        }
        val hs = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }
        x1.add(hs, 0, WRAP, 1f)
        xr.add(x1)
        val x2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        x2.add(label("UKURAN"), WRAP, WRAP, 0f, 0, 0, 6)
        x2.add(seek(200, store.xhSize - 20, { ok("Ukuran crosshair ${store.xhSize}") }) { store.xhSize = it + 20; refreshCrosshair() }, 0, WRAP, 1f)
        CrosshairView.COLORS.forEachIndexed { i, colr ->
            val d = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colr) }
                setOnClickListener { store.xhColor = i; renderXh(); refreshCrosshair(); ok("Warna crosshair diganti") }
            }
            colorDots += d
            x2.add(d, dp(24), dp(24), 0f, if (i == 0) 12 else 8)
        }
        xr.add(x2, t = 4)
        xhRow = xr; detail.add(xr)

        // ----- resolusi layar -----
        val sr = rowBox(true)
        val rl = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        rl.add(label("RESOLUSI"), WRAP, WRAP, 0f, 0, 0, 10)
        resoTv = tx("", 12f, Pal.GREEN, true)
        rl.add(resoTv, 0, WRAP, 1f)
        rl.add(tx("↺ RESET", 11f, Pal.GREEN, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = shape(Pal.CARD, dp(12).toFloat(), Pal.GREEN_D, dp(1))
            setOnClickListener { undoReso() }
        }, WRAP)
        sr.add(rl)
        // input angka: lebar x tinggi, density
        fun field(hint: String): android.widget.EditText = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI or android.view.inputmethod.EditorInfo.IME_ACTION_DONE
            setTextColor(Pal.TEXT); setHintTextColor(Pal.MUTED); textSize = 14f; typeface = body()
            gravity = Gravity.CENTER; setSingleLine(true); this.hint = hint
            background = shape(Pal.CARD, dp(12).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_DOWN) this@OverlayService.panelFocus(true)
                if (e.action == MotionEvent.ACTION_UP) v.post {
                    v.requestFocus()
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(v, 0)
                }
                false
            }
        }
        edW = field("Lebar"); edH = field("Tinggi"); edD = field("Density")
        val ir = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        ir.add(edW, dp(84), dp(38))
        ir.add(tx("×", 16f, Pal.GREEN, true), WRAP, WRAP, 0f, 6, 0, 6)
        ir.add(edH, dp(84), dp(38))
        ir.add(tx("DPI", 11f, Pal.MUTED, true), WRAP, WRAP, 0f, 12, 0, 6)
        ir.add(edD, dp(70), dp(38))
        ir.add(tx("TERAPKAN", 12f, Pal.ON_GREEN, true).apply {
            gravity = Gravity.CENTER
            background = shape(Pal.GREEN, dp(12).toFloat())
            setPadding(dp(14), dp(9), dp(14), dp(9))
            setOnClickListener { applyCustom() }
        }, WRAP, WRAP, 0f, 12)
        sr.add(ir, t = 8)
        sr.add(tx("Isi lebar × tinggi dan DPI lalu TERAPKAN. RESET mengembalikan ke pengaturan yang diterapkan sebelumnya (otomatis kembali normal kalau game ditinggal > 5 menit).", 10f, Pal.MUTED), t = 6)
        renderReso()
        sensiRow = sr; detail.add(sr)
        notice = tx("", 12f, Pal.ON_GREEN, true).apply {
            gravity = Gravity.CENTER
            background = shape(Pal.GREEN, dp(12).toFloat())
            setPadding(dp(12), dp(7), dp(12), dp(7))
            visibility = View.GONE
        }
        body.add(detail, t = 6)
        body.add(notice, t = 8)

        renderXh(); renderHz(); renderSel()

        val root = FrameLayout(this).apply {
            background = ChamferBg(dp(22).toFloat(), dp(2).toFloat())
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
            val x = tx("✕", 16f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#C62828")) }
                setOnClickListener { closePanel() }
            }
            addView(x, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(14), 0) })
            val pw = tx("⏻", 15f, Pal.GREEN, true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Pal.CARD2); setStroke(dp(1), Pal.GREEN_D) }
                setOnClickListener { Toast.makeText(this@OverlayService, "Panel dimatikan", Toast.LENGTH_SHORT).show(); stopSelf() }
            }
            addView(pw, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(50), 0) })
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel(); false }
        }
        panel = root
    }

    private fun renderSel() {
        tiles.forEachIndexed { i, t -> t.lit = (i == sel) || (i == 3 && store.resoPct < 100 && sel != 3) }
        detail.visibility = if (sel in 0..3) View.VISIBLE else View.GONE
        sensiRow.visibility = if (sel == 3) View.VISIBLE else View.GONE
        audioRow.visibility = if (sel == 0) View.VISIBLE else View.GONE
        brightRow.visibility = if (sel == 1) View.VISIBLE else View.GONE
        xhRow.visibility = if (sel == 2) View.VISIBLE else View.GONE
    }

    private fun renderXh() {
        styleChips.forEach { (id, c) ->
            val on = id == store.xhStyle
            c.background = if (on) shape(Pal.GREEN_D, dp(12).toFloat(), Pal.GREEN, dp(2)) else shape(Pal.CARD, dp(12).toFloat(), Pal.LINE, dp(1))
        }
        colorDots.forEachIndexed { i, d ->
            (d.background as GradientDrawable).setStroke(if (i == store.xhColor) dp(3) else 0, Color.WHITE)
        }
    }

    private fun renderHz() {
        for ((hz, t) in hzTiles) t.lit = !t.locked && abs(hz - curHz) <= 1
    }

    private fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    /** Ganti refresh rate di beberapa jalur sekaligus, lalu cek hasilnya di layar sebelum memberi kabar. */
    private fun setRate(hz: Int) {
        // minta mode layar yang cocok lewat jendela overlay juga
        try {
            val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
            val cm = d.mode
            val m = d.supportedModes.filter { it.physicalWidth == cm.physicalWidth && it.physicalHeight == cm.physicalHeight }
                .minByOrNull { abs(it.refreshRate - hz) }
            if (m != null) for (v in listOfNotNull(handle, xh, if (panelAdded) panel else null)) {
                val p = v.layoutParams as? WindowManager.LayoutParams ?: continue
                p.preferredDisplayModeId = m.modeId
                p.preferredRefreshRate = m.refreshRate
                try { wm.updateViewLayout(v, p) } catch (e: Exception) {}
            }
        } catch (e: Throwable) {}
        val samsung = if (hz > 60) 2 else 1
        Thread {
            Sz.sh(
                "settings put system min_refresh_rate $hz.0\n" +
                "settings put system peak_refresh_rate $hz.0\n" +
                "settings put system user_refresh_rate $hz\n" +
                "settings put secure user_refresh_rate $hz\n" +
                "settings put system miui_refresh_rate $hz\n" +
                "settings put secure miui_refresh_rate $hz\n" +
                "settings put secure refresh_rate_mode $samsung\n" +
                "settings put system refresh_rate_mode $samsung"
            )
            try { Thread.sleep(2000) } catch (e: InterruptedException) {}
            val now = Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate)
            ui.post {
                curHz = now; renderHz()
                if (abs(now - hz) <= 1) ok("Berhasil pindah ke $hz Hz")
                else toast("Gagal pindah ke $hz Hz (ditolak sistem/game). Sekarang $now Hz")
            }
        }.start()
    }

    private fun renderReso() {
        resoTv.text = if (store.resoPct >= 100 || resoLabel.isEmpty()) "ASLI" else resoLabel
    }

    private fun panelFocus(on: Boolean) {
        val p = panelLp ?: return
        val pnl = panel ?: return
        if (!panelAdded) return
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val nf = if (on) p.flags and f.inv() else p.flags or f
        if (nf == p.flags) return
        p.flags = nf
        try { wm.updateViewLayout(pnl, p) } catch (e: Exception) {}
        if (!on) try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(pnl.windowToken, 0)
        } catch (e: Exception) {}
    }

    private fun loadReso() {
        Thread {
            val c = Engine.readDisplay() ?: return@Thread
            ui.post { edW.setText(c[0]); edH.setText(c[1]); edD.setText(c[2]) }
        }.start()
    }

    private fun applyCustom() {
        val w = edW.text.toString().toIntOrNull(); val h = edH.text.toString().toIntOrNull()
        val d = edD.text.toString().toIntOrNull() ?: 0
        if (w == null || h == null) { toast("Isi lebar dan tinggi (angka)"); return }
        panelFocus(false)
        Thread {
            val before = Engine.readDisplay()
            val (good, msg) = Engine.setCustom(w, h, d)
            ui.post {
                if (good) {
                    if (store.resoBase.isEmpty() && before != null) store.resoBase = before.joinToString(",")
                    store.resoPct = 99; resoLabel = msg
                    renderReso(); renderSel(); loadReso()
                    ok("Resolusi $msg aktif")
                } else toast(msg)
            }
        }.start()
    }

    /** RESET: kembali ke keadaan sebelum aplikasi mengubah (mis. DPI yang kamu atur sendiri di pengaturan). */
    private fun undoReso() {
        if (store.resoBase.isEmpty()) { toast("Belum ada perubahan dari aplikasi"); return }
        Thread {
            val r = Engine.restoreBase(this)
            ui.post {
                if (r != null) {
                    store.resoPct = 100; resoLabel = ""
                    renderReso(); renderSel(); loadReso()
                    ok("Resolusi kembali ke pengaturan awal ($r)")
                } else toast("Gagal mengembalikan. Pastikan Shizuku aktif.")
            }
        }.start()
    }

    // ---------- Alat cepat ----------
    private fun stamp() = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    private fun toggleFocus() {
        val want = !store.focusOn
        Thread {
            val good = Engine.focus(this, want)
            ui.post {
                if (good) { focusTile.lit = want; ok(if (want) "Mode Fokus aktif · notifikasi dibisukan" else "Mode Fokus dimatikan") }
                else toast("Gagal mengubah Mode Fokus")
            }
        }.start()
    }

    private fun memFree(): Long {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1048576L
    }

    private fun cleanRam() {
        toast("Membersihkan RAM...")
        Thread {
            val before = memFree()
            Sz.sh("am kill-all")
            try { Thread.sleep(1500) } catch (e: InterruptedException) {}
            val after = memFree()
            val gain = after - before
            ok(if (gain > 0) "RAM dibersihkan · +$gain MB (kini $after MB bebas)" else "RAM sudah bersih · $after MB bebas")
        }.start()
    }

    private fun screenshot() {
        val wasOpen = open
        if (open) closePanel()
        Thread {
            try { Thread.sleep(if (wasOpen) 450L else 60L) } catch (e: InterruptedException) {}
            val f = "/sdcard/Pictures/GZI TOOLS/GZI_${stamp()}.png"
            val o = Sz.sh("mkdir -p '/sdcard/Pictures/GZI TOOLS'\nscreencap -p '$f'\nls '$f'")
            if (o.startsWith("ERROR") || o.contains("No such", true) || !o.contains("GZI_")) { toast("Gagal mengambil screenshot"); return@Thread }
            MediaScannerConnection.scanFile(this, arrayOf(f), arrayOf("image/png"), null)
            ok("Screenshot tersimpan di Pictures/GZI TOOLS")
        }.start()
    }

    private val recEnd = Runnable { if (recording) stopRec(false) }

    private fun toggleRec() {
        if (recording) { stopRec(true); return }
        if (open) closePanel()
        val f = "/sdcard/Movies/GZI TOOLS/GZI_${stamp()}.mp4"
        recFile = f
        Thread {
            try { Thread.sleep(450) } catch (e: InterruptedException) {}
            Sz.sh("mkdir -p '/sdcard/Movies/GZI TOOLS'\n(screenrecord --time-limit 180 --bit-rate 8000000 '$f' </dev/null >/dev/null 2>&1 &)")
            ui.post {
                recording = true; recTile.lit = true
                ok("Rekam layar dimulai (maks. 3 menit)")
                ui.postDelayed(recEnd, 183000)
            }
        }.start()
    }

    private fun stopRec(manual: Boolean) {
        ui.removeCallbacks(recEnd)
        val f = recFile
        Thread {
            if (manual) Sz.sh("pkill -2 screenrecord || killall -2 screenrecord")
            try { Thread.sleep(1800) } catch (e: InterruptedException) {}
            MediaScannerConnection.scanFile(this, arrayOf(f), arrayOf("video/mp4"), null)
            ui.post { recording = false; recTile.lit = false; ok("Rekaman tersimpan di Movies/GZI TOOLS") }
        }.start()
    }

    private fun battText(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = max(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val chg = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0) == BatteryManager.BATTERY_STATUS_CHARGING
        infoTv.setTextColor(if (t >= 45f) Pal.BAD else if (t >= 42f) Pal.WARN else Pal.TEXT)
        return "🌡 " + String.format(java.util.Locale.US, "%.1f", t) + "°C · 🔋 " + (lv * 100 / sc) + "%" + (if (chg) " ⚡" else "")
    }

    private fun pingOnce() {
        Thread {
            val o = Sz.sh("ping -c 1 -W 2 1.1.1.1")
            val ms = Regex("time=([0-9.]+)").find(o)?.groupValues?.get(1)?.toFloatOrNull()
            ui.post {
                if (ms != null) {
                    pingTv.text = "PING ${ms.toInt()} ms"
                    pingTv.setTextColor(if (ms < 60f) Pal.GREEN else if (ms < 120f) Pal.WARN else Pal.BAD)
                } else { pingTv.text = "PING --"; pingTv.setTextColor(Pal.MUTED) }
            }
        }.start()
    }

    private fun openPanel() {
        if (open || !inGame) return
        val pnl = panel ?: return
        open = true
        curHz = Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate)
        renderHz()
        val w = minOf(screen().x - dp(24), dp(800))
        pnl.translationY = -dp(320).toFloat()
        try {
            val p = lp(w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            p.y = dp(4)
            wm.addView(pnl, p)
            panelLp = p
            panelAdded = true
        } catch (e: Exception) { open = false; return }
        handle?.visibility = View.INVISIBLE
        loadReso()
        infoTv.text = battText()
        ValueAnimator.ofFloat(-dp(320).toFloat(), 0f).apply {
            duration = 200
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            start()
        }
    }

    private fun closePanel() {
        if (!open) return
        panelFocus(false)
        open = false
        val pnl = panel ?: return
        ValueAnimator.ofFloat(0f, -dp(320).toFloat()).apply {
            duration = 160
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    try { if (panelAdded) wm.removeView(pnl) } catch (e: Exception) {}
                    panelAdded = false
                    handle?.visibility = if (inGame) View.VISIBLE else View.GONE
                }
            })
            start()
        }
    }

    private fun forceClose() {
        if (panelAdded) { try { wm.removeView(panel) } catch (e: Exception) {}; panelAdded = false }
        open = false
    }

    /** Panel, pegangan, dan crosshair hanya tampil saat game di depan. */
    private fun applyVisibility() {
        if (!hasUi) return
        if (!inGame) {
            forceClose()
            handle?.visibility = View.GONE
            xh?.visibility = View.GONE
        } else {
            handle?.visibility = if (open) View.INVISIBLE else View.VISIBLE
            xh?.visibility = View.VISIBLE
        }
    }

    private fun refreshCrosshair() {
        if (!store.xhOn) {
            xh?.let { try { wm.removeView(it) } catch (e: Exception) {} }
            xh = null
            return
        }
        val v = xh ?: CrosshairView(this).also {
            xh = it
            wm.addView(it, lp(dp(240), dp(240), WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, Gravity.CENTER))
        }
        v.visibility = if (inGame) View.VISIBLE else View.GONE
        v.style = if (store.xhStyle >= 100 && !XhAssets.all(this).containsKey(store.xhStyle)) 0 else store.xhStyle
        v.sizeDp = minOf(store.xhSize, 230); v.colorIdx = store.xhColor
        v.invalidate()
    }

    // ---------- Loop: fokus game, FPS/CPU, auto-kembali ke asli ----------
    private fun startLoop() {
        Thread {
            var tick = 0
            while (running) {
                try {
                    tick++
                    if (tick == 1 || tick % 2 == 0) checkFocus()
                    if (open && inGame) poll()
                    if (!inGame && awaySince > 0 && System.currentTimeMillis() - awaySince >= AWAY_LIMIT_MS) {
                        Engine.revertAll(this, pkg)
                        ui.post { stopSelf() }
                        break
                    }
                    Thread.sleep(1000)
                } catch (e: Throwable) {}
            }
        }.start()
    }

    /** Deteksi game di depan, dengan beberapa jalur cadangan supaya jalan di Android apa pun. */
    private fun checkFocus() {
        if (pkg.isEmpty()) return
        var r = Sz.sh("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -n3")
        var known = !(r.startsWith("ERROR") || r.isBlank())
        if (!known) {
            r = Sz.sh("dumpsys activity activities | grep -E 'ResumedActivity|mResumedActivity|topResumedActivity' | head -n3")
            known = !(r.startsWith("ERROR") || r.isBlank())
        }
        val g: Boolean
        if (known) {
            focusMiss = 0
            if (open && r.contains(packageName)) return // sedang mengetik di panel
            val onlyNull = r.lines().all { !it.contains("/") && !it.contains(pkg) }
            if (onlyNull && inGame) return // transisi sesaat, pertahankan status
            g = r.contains(pkg)
        } else {
            focusMiss++
            if (focusMiss < 3) return
            g = true // sistem tidak bisa ditanya: anggap game aktif agar panel tetap muncul
        }
        if (g != inGame) {
            inGame = g
            awaySince = if (g) 0L else System.currentTimeMillis()
            if (!g) layer = ""
            ui.post { applyVisibility() }
        }
    }

    private fun parseTs(lines: List<String>): List<Long> = lines.mapNotNull {
        val p = it.trim().split(Regex("\\s+"))
        if (p.size == 3) p[1].toLongOrNull() else null
    }.filter { it > 0 && it < Long.MAX_VALUE / 2 }

    /** Uji semua layer milik game, pilih yang paling banyak punya frame. */
    private fun detect() {
        val out = Sz.sh(
            "dumpsys SurfaceFlinger --list | grep -F '$pkg' | while IFS= read -r l; do " +
            "echo \"@L\$l\"; dumpsys SurfaceFlinger --latency \"\$l\"; done"
        ).lines()
        var best = ""
        var bestN = 0
        var name = ""
        val buf = mutableListOf<String>()
        fun flush() {
            if (name.isNotEmpty()) {
                val n = parseTs(buf).size
                if (n >= 2 && n > bestN) { best = name; bestN = n }
            }
        }
        for (ln in out) {
            if (ln.startsWith("@L")) { flush(); name = ln.substring(2); buf.clear() } else buf += ln
        }
        flush()
        layer = best
    }

    private fun poll() {
        pollN++
        if (pollN % 5 == 1) pingOnce()
        if (layer.isEmpty() && pkg.isNotEmpty()) detect()
        val q = layer.replace("'", "'\\''")
        val lat = if (layer.isNotEmpty()) "dumpsys SurfaceFlinger --latency '$q'" else "true"
        val out = Sz.sh("echo @S; head -n1 /proc/stat; echo @F; $lat").lines()
        val si = out.indexOf("@S"); val fi = out.indexOf("@F")
        if (si < 0 || fi < 0) return

        var cpu = -1
        val nums = out.getOrNull(si + 1)?.trim()?.split(Regex("\\s+"))?.drop(1)?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        if (nums.size >= 5) {
            val total = nums.take(8).sum()
            val idle = nums[3] + nums[4]
            if (prevTotal > 0 && total > prevTotal) {
                cpu = (100 * (1.0 - (idle - prevIdle).toDouble() / (total - prevTotal))).toInt().coerceIn(0, 100)
            }
            prevTotal = total; prevIdle = idle
        }

        val ts = parseTs(out.drop(fi + 2))
        var fps = -1
        if (ts.size >= 2) {
            val mx = ts.max()
            fps = ts.count { it >= mx - 1_000_000_000L }
            fpsMiss = 0
        } else if (layer.isNotEmpty()) {
            fpsMiss++
            if (fpsMiss >= 3) { layer = ""; fpsMiss = 0 }
        }

        val note = if (layer.isEmpty()) "MENCARI" else "--"
        ui.post {
            gauge.fps = fps; gauge.note = note; gauge.invalidate()
            cpuTv.text = if (cpu >= 0) "CPU $cpu%" else "CPU --%"
            if (cpu >= 0) cpuBar.progress = cpu
            infoTv.text = battText()
        }
    }

    companion object {
        const val AWAY_LIMIT_MS = 5 * 60 * 1000L
    }
}
