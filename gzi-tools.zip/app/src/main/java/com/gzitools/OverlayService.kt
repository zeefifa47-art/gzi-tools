package com.gzitools

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Path
import android.graphics.Point
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.hardware.display.DisplayManager
import android.view.Display
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/** Crosshair di tengah layar. */
class CrosshairView(ctx: Context) : View(ctx) {
    var style = 0
    var sizeDp = 60
    var colorIdx = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val half = context.dp(sizeDp) / 2f
        val col = COLORS[colorIdx.coerceIn(0, COLORS.size - 1)]
        val sw = context.dp(2).toFloat()
        for (pass in 0..1) {
            p.color = if (pass == 0) Color.argb(200, 0, 0, 0) else col
            p.strokeWidth = if (pass == 0) sw + context.dp(2) else sw
            p.style = Paint.Style.STROKE
            when (style) {
                0 -> {
                    val g = half * 0.25f
                    c.drawLine(cx - half, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + half, cy, p)
                    c.drawLine(cx, cy - half, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + half, p)
                }
                1 -> { p.style = Paint.Style.FILL; c.drawCircle(cx, cy, max(context.dp(3), (half * 0.12f).toInt()).toFloat(), p) }
                else -> {
                    c.drawCircle(cx, cy, half * 0.7f, p)
                    p.style = Paint.Style.FILL; c.drawCircle(cx, cy, context.dp(2).toFloat(), p)
                }
            }
        }
    }

    companion object {
        val COLORS = intArrayOf(Color.parseColor("#39FF88"), Color.parseColor("#FF3B3B"), Color.WHITE, Color.parseColor("#FFE24D"))
    }
}

/** Gauge FPS setengah-lingkaran seperti p3. */
class FpsGauge(ctx: Context) : View(ctx) {
    var fps = -1
    var maxFps = 120
    var note = ""
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.LINE; strokeWidth = ctx.dp(8).toFloat() }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Pal.GREEN; strokeWidth = ctx.dp(8).toFloat() }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.TEXT; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(34).toFloat() }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.MUTED; textAlign = Paint.Align.CENTER; typeface = ctx.head(); textSize = ctx.dp(10).toFloat() }

    override fun onDraw(c: Canvas) {
        val pad = context.dp(10).toFloat()
        val size = minOf(width.toFloat(), height.toFloat()) - pad * 2
        val l = (width - size) / 2f; val t = (height - size) / 2f
        val rect = RectF(l, t, l + size, t + size)
        c.drawArc(rect, 135f, 270f, false, bg)
        if (fps > 0) c.drawArc(rect, 135f, 270f * (fps.toFloat() / maxFps).coerceIn(0f, 1f), false, fg)
        val cx = width / 2f; val cy = height / 2f
        c.drawText("FPS", cx, cy - size * 0.28f, small)
        c.drawText(if (fps >= 0) fps.toString() else "--", cx, cy + context.dp(10), big)
        val st = when {
            fps < 0 -> note
            fps >= maxFps * 0.85f -> "STABIL"
            else -> "TURUN"
        }
        c.drawText(st, cx, cy + size * 0.36f, small)
    }
}

/** Tile segi enam bergaya p3. */
class HexTile(ctx: Context, var glyph: String, var sub: String) : View(ctx) {
    var lit = false
        set(v) { field = v; invalidate() }
    var locked = false
        set(v) { field = v; alpha = if (v) 0.45f else 1f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Pal.GREEN }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(90, 57, 255, 136) }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dp(17).toFloat(); color = Pal.TEXT; typeface = ctx.head() }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dp(9).toFloat(); color = Pal.MUTED; typeface = ctx.head() }
    private val path = Path()
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val r = w / 2f - context.dp(3)
        val hh = r * 0.866f
        val cx = w / 2f
        val cy = hh + context.dp(3)
        path.reset()
        path.moveTo(cx - r, cy); path.lineTo(cx - r / 2, cy - hh); path.lineTo(cx + r / 2, cy - hh)
        path.lineTo(cx + r, cy); path.lineTo(cx + r / 2, cy + hh); path.lineTo(cx - r / 2, cy + hh)
        path.close()
        fill.color = if (lit) Color.argb(255, 15, 107, 58) else Pal.CARD2
        c.drawPath(path, fill)
        if (lit) { glow.strokeWidth = context.dp(5).toFloat(); c.drawPath(path, glow) }
        ln.strokeWidth = context.dp(if (lit) 2 else 1).toFloat()
        c.drawPath(path, ln)
        c.drawText(glyph, cx, cy + gp.textSize * 0.35f, gp)
        c.drawText(sub, cx, cy + hh + context.dp(13), sp)
    }
}

/**
 * Panel overlay bergaya p3: banner tengah-atas dengan tile segi enam.
 * Hanya tampil saat game di depan; kalau game ditinggal > 5 menit, grafis dikembalikan ke asli.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var am: AudioManager
    private lateinit var dm: DisplayManager
    private val ui = Handler(Looper.getMainLooper())
    private var pkg = ""
    private var handle: View? = null
    private var panel: View? = null
    private var xh: CrosshairView? = null
    private var open = false
    private var panelAdded = false
    private var started = false
    private var hasUi = false
    @Volatile private var running = true
    @Volatile private var inGame = false
    private var awaySince = 0L
    private lateinit var gauge: FpsGauge
    private lateinit var cpuTv: TextView
    private lateinit var cpuBar: ProgressBar
    private lateinit var detail: LinearLayout
    private lateinit var audioRow: View
    private lateinit var brightRow: View
    private lateinit var xhRow: View
    private val tiles = mutableListOf<HexTile>()
    private val styleChips = mutableListOf<TextView>()
    private val colorDots = mutableListOf<View>()
    private val hzTiles = mutableListOf<Pair<Int, HexTile>>()
    private var sel = -1
    private var rates = setOf<Int>()
    private var curHz = 60
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var layer = ""
    private var fpsMiss = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        store = Store(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (started) return START_NOT_STICKY
        started = true
        pkg = i?.getStringExtra("pkg") ?: ""
        val wantUi = i?.getBooleanExtra("ov", true) ?: true
        if (wantUi && Settings.canDrawOverlays(this)) {
            hasUi = true
            buildHandle()
            buildPanel()
            refreshCrosshair()
        }
        awaySince = System.currentTimeMillis()
        startLoop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { handle?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { if (panelAdded) wm.removeView(panel) } catch (e: Exception) {}
        try { xh?.let { wm.removeView(it) } } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gzi", "GZI Panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "gzi")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("GZI TOOLS")
            .setContentText("Panel game aktif")
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun screen(): Point {
        val p = Point()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealSize(p)
        return p
    }

    private fun lp(w: Int, h: Int, flags: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

    // ---------- Pegangan: mentok kiri, agak atas, bisa digeser naik-turun ----------
    private fun buildHandle() {
        val hH = dp(76)
        val r = dp(7).toFloat()
        val h = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Pal.GREEN)
                cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
            alpha = 0.35f
            visibility = View.GONE
        }
        val hp = lp(dp(14), hH, 0, Gravity.START or Gravity.TOP)
        hp.x = 0
        hp.y = if (store.hy >= 0) store.hy else (screen().y * 0.16f).toInt()
        var downX = 0f; var downY = 0f; var startY = 0; var moving = false
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = hp.y; moving = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (dx > dp(28) && abs(dy) < dp(40)) {
                        if (!moving) openPanel()
                    } else if (abs(dy) > dp(12) && abs(dx) < dp(28)) {
                        moving = true
                        hp.y = (startY + dy).toInt().coerceIn(0, max(0, screen().y - hH))
                        try { wm.updateViewLayout(h, hp) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moving) store.hy = hp.y
                    else if (abs(e.rawX - downX) < dp(8) && abs(e.rawY - downY) < dp(8)) openPanel()
                }
            }
            true
        }
        handle = h
        wm.addView(h, hp)
    }

    // ---------- Panel ----------
    private fun label(s: String) = tx(s, 10f, Pal.MUTED, true).apply { letterSpacing = 0.15f }

    private fun tint(sb: SeekBar) {
        val g = ColorStateList.valueOf(Pal.GREEN)
        sb.progressTintList = g; sb.thumbTintList = g
        sb.progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
    }

    private fun seek(maxV: Int, cur: Int, on: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        max = maxV; progress = cur.coerceIn(0, maxV); tint(this)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun rowBox(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        background = shape(Pal.CARD2, dp(16).toFloat(), Pal.LINE, dp(1))
        setPadding(dp(14), dp(8), dp(14), dp(8))
        visibility = View.GONE
    }

    private fun tile(g: String, s: String): HexTile = HexTile(this, g, s)

    private fun buildPanel() {
        rates = dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes.map { Math.round(it.refreshRate) }.toSet()
        val tw = dp(58); val th = dp(76)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(16), dp(30), dp(14))
        }

        // ===== Baris tile: [Audio][Kecerahan][Crosshair][Matikan] | gauge | [60][90][120][144] =====
        val rowA = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }

        val left = LinearLayout(this)
        val defs = listOf("🔊" to "AUDIO", "☀" to "KECERAHAN", "⊕" to "CROSSHAIR", "⏻" to "MATIKAN")
        defs.forEachIndexed { i, (g, s) ->
            val t = tile(g, s)
            t.setOnClickListener { if (i == 3) stopSelf() else { sel = if (sel == i) -1 else i; renderSel() } }
            if (i < 3) tiles += t
            left.add(t, tw, th, 0f, 0, 0, 4)
        }
        rowA.add(left, WRAP, WRAP)
        rowA.add(View(this), 0, 1, 1f)

        val cen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        gauge = FpsGauge(this)
        gauge.maxFps = max(60, rates.maxOrNull() ?: 60)
        cen.add(gauge, dp(140), dp(92))
        cpuTv = tx("CPU --%", 12f, Pal.TEXT, true)
        cen.add(cpuTv, WRAP, WRAP, 0f, 0, 0)
        cpuBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(Pal.GREEN)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
        }
        cen.add(cpuBar, dp(120), dp(5), 0f, 0, 4)
        rowA.add(cen, WRAP, WRAP, 0f, 8, 0, 8)
        rowA.add(View(this), 0, 1, 1f)

        val right = LinearLayout(this)
        listOf(60, 90, 120, 144).forEach { hz ->
            val ok = rates.any { abs(it - hz) <= 1 }
            val t = if (ok) tile("$hz", "Hz") else tile("🔒", "$hz Hz")
            t.locked = !ok
            t.setOnClickListener {
                if (ok) setRate(hz)
                else Toast.makeText(this@OverlayService, "$hz Hz tidak didukung HP ini", Toast.LENGTH_SHORT).show()
            }
            hzTiles += hz to t
            right.add(t, tw, th, 0f, 4, 0, 0)
        }
        rowA.add(right, WRAP, WRAP)
        body.add(rowA)

        // ===== Detail (muncul setelah tile ditekan) =====
        detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        val ar = rowBox()
        ar.add(tx("🔊", 16f), WRAP, WRAP, 0f, 0, 0, 10)
        ar.add(seek(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0) } catch (e: Exception) {}
        }, 0, WRAP, 1f)
        audioRow = ar; detail.add(ar)

        val br = rowBox()
        br.add(tx("☀", 16f), WRAP, WRAP, 0f, 0, 0, 10)
        val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
        br.add(seek(255, cur) {
            try {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(1, it))
            } catch (e: Exception) {}
        }, 0, WRAP, 1f)
        brightRow = br; detail.add(br)

        val xr = rowBox()
        xr.add(label("CROSSHAIR"), WRAP, WRAP, 0f, 0, 0, 8)
        val sw = Switch(this).apply {
            isChecked = store.xhOn
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN, Pal.MUTED))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN_D, Pal.LINE))
            setOnCheckedChangeListener { _, v -> store.xhOn = v; refreshCrosshair() }
        }
        xr.add(sw, WRAP, WRAP, 0f, 0, 0, 10)
        listOf("＋", "•", "◎").forEachIndexed { i, s ->
            val c = tx(s, 15f, Pal.TEXT, true).apply {
                gravity = Gravity.CENTER
                setOnClickListener { store.xhStyle = i; renderXh(); refreshCrosshair() }
            }
            styleChips += c
            xr.add(c, dp(38), dp(32), 0f, 0, 0, 6)
        }
        xr.add(label("UKURAN"), WRAP, WRAP, 0f, 8, 0, 4)
        xr.add(seek(200, store.xhSize - 20) { store.xhSize = it + 20; refreshCrosshair() }, 0, WRAP, 1f)
        CrosshairView.COLORS.forEachIndexed { i, colr ->
            val d = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colr) }
                setOnClickListener { store.xhColor = i; renderXh(); refreshCrosshair() }
            }
            colorDots += d
            xr.add(d, dp(24), dp(24), 0f, if (i == 0) 12 else 8)
        }
        xhRow = xr; detail.add(xr)
        body.add(detail, t = 6)

        renderXh(); renderHz(); renderSel()

        val root = FrameLayout(this).apply {
            background = ChamferBg(dp(22).toFloat(), dp(2).toFloat())
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
            val x = tx("✕", 16f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#C62828")) }
                setOnClickListener { closePanel() }
            }
            addView(x, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(10), dp(16), 0) })
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel(); false }
        }
        panel = root
    }

    private fun renderSel() {
        tiles.forEachIndexed { i, t -> t.lit = (i == sel) }
        detail.visibility = if (sel in 0..2) View.VISIBLE else View.GONE
        audioRow.visibility = if (sel == 0) View.VISIBLE else View.GONE
        brightRow.visibility = if (sel == 1) View.VISIBLE else View.GONE
        xhRow.visibility = if (sel == 2) View.VISIBLE else View.GONE
    }

    private fun renderXh() {
        styleChips.forEachIndexed { i, c ->
            val on = i == store.xhStyle
            c.background = if (on) shape(Pal.GREEN, dp(12).toFloat()) else shape(Pal.CARD, dp(12).toFloat(), Pal.LINE, dp(1))
            c.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
        colorDots.forEachIndexed { i, d ->
            (d.background as GradientDrawable).setStroke(if (i == store.xhColor) dp(3) else 0, Color.WHITE)
        }
    }

    private fun renderHz() {
        for ((hz, t) in hzTiles) t.lit = !t.locked && abs(hz - curHz) <= 1
    }

    private fun setRate(hz: Int) {
        curHz = hz; renderHz()
        Thread {
            Sz.sh(
                "settings put system min_refresh_rate $hz.0\n" +
                "settings put system peak_refresh_rate $hz.0\n" +
                "settings put system user_refresh_rate $hz\n" +
                "settings put secure user_refresh_rate $hz"
            )
        }.start()
    }

    private fun openPanel() {
        if (open || !inGame) return
        val pnl = panel ?: return
        open = true
        curHz = Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate)
        renderHz()
        val w = minOf(screen().x - dp(24), dp(800))
        pnl.translationY = -dp(320).toFloat()
        try {
            val p = lp(w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            p.y = dp(4)
            wm.addView(pnl, p)
            panelAdded = true
        } catch (e: Exception) { open = false; return }
        handle?.visibility = View.INVISIBLE
        ValueAnimator.ofFloat(-dp(320).toFloat(), 0f).apply {
            duration = 200
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            start()
        }
    }

    private fun closePanel() {
        if (!open) return
        open = false
        val pnl = panel ?: return
        ValueAnimator.ofFloat(0f, -dp(320).toFloat()).apply {
            duration = 160
            addUpdateListener { pnl.translationY = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    try { if (panelAdded) wm.removeView(pnl) } catch (e: Exception) {}
                    panelAdded = false
                    handle?.visibility = if (inGame) View.VISIBLE else View.GONE
                }
            })
            start()
        }
    }

    private fun forceClose() {
        if (panelAdded) { try { wm.removeView(panel) } catch (e: Exception) {}; panelAdded = false }
        open = false
    }

    /** Panel, pegangan, dan crosshair hanya tampil saat game di depan. */
    private fun applyVisibility() {
        if (!hasUi) return
        if (!inGame) {
            forceClose()
            handle?.visibility = View.GONE
            xh?.visibility = View.GONE
        } else {
            handle?.visibility = if (open) View.INVISIBLE else View.VISIBLE
            xh?.visibility = View.VISIBLE
        }
    }

    private fun refreshCrosshair() {
        if (!store.xhOn) {
            xh?.let { try { wm.removeView(it) } catch (e: Exception) {} }
            xh = null
            return
        }
        val v = xh ?: CrosshairView(this).also {
            xh = it
            wm.addView(it, lp(dp(240), dp(240), WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, Gravity.CENTER))
        }
        v.visibility = if (inGame) View.VISIBLE else View.GONE
        v.style = store.xhStyle; v.sizeDp = store.xhSize; v.colorIdx = store.xhColor
        v.invalidate()
    }

    // ---------- Loop: fokus game, FPS/CPU, auto-kembali ke asli ----------
    private fun startLoop() {
        Thread {
            var tick = 0
            while (running) {
                try {
                    tick++
                    if (tick % 2 == 0) checkFocus()
                    if (open && inGame) poll()
                    if (!inGame && awaySince > 0 && System.currentTimeMillis() - awaySince >= AWAY_LIMIT_MS) {
                        Engine.reset()
                        ui.post { stopSelf() }
                        break
                    }
                    Thread.sleep(1000)
                } catch (e: Throwable) {}
            }
        }.start()
    }

    private fun checkFocus() {
        if (pkg.isEmpty()) return
        val r = Sz.sh("dumpsys window | grep mCurrentFocus | head -n1")
        if (r.startsWith("ERROR") || r.isBlank()) return
        val g = r.contains(pkg)
        if (g != inGame) {
            inGame = g
            awaySince = if (g) 0L else System.currentTimeMillis()
            if (!g) layer = ""
            ui.post { applyVisibility() }
        }
    }

    private fun parseTs(lines: List<String>): List<Long> = lines.mapNotNull {
        val p = it.trim().split(Regex("\\s+"))
        if (p.size == 3) p[1].toLongOrNull() else null
    }.filter { it > 0 && it < Long.MAX_VALUE / 2 }

    /** Uji semua layer milik game, pilih yang paling banyak punya frame. */
    private fun detect() {
        val out = Sz.sh(
            "dumpsys SurfaceFlinger --list | grep -F '$pkg' | while IFS= read -r l; do " +
            "echo \"@L\$l\"; dumpsys SurfaceFlinger --latency \"\$l\"; done"
        ).lines()
        var best = ""
        var bestN = 0
        var name = ""
        val buf = mutableListOf<String>()
        fun flush() {
            if (name.isNotEmpty()) {
                val n = parseTs(buf).size
                if (n >= 2 && n > bestN) { best = name; bestN = n }
            }
        }
        for (ln in out) {
            if (ln.startsWith("@L")) { flush(); name = ln.substring(2); buf.clear() } else buf += ln
        }
        flush()
        layer = best
    }

    private fun poll() {
        if (layer.isEmpty() && pkg.isNotEmpty()) detect()
        val q = layer.replace("'", "'\\''")
        val lat = if (layer.isNotEmpty()) "dumpsys SurfaceFlinger --latency '$q'" else "true"
        val out = Sz.sh("echo @S; head -n1 /proc/stat; echo @F; $lat").lines()
        val si = out.indexOf("@S"); val fi = out.indexOf("@F")
        if (si < 0 || fi < 0) return

        var cpu = -1
        val nums = out.getOrNull(si + 1)?.trim()?.split(Regex("\\s+"))?.drop(1)?.mapNotNull { it.toLongOrNull() } ?: emptyList()
        if (nums.size >= 5) {
            val total = nums.take(8).sum()
            val idle = nums[3] + nums[4]
            if (prevTotal > 0 && total > prevTotal) {
                cpu = (100 * (1.0 - (idle - prevIdle).toDouble() / (total - prevTotal))).toInt().coerceIn(0, 100)
            }
            prevTotal = total; prevIdle = idle
        }

        val ts = parseTs(out.drop(fi + 2))
        var fps = -1
        if (ts.size >= 2) {
            val mx = ts.max()
            fps = ts.count { it >= mx - 1_000_000_000L }
            fpsMiss = 0
        } else if (layer.isNotEmpty()) {
            fpsMiss++
            if (fpsMiss >= 3) { layer = ""; fpsMiss = 0 }
        }

        val note = if (layer.isEmpty()) "MENCARI" else "--"
        ui.post {
            gauge.fps = fps; gauge.note = note; gauge.invalidate()
            cpuTv.text = if (cpu >= 0) "CPU $cpu%" else "CPU --%"
            if (cpu >= 0) cpuBar.progress = cpu
        }
    }

    companion object {
        const val AWAY_LIMIT_MS = 5 * 60 * 1000L
    }
}
