package com.gzitools

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Pemeriksa keaslian build GZI TOOLS. Membandingkan sertifikat penandatangan APK yang sedang
 * berjalan dengan sertifikat rilis resmi (by @hazi). Kalau APK sudah dibongkar lalu ditandatangani
 * ulang oleh orang lain (wajib terjadi saat APK dimodifikasi), sertifikatnya pasti berbeda.
 *
 * Sengaja TIDAK hanya satu gerbang: fungsi genuine() juga dipanggil ulang dari dalam Engine
 * (Core.kt) sebelum tiap aksi inti dijalankan, supaya menghapus pengecekan di satu activity saja
 * tidak cukup untuk membuka kuncinya.
 */
object Guard {
    // Hash sertifikat resmi, disimpan terenkripsi (XOR) supaya tidak langsung terlihat sebagai
    // teks polos di dalam APK yang dibongkar.
    private val ENC = intArrayOf(
        104, 57, 105, 56, 104, 107, 98, 111, 99, 99, 56, 111, 57, 110, 99, 99, 63, 109, 111, 110,
        108, 110, 57, 106, 108, 62, 59, 107, 56, 108, 109, 106, 104, 62, 109, 106, 60, 106, 63, 105,
        105, 56, 110, 98, 111, 62, 99, 59, 107, 106, 56, 60, 56, 59, 60, 62, 98, 63, 109, 110, 57,
        98, 56, 111
    )
    private const val K = 0x5a

    private fun expected(): String {
        val c = CharArray(ENC.size)
        for (i in ENC.indices) c[i] = (ENC[i] xor K).toChar()
        return String(c)
    }

    @Volatile private var checked = false
    @Volatile private var ok = false

    /** true bila APK ini ditandatangani dengan sertifikat resmi GZI TOOLS. */
    fun genuine(ctx: Context): Boolean {
        if (checked) return ok
        ok = try { hash(ctx) == expected() } catch (e: Throwable) { false }
        checked = true
        return ok
    }

    private fun hash(ctx: Context): String {
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= 28) {
            val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val si = info.signingInfo ?: return ""
            if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
        } else {
            @Suppress("DEPRECATION")
            ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
        }
        if (sigs.isEmpty()) return ""
        val md = MessageDigest.getInstance("SHA-256")
        val out = StringBuilder()
        for (b in md.digest(sigs[0].toByteArray())) out.append(String.format("%02x", b))
        return out.toString()
    }
}
