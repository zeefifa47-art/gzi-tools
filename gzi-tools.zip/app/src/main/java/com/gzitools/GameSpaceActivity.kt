package com.gzitools

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Halaman lebar: Main / Tekstur Ringan / Cek Status. */
class GameSpaceActivity : Activity() {
    private lateinit var pkg: String
    private lateinit var store: Store
    private lateinit var cfg: TexCfg
    private lateinit var menuPane: View
    private lateinit var texPane: View
    private lateinit var burikPane: View
    private lateinit var bkCard: View
    private lateinit var bkTitle: TextView
    private lateinit var bkDesc: TextView
    private var burikOk = false
    private lateinit var rootFl: FrameLayout
    private lateinit var bSample: SampleView
    private lateinit var bSeek: SeekBar
    private lateinit var bName: TextView
    private lateinit var bEnable: Switch
    private val bChips = mutableListOf<TextView>()
    private var bLv = 1
    private var bOn = false
    private var bUpd = false
    private lateinit var sample: SampleView
    private lateinit var seek: SeekBar
    private lateinit var levelName: TextView
    private lateinit var swSharp: Switch
    private lateinit var swHard: Switch
    private lateinit var swEnable: Switch
    private val chips = mutableListOf<TextView>()
    private var upd = false
    private var gameName = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        pkg = intent.getStringExtra("pkg") ?: run { finish(); return }
        store = Store(this)
        cfg = if (store.has(pkg)) store.cfg(pkg) else store.cfg(pkg).copy(enabled = true)
        gameName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

        val root = FrameLayout(this).apply { setBackgroundColor(Pal.BG) }
        root.addView(GridBg(this), FrameLayout.LayoutParams(MATCH, MATCH))
        bLv = store.burikLv; bOn = store.burikOn
        menuPane = buildMenu(); texPane = buildTexture(); burikPane = buildBurik()
        root.addView(menuPane, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(texPane, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(burikPane, FrameLayout.LayoutParams(MATCH, MATCH))
        rootFl = root
        setContentView(root)
        showMenu()
        render()
        renderBurik()
        if (intent.getBooleanExtra("fromIntro", false)) {
            val f = View(this).apply { setBackgroundColor(Pal.GREEN) }
            root.addView(f, FrameLayout.LayoutParams(MATCH, MATCH))
            f.animate().alpha(0f).setDuration(520).withEndAction { root.removeView(f) }.start()
        }
    }

    // ---------- Menu ----------
    private fun buildMenu(): View {
        val row = LinearLayout(this).apply { setPadding(dp(24), dp(20), dp(24), dp(20)) }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.add(btn("←  Kembali", false) { finish() }.apply { textSize = 12f }, WRAP)
        val icon = try { drawableToBitmap(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { null }
        if (icon != null) left.add(ImageView(this).apply {
            setImageBitmap(icon); clipToOutline = true
            background = shape(Pal.CARD, dp(20).toFloat(), Pal.GREEN, dp(2))
        }, dp(84), dp(84), 0f, 0, 22)
        left.add(tx("ARENA  ·  by @hazi", 10f, Pal.GREEN, true).apply { letterSpacing = 0.25f }, t = 12)
        left.add(tx(gameName, 22f, Pal.TEXT, true), t = 2)
        left.add(tx(pkg, 10f, Pal.MUTED), t = 2)
        row.add(left, dp(230), MATCH)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.add(btn("▶   MAIN  $gameName") { play() }.apply { textSize = 18f; setPadding(dp(20), dp(18), dp(20), dp(18)) })
        val tex = card().apply {
            setOnClickListener { if (Engine.supported) showTexture() else toast("Pixel Lab butuh Android 15 ke atas") }
            if (!Engine.supported) alpha = 0.55f
        }
        tex.add(tx("Pixel Lab", 18f, Pal.TEXT, true))
        tex.add(
            tx(
                if (Engine.supported) "5 level piksel · Tepi Kotak · Lompat Detail  —  by @hazi"
                else "Tidak tersedia: butuh Android 15 ke atas (HP kamu Android ${Build.VERSION.RELEASE})",
                12f, if (Engine.supported) Pal.MUTED else Pal.WARN
            ), t = 4
        )
        right.add(tex, t = 14)

        val bk = card().apply {
            setOnClickListener {
                if (burikOk) showBurik()
                else toast("Grafik Burik hanya untuk HP yang mendukung downscale game")
            }
        }
        bkTitle = tx("Grafik Burik", 18f, Pal.TEXT, true)
        bkDesc = tx("Memeriksa dukungan HP...", 12f, Pal.MUTED)
        bk.add(bkTitle)
        bk.add(bkDesc, t = 4)
        bkCard = bk
        if (Build.VERSION.SDK_INT < 31) setBurikLocked() else {
            bk.alpha = 0.55f
            Thread {
                val ok = Engine.checkDownscale()
                runOnUiThread { if (ok) setBurikOpen() else setBurikLocked() }
            }.start()
        }
        right.add(bk, t = 12)


        val pn = card()
        val pr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pc.add(tx("Panel Game", 18f, Pal.TEXT, true))
        pc.add(tx("Geser dari tepi kiri layar saat bermain: FPS, CPU, Audio, Kecerahan, Crosshair, Resolusi, Refresh Rate, Mode Fokus, RAM, Screenshot, Rekam, Suhu, Ping", 12f, Pal.MUTED), t = 4)
        pr.add(pc, 0, WRAP, 1f, 0, 0, 10)
        val psw = Switch(this).apply {
            isChecked = store.overlayOn
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN, Pal.MUTED))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN_D, Pal.LINE))
            setOnCheckedChangeListener { _, v -> store.overlayOn = v }
        }
        pr.add(psw, WRAP)
        pn.add(pr)
        right.add(pn, t = 12)

        right.add(btn("☝  Uji Sentuh", false) { startActivity(Intent(this, TouchTestActivity::class.java)) }, WRAP, WRAP, 0f, 0, 10)
        right.add(btn("♪  TikTok  @inihazi", false) { openTikTok() }, WRAP, WRAP, 0f, 0, 14)
        row.add(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(right) }, 0, MATCH, 1f, 24)
        return row
    }

    // ---------- Tekstur (p3) ----------
    private fun buildTexture(): View {
        val row = LinearLayout(this).apply { setPadding(dp(20), dp(14), dp(20), dp(14)) }

        // kiri: sampel
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hd = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hd.add(btn("←", false) { showMenu() }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)) }, WRAP)
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.add(tx("GZI ARENA  ·  by @hazi", 9f, Pal.GREEN, true).apply { letterSpacing = 0.2f })
        ht.add(tx("Pixel Lab", 18f, Pal.TEXT, true))
        hd.add(ht, WRAP, WRAP, 0f, 12)
        left.add(hd)
        sample = SampleView(this)
        left.add(sample, MATCH, 0, 1f, 0, 10, 0, 10)
        val gr = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Pal.CARD, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val gc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gc.add(tx(gameName, 13f, Pal.TEXT, true))
        gc.add(tx("Pakai Pixel Lab di $gameName", 10f, Pal.MUTED))
        gr.add(gc, 0, WRAP, 1f)
        swEnable = sw { if (!upd) { cfg = cfg.copy(enabled = it); render() } }
        gr.add(swEnable, WRAP)
        left.add(gr)
        row.add(left, 0, MATCH, 0.42f)

        // kanan: kontrol
        val sc = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val seg = LinearLayout(this).apply {
            background = shape(Pal.CARD, dp(22).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listOf("Soft", "Arcade", "Block Max", "Manual").forEachIndexed { i, n ->
            val c = tx(n, 12f, Pal.TEXT, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { preset(i) }
            }
            chips += c
            seg.add(c, 0, WRAP, 1f)
        }
        right.add(seg)

        val lh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lh.add(tx("Level Piksel", 13f, Pal.TEXT, true), 0, WRAP, 1f)
        levelName = tx("", 13f, Pal.GREEN, true); lh.add(levelName, WRAP)
        right.add(lh, t = 12)

        seek = SeekBar(this).apply {
            max = 4
            val g = ColorStateList.valueOf(Pal.GREEN)
            progressTintList = g; thumbTintList = g
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (!upd && user) { cfg = cfg.copy(level = p); render() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        right.add(seek, t = 4)
        val lr = LinearLayout(this)
        Engine.LEVELS.forEachIndexed { i, n ->
            lr.add(tx(n, 10f, Pal.MUTED).apply {
                gravity = when (i) { 0 -> Gravity.START; 4 -> Gravity.END; else -> Gravity.CENTER }
            }, 0, WRAP, 1f)
        }
        right.add(lr, l = 4, r = 4)

        val tg = LinearLayout(this)
        swSharp = sw { if (!upd) { cfg = cfg.copy(sharp = it); render() } }
        swHard = sw { if (!upd) { cfg = cfg.copy(hard = it); render() } }
        tg.add(toggleCard("Tepi Kotak", "Tepi gambar jadi kotak-kotak. Matikan untuk tampilan halus.", swSharp), 0, WRAP, 1f, 0, 0, 6)
        tg.add(toggleCard("Lompat Detail", "Detail dekat ke jauh berganti mendadak, tidak halus.", swHard), 0, WRAP, 1f, 6)
        right.add(tg, t = 12)

        right.add(tx("• Perubahan berlaku setelah game dibuka ulang.", 11f, Pal.MUTED), t = 10)
        right.add(tx("• Paling terasa kalau grafis dalam game di setelan rendah.", 11f, Pal.MUTED), t = 4)

        val bt = LinearLayout(this)
        bt.add(btn("↺  Kembalikan Normal", false) { resetAll() }, WRAP, WRAP, 0f, 0, 0, 10)
        bt.add(btn("Terapkan") { save() }, 0, WRAP, 1f)
        right.add(bt, t = 16)

        sc.addView(right)
        row.add(sc, 0, MATCH, 0.58f, 18)
        return row
    }

    // ---------- Grafik Burik (mirip Pixel Lab) ----------
    private fun buildBurik(): View {
        val row = LinearLayout(this).apply { setPadding(dp(20), dp(14), dp(20), dp(14)) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hd = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hd.add(btn("←", false) { showMenu() }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)) }, WRAP)
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.add(tx("GZI ARENA  ·  by @hazi", 9f, Pal.GREEN, true).apply { letterSpacing = 0.2f })
        ht.add(tx("Grafik Burik", 18f, Pal.TEXT, true))
        hd.add(ht, WRAP, WRAP, 0f, 12)
        left.add(hd)
        bSample = SampleView(this)
        left.add(bSample, MATCH, 0, 1f, 0, 10, 0, 10)
        val gr = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Pal.CARD, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val gc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gc.add(tx(gameName, 13f, Pal.TEXT, true))
        gc.add(tx("Pakai Grafik Burik di $gameName", 10f, Pal.MUTED))
        gr.add(gc, 0, WRAP, 1f)
        bEnable = sw { if (!bUpd) { bOn = it; renderBurik() } }
        gr.add(bEnable, WRAP)
        left.add(gr)
        row.add(left, 0, MATCH, 0.42f)

        val sc = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val seg = LinearLayout(this).apply {
            background = shape(Pal.CARD, dp(22).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        Engine.BURIK.forEachIndexed { i, n ->
            val c = tx(n, 12f, Pal.TEXT, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { bLv = i; renderBurik() }
            }
            bChips += c
            seg.add(c, 0, WRAP, 1f)
        }
        right.add(seg)
        val lh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lh.add(tx("Tingkat Burik", 13f, Pal.TEXT, true), 0, WRAP, 1f)
        bName = tx("", 13f, Pal.GREEN, true); lh.add(bName, WRAP)
        right.add(lh, t = 12)
        bSeek = SeekBar(this).apply {
            max = 2
            val g = ColorStateList.valueOf(Pal.GREEN)
            progressTintList = g; thumbTintList = g
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (!bUpd && user) { bLv = p; renderBurik() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        right.add(bSeek, t = 4)
        val lr = LinearLayout(this)
        Engine.BURIK.forEachIndexed { i, n ->
            lr.add(tx(n, 10f, Pal.MUTED).apply { gravity = when (i) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER } }, 0, WRAP, 1f)
        }
        right.add(lr, l = 4, r = 4)

        val note = card()
        note.add(tx("Cocok untuk HP di bawah Android 15", 13f, Pal.TEXT, true))
        note.add(tx("Resolusi game diturunkan (Ringan ± 70%, Extrem ± 50%) supaya GPU lebih enteng dan FPS lebih stabil. Hanya resolusi game yang diturunkan. Layar dan DPI HP tidak diubah. Kembali normal lewat tombol Kembalikan Asli, atau otomatis kalau game ditinggal lebih dari 5 menit. Butuh Android 11 ke atas.", 11f, Pal.MUTED), t = 4)
        right.add(note, t = 12)
        right.add(tx("• Perubahan berlaku setelah game dibuka ulang (tombol MAIN otomatis memuat ulang).", 11f, Pal.MUTED), t = 10)

        val bt = LinearLayout(this)
        bt.add(btn("↺  Kembalikan Asli", false) { resetBurik() }, WRAP, WRAP, 0f, 0, 0, 10)
        bt.add(btn("Terapkan") { saveBurik() }, 0, WRAP, 1f)
        right.add(bt, t = 16)
        sc.addView(right)
        row.add(sc, 0, MATCH, 0.58f, 18)
        return row
    }

    private fun renderBurik() {
        bUpd = true
        bSample.updateScale(Engine.BURIK_F[bLv])
        bSeek.progress = bLv
        bEnable.isChecked = bOn
        bName.text = Engine.BURIK[bLv]
        bChips.forEachIndexed { i, c ->
            val on = i == bLv
            c.background = if (on) shape(Pal.GREEN, dp(18).toFloat()) else null
            c.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
        bUpd = false
    }

    private fun saveBurik() {
        store.burikOn = bOn; store.burikLv = bLv
        val lv = if (bOn) bLv else 0
        Thread {
            val good = Engine.applyBurik(this, pkg, lv)
            runOnUiThread {
                if (good && lv > 0) ensureTimer()
                if (good) rootFl.banner(if (lv == 0) "Grafik Burik dimatikan (Asli)" else "Grafik Burik ${Engine.BURIK[lv]} aktif (${if (Engine.burikMethod == "game") "downscale game" else Engine.burikMethod}) · buka game lewat MAIN")
                else toast("Gagal. Pastikan Shizuku aktif dan HP Android 11+.")
            }
        }.start()
    }

    private fun resetBurik() {
        bOn = false; bLv = 0
        store.burikOn = false; store.burikLv = 0
        renderBurik()
        Thread {
            Engine.resetBurik(this, store.games + pkg)
            runOnUiThread { rootFl.banner("Grafik dikembalikan ke Asli") }
        }.start()
    }

    private fun sw(on: (Boolean) -> Unit): Switch = Switch(this).apply {
        thumbTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Pal.GREEN, Pal.MUTED)
        )
        trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Pal.GREEN_D, Pal.LINE)
        )
        setOnCheckedChangeListener { _, v -> on(v) }
    }

    private fun toggleCard(title: String, desc: String, s: Switch): View {
        val c = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Pal.CARD, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(tx(title, 13f, Pal.TEXT, true))
        col.add(tx(desc, 10f, Pal.MUTED), t = 3)
        c.add(col, 0, WRAP, 1f, 0, 0, 8)
        c.add(s, WRAP)
        return c
    }

    private fun preset(i: Int) {
        when (i) {
            0 -> cfg = cfg.copy(level = 1, sharp = false, hard = false)
            1 -> cfg = cfg.copy(level = 2, sharp = true, hard = true)
            2 -> cfg = cfg.copy(level = 3, sharp = true, hard = true)
        }
        render()
    }

    private fun presetIndex() = when {
        cfg.level == 1 && !cfg.sharp && !cfg.hard -> 0
        cfg.level == 2 && cfg.sharp && cfg.hard -> 1
        cfg.level == 3 && cfg.sharp && cfg.hard -> 2
        else -> 3
    }

    private fun render() {
        upd = true
        sample.update(cfg.level, cfg.sharp)
        seek.progress = cfg.level
        swSharp.isChecked = cfg.sharp
        swHard.isChecked = cfg.hard
        swEnable.isChecked = cfg.enabled
        levelName.text = Engine.LEVELS[cfg.level]
        val pi = presetIndex()
        chips.forEachIndexed { i, c ->
            val on = i == pi
            c.background = if (on) shape(Pal.GREEN, dp(18).toFloat()) else null
            c.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
        upd = false
    }

    private fun showMenu() { menuPane.visibility = View.VISIBLE; texPane.visibility = View.GONE; burikPane.visibility = View.GONE }
    private fun showTexture() { menuPane.visibility = View.GONE; texPane.visibility = View.VISIBLE; burikPane.visibility = View.GONE }
    private fun showBurik() { menuPane.visibility = View.GONE; texPane.visibility = View.GONE; burikPane.visibility = View.VISIBLE }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (menuPane.visibility != View.VISIBLE) showMenu() else super.onBackPressed()
    }

    // ---------- Aksi ----------
    private fun save() {
        store.save(pkg, cfg)
        Thread {
            val r = Engine.apply(this, pkg, cfg)
            runOnUiThread {
                if (r.startsWith("ERROR")) toast("Gagal menyimpan. Pastikan Shizuku aktif.")
                else if (cfg.enabled) ensureTimer()
                if (!r.startsWith("ERROR")) rootFl.banner(if (cfg.enabled) "Pixel Lab ${Engine.LEVELS[cfg.level]} aktif · buka game lewat MAIN" else "Pixel Lab dimatikan")
            }
        }.start()
    }

    private fun resetAll() {
        cfg = cfg.copy(enabled = false, level = 0, sharp = false, hard = false)
        store.save(pkg, cfg)
        render()
        Thread {
            val r = Engine.reset()
            runOnUiThread { if (r.startsWith("ERROR")) toast("Gagal. Pastikan Shizuku aktif.") else rootFl.banner("Pixel Lab dikembalikan ke Normal") }
        }.start()
    }

    private fun play() {
        if (!Sz.ready(this)) { toast("Aktifkan Shizuku dulu"); finish(); return }
        rootFl.banner("Menyiapkan $gameName...")
        val c = store.cfg(pkg)
        try {
            startForegroundService(
                Intent(this, OverlayService::class.java).putExtra("pkg", pkg).putExtra("ov", store.overlayOn)
            )
        } catch (e: Exception) {}
        Thread {
            Engine.apply(this, pkg, c)
            if (burikOk) Engine.applyBurik(this, pkg, if (store.burikOn) store.burikLv else 0)
            Engine.forceStop(pkg)
            try { Thread.sleep(600) } catch (e: InterruptedException) {}
            runOnUiThread {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) startActivity(i) else toast("Game tidak bisa dibuka")
            }
        }.start()
    }

    private fun setBurikOpen() {
        burikOk = true
        bkCard.alpha = 1f
        bkTitle.text = "Grafik Burik"
        bkDesc.text = "Asli · Ringan · Extrem  —  turunkan resolusi game biar lebih enteng. HP kamu mendukung  ·  by @hazi"
        bkDesc.setTextColor(Pal.MUTED)
    }

    private fun setBurikLocked() {
        burikOk = false
        bkCard.alpha = 0.55f
        bkTitle.text = "🔒  Grafik Burik"
        bkDesc.text = "Terkunci: HP ini tidak mendukung downscale game (butuh Android 12 ke atas dengan Game Mode). HP kamu Android ${Build.VERSION.RELEASE}"
        bkDesc.setTextColor(Pal.WARN)
    }

    /** Jalankan penjaga 5 menit (auto-reset) walau game belum dibuka lewat MAIN. */
    private fun ensureTimer() {
        try {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("pkg", pkg).putExtra("ov", store.overlayOn))
        } catch (e: Exception) {}
    }

    private fun openTikTok() {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/@inihazi"))) }
        catch (e: Exception) { toast("Tidak bisa membuka TikTok") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
