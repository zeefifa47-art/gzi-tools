package com.gzitools

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Halaman lebar: Main / Tekstur Ringan / Cek Status. */
class GameSpaceActivity : Activity() {
    private lateinit var pkg: String
    private lateinit var store: Store
    private lateinit var cfg: TexCfg
    private lateinit var menuPane: View
    private lateinit var texPane: View
    private lateinit var sample: SampleView
    private lateinit var seek: SeekBar
    private lateinit var levelName: TextView
    private lateinit var swSharp: Switch
    private lateinit var swHard: Switch
    private lateinit var swEnable: Switch
    private val chips = mutableListOf<TextView>()
    private var upd = false
    private var gameName = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        pkg = intent.getStringExtra("pkg") ?: run { finish(); return }
        store = Store(this)
        cfg = if (store.has(pkg)) store.cfg(pkg) else store.cfg(pkg).copy(enabled = true)
        gameName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

        val root = FrameLayout(this).apply { setBackgroundColor(Pal.BG) }
        menuPane = buildMenu(); texPane = buildTexture()
        root.addView(menuPane, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(texPane, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        showMenu()
        render()
    }

    // ---------- Menu ----------
    private fun buildMenu(): View {
        val row = LinearLayout(this).apply { setPadding(dp(24), dp(20), dp(24), dp(20)) }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.add(btn("←  Kembali", false) { finish() }.apply { textSize = 12f }, WRAP)
        val icon = try { drawableToBitmap(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { null }
        if (icon != null) left.add(ImageView(this).apply {
            setImageBitmap(icon); clipToOutline = true
            background = shape(Pal.CARD, dp(20).toFloat(), Pal.GREEN, dp(2))
        }, dp(84), dp(84), 0f, 0, 22)
        left.add(tx("GAME SPACE", 10f, Pal.GREEN, true).apply { letterSpacing = 0.25f }, t = 12)
        left.add(tx(gameName, 22f, Pal.TEXT, true), t = 2)
        left.add(tx(pkg, 10f, Pal.MUTED), t = 2)
        row.add(left, dp(230), MATCH)

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.add(btn("▶   MAIN  $gameName") { play() }.apply { textSize = 18f; setPadding(dp(20), dp(18), dp(20), dp(18)) })
        val tex = card().apply {
            setOnClickListener { if (Engine.supported) showTexture() else toast("Grafik tekstur butuh Android 15 ke atas") }
            if (!Engine.supported) alpha = 0.55f
        }
        tex.add(tx("Tekstur Ringan", 18f, Pal.TEXT, true))
        tex.add(
            tx(
                if (Engine.supported) "5 level detail · Piksel Tajam · Batas Jarak Tegas"
                else "Tidak tersedia: butuh Android 15 ke atas (HP kamu Android ${Build.VERSION.RELEASE})",
                12f, if (Engine.supported) Pal.MUTED else Pal.WARN
            ), t = 4
        )
        right.add(tex, t = 14)

        val pn = card()
        val pr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pc.add(tx("Panel Game", 18f, Pal.TEXT, true))
        pc.add(tx("Geser dari tepi kiri layar saat bermain: FPS, CPU, Audio, Kecerahan, Crosshair", 12f, Pal.MUTED), t = 4)
        pr.add(pc, 0, WRAP, 1f, 0, 0, 10)
        val psw = Switch(this).apply {
            isChecked = store.overlayOn
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN, Pal.MUTED))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Pal.GREEN_D, Pal.LINE))
            setOnCheckedChangeListener { _, v -> store.overlayOn = v }
        }
        pr.add(psw, WRAP)
        pn.add(pr)
        right.add(pn, t = 12)

        right.add(btn("♪  TikTok  @inihazi", false) { openTikTok() }, WRAP, WRAP, 0f, 0, 14)
        row.add(right, 0, MATCH, 1f, 24)
        return row
    }

    // ---------- Tekstur (p3) ----------
    private fun buildTexture(): View {
        val row = LinearLayout(this).apply { setPadding(dp(20), dp(14), dp(20), dp(14)) }

        // kiri: sampel
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hd = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hd.add(btn("←", false) { showMenu() }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)) }, WRAP)
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.add(tx("GZI GAME SPACE", 9f, Pal.GREEN, true).apply { letterSpacing = 0.2f })
        ht.add(tx("Tekstur Ringan", 18f, Pal.TEXT, true))
        hd.add(ht, WRAP, WRAP, 0f, 12)
        left.add(hd)
        sample = SampleView(this)
        left.add(sample, MATCH, 0, 1f, 0, 10, 0, 10)
        val gr = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Pal.CARD, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val gc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gc.add(tx(gameName, 13f, Pal.TEXT, true))
        gc.add(tx("Aktifkan untuk $gameName", 10f, Pal.MUTED))
        gr.add(gc, 0, WRAP, 1f)
        swEnable = sw { if (!upd) { cfg = cfg.copy(enabled = it); render() } }
        gr.add(swEnable, WRAP)
        left.add(gr)
        row.add(left, 0, MATCH, 0.42f)

        // kanan: kontrol
        val sc = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val seg = LinearLayout(this).apply {
            background = shape(Pal.CARD, dp(22).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listOf("Halus", "Retro", "Kotak Total", "Kustom").forEachIndexed { i, n ->
            val c = tx(n, 12f, Pal.TEXT, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { preset(i) }
            }
            chips += c
            seg.add(c, 0, WRAP, 1f)
        }
        right.add(seg)

        val lh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lh.add(tx("Detail Tekstur", 13f, Pal.TEXT, true), 0, WRAP, 1f)
        levelName = tx("", 13f, Pal.GREEN, true); lh.add(levelName, WRAP)
        right.add(lh, t = 12)

        seek = SeekBar(this).apply {
            max = 4
            val g = ColorStateList.valueOf(Pal.GREEN)
            progressTintList = g; thumbTintList = g
            progressBackgroundTintList = ColorStateList.valueOf(Pal.LINE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (!upd && user) { cfg = cfg.copy(level = p); render() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        right.add(seek, t = 4)
        val lr = LinearLayout(this)
        Engine.LEVELS.forEachIndexed { i, n ->
            lr.add(tx(n, 10f, Pal.MUTED).apply {
                gravity = when (i) { 0 -> Gravity.START; 4 -> Gravity.END; else -> Gravity.CENTER }
            }, 0, WRAP, 1f)
        }
        right.add(lr, l = 4, r = 4)

        val tg = LinearLayout(this)
        swSharp = sw { if (!upd) { cfg = cfg.copy(sharp = it); render() } }
        swHard = sw { if (!upd) { cfg = cfg.copy(hard = it); render() } }
        tg.add(toggleCard("Piksel Tajam", "Tepi tekstur kotak-kotak. Matikan untuk efek buram halus.", swSharp), 0, WRAP, 1f, 0, 0, 6)
        tg.add(toggleCard("Batas Jarak Tegas", "Perpindahan detail dekat-jauh jadi patah-patah.", swHard), 0, WRAP, 1f, 6)
        right.add(tg, t = 12)

        right.add(tx("• Diubah waktu lagi main? Tutup game lalu buka lagi.", 11f, Pal.MUTED), t = 10)
        right.add(tx("• Paling kelihatan kalau grafis game di setelan paling rendah.", 11f, Pal.MUTED), t = 4)

        val bt = LinearLayout(this)
        bt.add(btn("↺  Reset ke Asli", false) { resetAll() }, WRAP, WRAP, 0f, 0, 0, 10)
        bt.add(btn("Simpan") { save() }, 0, WRAP, 1f)
        right.add(bt, t = 16)

        sc.addView(right)
        row.add(sc, 0, MATCH, 0.58f, 18)
        return row
    }

    private fun sw(on: (Boolean) -> Unit): Switch = Switch(this).apply {
        thumbTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Pal.GREEN, Pal.MUTED)
        )
        trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Pal.GREEN_D, Pal.LINE)
        )
        setOnCheckedChangeListener { _, v -> on(v) }
    }

    private fun toggleCard(title: String, desc: String, s: Switch): View {
        val c = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Pal.CARD, dp(16).toFloat(), Pal.LINE, dp(1))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(tx(title, 13f, Pal.TEXT, true))
        col.add(tx(desc, 10f, Pal.MUTED), t = 3)
        c.add(col, 0, WRAP, 1f, 0, 0, 8)
        c.add(s, WRAP)
        return c
    }

    private fun preset(i: Int) {
        when (i) {
            0 -> cfg = cfg.copy(level = 1, sharp = false, hard = false)
            1 -> cfg = cfg.copy(level = 2, sharp = true, hard = true)
            2 -> cfg = cfg.copy(level = 3, sharp = true, hard = true)
        }
        render()
    }

    private fun presetIndex() = when {
        cfg.level == 1 && !cfg.sharp && !cfg.hard -> 0
        cfg.level == 2 && cfg.sharp && cfg.hard -> 1
        cfg.level == 3 && cfg.sharp && cfg.hard -> 2
        else -> 3
    }

    private fun render() {
        upd = true
        sample.update(cfg.level, cfg.sharp)
        seek.progress = cfg.level
        swSharp.isChecked = cfg.sharp
        swHard.isChecked = cfg.hard
        swEnable.isChecked = cfg.enabled
        levelName.text = Engine.LEVELS[cfg.level]
        val pi = presetIndex()
        chips.forEachIndexed { i, c ->
            val on = i == pi
            c.background = if (on) shape(Pal.GREEN, dp(18).toFloat()) else null
            c.setTextColor(if (on) Pal.ON_GREEN else Pal.TEXT)
        }
        upd = false
    }

    private fun showMenu() { menuPane.visibility = View.VISIBLE; texPane.visibility = View.GONE }
    private fun showTexture() { menuPane.visibility = View.GONE; texPane.visibility = View.VISIBLE }

    override fun onBackPressed() {
        if (texPane.visibility == View.VISIBLE) showMenu() else super.onBackPressed()
    }

    // ---------- Aksi ----------
    private fun save() {
        store.save(pkg, cfg)
        toast("Menyimpan...")
        Thread {
            val r = Engine.apply(this, pkg, cfg)
            runOnUiThread {
                toast(if (r.startsWith("ERROR")) "Gagal menyimpan. Pastikan Shizuku aktif." else "Tersimpan. Tutup game lalu buka lagi.")
            }
        }.start()
    }

    private fun resetAll() {
        cfg = cfg.copy(enabled = false, level = 0, sharp = false, hard = false)
        store.save(pkg, cfg)
        render()
        Thread {
            val r = Engine.reset()
            runOnUiThread { toast(if (r.startsWith("ERROR")) "Gagal. Pastikan Shizuku aktif." else "Dikembalikan ke asli") }
        }.start()
    }

    private fun play() {
        if (!Sz.ready(this)) { toast("Aktifkan Shizuku dulu"); finish(); return }
        toast("Menyiapkan...")
        val c = store.cfg(pkg)
        try {
            startForegroundService(
                Intent(this, OverlayService::class.java).putExtra("pkg", pkg).putExtra("ov", store.overlayOn)
            )
        } catch (e: Exception) {}
        Thread {
            Engine.apply(this, pkg, c)
            Engine.forceStop(pkg)
            try { Thread.sleep(600) } catch (e: InterruptedException) {}
            runOnUiThread {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) startActivity(i) else toast("Game tidak bisa dibuka")
            }
        }.start()
    }

    private fun openTikTok() {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/@inihazi"))) }
        catch (e: Exception) { toast("Tidak bisa membuka TikTok") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
