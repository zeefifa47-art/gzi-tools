package com.gzitools

import android.app.Application

/** Mulai sesi "online" (lihat Presence.kt) selama proses app ini hidup — termasuk pas lagi main game di background. */
class GziApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Presence.start()
    }
}
