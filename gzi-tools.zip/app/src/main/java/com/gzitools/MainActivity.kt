package com.gzitools

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroBtn: TextView
    private lateinit var vShizuku: TextView
    private lateinit var vPerm: TextView
    private lateinit var vGfx: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        setContentView(build())
        if (!Sz.ready(this)) startActivity(Intent(this, OnboardActivity::class.java))
    }

    override fun onResume() { super.onResume(); render() }

    private fun statusRow(name: String): Pair<View, TextView> {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        r.add(tx(name, 11f, Pal.MUTED, true).apply { letterSpacing = 0.15f }, 0, WRAP, 1f)
        val v = tx("", 12f, Pal.TEXT, true)
        r.add(v, WRAP)
        return r to v
    }

    private fun setStat(v: TextView, ok: Boolean, s: String) {
        v.text = "● $s"
        v.setTextColor(if (ok) Pal.GREEN else Pal.WARN)
    }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }

        // ----- bar atas -----
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = chamferOutline(dp(10).toFloat(), true)
            clipToOutline = true
        }
        top.add(logo, dp(48), dp(48))
        val wm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wm.add(tx("GZI TOOLS", 22f, Pal.TEXT, true).apply { letterSpacing = 0.18f })
        wm.add(tx("BOOST  //  by @hazi  //  v1.1.0", 9f, Pal.GREEN, true).apply { letterSpacing = 0.2f }, t = 2)
        top.add(wm, 0, WRAP, 1f, 12)
        top.add(btn("♪ @inihazi", false) { openTikTok() }.apply {
            textSize = 11f; setPadding(dp(12), dp(7), dp(12), dp(7))
        }, WRAP)
        root.add(top)

        // ----- kartu status -----
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ChamferBg(dp(20).toFloat(), dp(1).toFloat(), Color.argb(235, 8, 24, 16), Pal.GREEN, true, true)
            setPadding(dp(24), dp(22), dp(24), dp(22))
        }
        hero.add(tx("SYSTEM STATUS", 10f, Pal.GREEN, true).apply { letterSpacing = 0.3f })
        heroTitle = tx("", 26f, Pal.TEXT, true); hero.add(heroTitle, t = 4)
        heroSub = tx("", 12f, Pal.MUTED); hero.add(heroSub, t = 2)
        hero.add(View(this).apply { setBackgroundColor(Pal.LINE) }, MATCH, 1, 0f, 0, 14, 0, 8)
        val (r1, v1) = statusRow("SHIZUKU"); vShizuku = v1; hero.add(r1, t = 6)
        val (r2, v2) = statusRow("IZIN SISTEM"); vPerm = v2; hero.add(r2, t = 6)
        val (r3, v3) = statusRow("GRAFIK"); vGfx = v3; hero.add(r3, t = 6)
        heroBtn = btn("▶  GAS MAIN") { heroAction() }
        hero.add(heroBtn, MATCH, WRAP, 0f, 0, 18)
        root.add(hero, t = 22)

        // ----- perpustakaan -----
        val lib = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lib.add(View(this).apply { setBackgroundColor(Pal.GREEN) }, dp(4), dp(18), 0f, 0, 0, 10)
        lib.add(tx("GAME LIBRARY", 15f, Pal.TEXT, true).apply { letterSpacing = 0.12f }, WRAP)
        count = tx("", 12f, Pal.MUTED, true); lib.add(count, WRAP, WRAP, 0f, 10)
        lib.add(View(this), 0, 1, 1f)
        lib.add(btn("+ TAMBAH", false) { addGame() }.apply {
            textSize = 12f; setPadding(dp(14), dp(8), dp(14), dp(8))
        }, WRAP)
        root.add(lib, t = 28)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.add(list, t = 12)

        root.add(tx("GZI TOOLS  ·  hijau itu cyber", 10f, Pal.MUTED).apply { gravity = Gravity.CENTER }, t = 30)

        val fl = FrameLayout(this)
        fl.addView(GridBg(this), FrameLayout.LayoutParams(MATCH, MATCH))
        fl.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(root) }, FrameLayout.LayoutParams(MATCH, MATCH))
        return fl
    }

    private fun render() {
        val alive = Sz.alive()
        val shz = alive && Sz.granted()
        val perm = Sz.perms(this)
        val ready = shz && perm
        heroTitle.text = if (ready) "SIAP MAIN" else "BUTUH AKTIVASI"
        heroTitle.setTextColor(if (ready) Pal.GREEN else Pal.WARN)
        heroSub.text = if (ready) "Semua izin aktif. Pilih game lalu tekan Launch." else "Selesaikan izin sistem dan Shizuku dulu."
        heroBtn.text = if (ready) "▶  GAS MAIN" else "AKTIVASI SEKARANG"
        setStat(vShizuku, shz, if (shz) "AKTIF" else if (alive) "BUTUH IZIN" else "MATI")
        setStat(vPerm, perm, if (perm) "OK" else "BELUM")
        setStat(vGfx, Engine.supported, if (Engine.supported) "SIAP" else "BUTUH ANDROID 15+")

        val games = store.games
        count.text = "%02d / 10".format(games.size)
        list.removeAllViews()
        if (games.isEmpty()) {
            val e = card()
            e.add(tx("Belum ada game", 15f, Pal.TEXT, true))
            e.add(tx("Tekan \"+ TAMBAH\" lalu pilih Free Fire.", 12f, Pal.MUTED), t = 4)
            list.add(e, t = 4)
        }
        for (pkg in games) list.add(gameCard(pkg), t = 14)
    }

    private fun gameCard(pkg: String): View {
        val pm = packageManager
        val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val icon = try { drawableToBitmap(pm.getApplicationIcon(pkg)) } catch (e: Exception) { null }
        val cut = dp(20).toFloat()

        val f = FrameLayout(this).apply {
            outlineProvider = chamferOutline(cut, true)
            clipToOutline = true
            setBackgroundColor(Pal.CARD)
            setOnLongClickListener { confirmRemove(pkg, name); true }
        }
        f.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (icon != null) setImageBitmap(icon)
            alpha = 0.7f
            if (Build.VERSION.SDK_INT >= 31) setRenderEffect(RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        f.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.argb(240, 3, 8, 6), Color.argb(150, 3, 8, 6), Color.argb(20, 3, 8, 6))
            )
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        f.addView(Stripes(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)) }
        val tag = if (pkg.startsWith("com.dts.freefire")) "BATTLE ROYALE" else "GAME"
        col.add(tx("▌ $tag", 10f, Pal.GREEN, true).apply { letterSpacing = 0.25f })
        col.add(tx(name, 24f, Pal.TEXT, true), t = 6)
        col.add(tx(pkg, 10f, Pal.MUTED), t = 2)
        col.add(View(this), 0, dp(30))
        col.add(btn("▶  LAUNCH") { openSpace(pkg) }, WRAP)
        f.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        if (icon != null) {
            f.addView(ImageView(this).apply {
                setImageBitmap(icon)
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = ChamferBg(dp(12).toFloat(), dp(2).toFloat(), Pal.CARD, Pal.GREEN, false, true)
                outlineProvider = chamferOutline(dp(12).toFloat(), true)
                clipToOutline = true
            }, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(18), dp(18), 0) })
        }
        f.addView(View(this).apply {
            background = ChamferBg(cut, dp(2).toFloat(), 0, Pal.GREEN_D, false, true)
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        return f
    }

    private fun heroAction() {
        if (!Sz.ready(this)) { startActivity(Intent(this, OnboardActivity::class.java)); return }
        openFirst()
    }

    private fun openTikTok() {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/@inihazi"))) }
        catch (e: Exception) { toast("Tidak bisa membuka TikTok") }
    }

    private fun openSpace(pkg: String) {
        if (!Sz.ready(this)) { startActivity(Intent(this, OnboardActivity::class.java)); return }
        startActivity(Intent(this, GameSpaceActivity::class.java).putExtra("pkg", pkg))
    }

    private fun openFirst() {
        val g = store.games
        if (g.isEmpty()) toast("Tambah game dulu") else openSpace(g.first())
    }

    private fun addGame() {
        if (!Sz.ready(this)) { startActivity(Intent(this, OnboardActivity::class.java)); return }
        if (store.games.size >= 10) { toast("Maksimal 10 game"); return }
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName && it.first !in store.games }
            .sortedWith(
                compareByDescending<Pair<String, String>> { it.first.startsWith("com.dts.freefire") }
                    .thenBy { it.second.lowercase() }
            )
        if (apps.isEmpty()) { toast("Tidak ada aplikasi"); return }
        val names = apps.map { (if (it.first.startsWith("com.dts.freefire")) "★ " else "") + it.second }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pilih game")
            .setItems(names) { _, w ->
                store.games = store.games + apps[w].first
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmRemove(pkg: String, name: String) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Hapus $name dari perpustakaan?")
            .setPositiveButton("Hapus") { _, _ -> store.games = store.games - pkg; render() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
