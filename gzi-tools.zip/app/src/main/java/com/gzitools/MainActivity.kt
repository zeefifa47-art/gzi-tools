package com.gzitools

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Shader
import android.graphics.RenderEffect
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private lateinit var stShizuku: TextView
    private lateinit var stGfx: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        setContentView(build())
        if (!Sz.ready(this)) startActivity(Intent(this, OnboardActivity::class.java))
    }

    override fun onResume() { super.onResume(); render() }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }

        // header
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = shape(Pal.CARD, dp(44).toFloat(), Pal.GREEN, dp(2))
            clipToOutline = true
        }
        head.add(logo, dp(88), dp(88))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(tx("GRAPHICS BOOST", 11f, Pal.GREEN, true).apply { letterSpacing = 0.25f })
        col.add(tx("GZI TOOLS", 32f, Pal.TEXT, true).apply { letterSpacing = 0.12f }, t = 2)
        col.add(tx("v1.0.0", 12f, Pal.MUTED), t = 2)
        head.add(col, WRAP, WRAP, 0f, 16)
        root.add(head)

        // masuk game space
        val entry = card().apply { setOnClickListener { openFirst() } }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tcol.add(tx("Masuk ke", 12f, Pal.MUTED))
        tcol.add(tx("Game Space", 22f, Pal.TEXT, true))
        row.add(tcol, 0, WRAP, 1f)
        row.add(tx("→", 22f, Pal.ON_GREEN, true).apply {
            gravity = Gravity.CENTER
            background = shape(Pal.GREEN, dp(24).toFloat())
        }, dp(48), dp(48))
        entry.add(row)
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        stShizuku = tx("", 12f, Pal.MUTED, true)
        stGfx = tx("", 12f, Pal.MUTED, true)
        st.add(stShizuku, WRAP, WRAP, 0f, 0, 0, 18)
        st.add(stGfx)
        entry.add(st, t = 14)
        root.add(entry, t = 22)
        root.add(btn("♪  TikTok  @inihazi", false) { openTikTok() }, t = 12)

        // perpustakaan
        val lib = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lib.add(tx("Perpustakaan Game", 17f, Pal.TEXT, true), WRAP)
        count = tx("", 12f, Pal.MUTED); lib.add(count, WRAP, WRAP, 0f, 8)
        lib.add(View(this), 0, 1, 1f)
        lib.add(btn("Tambah +", false) { addGame() }.apply { textSize = 13f; setPadding(dp(16), dp(8), dp(16), dp(8)) }, WRAP)
        root.add(lib, t = 26)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.add(list, t = 12)

        root.add(tx("Sumber: TikTok @inihazi", 11f, Pal.MUTED).apply { gravity = Gravity.CENTER }, t = 30)

        return ScrollView(this).apply { setBackgroundColor(Pal.BG); addView(root) }
    }

    private fun render() {
        val ok = Sz.ready(this)
        val alive = Sz.alive()
        stShizuku.text = if (ok) "● Shizuku aktif" else if (alive) "● Shizuku butuh izin" else "● Shizuku mati"
        stShizuku.setTextColor(if (ok) Pal.GREEN else Pal.WARN)
        stGfx.text = if (Engine.supported) "● Grafik: siap" else "● Grafik: butuh Android 15+"
        stGfx.setTextColor(if (Engine.supported) Pal.GREEN else Pal.WARN)

        val games = store.games
        count.text = "${games.size} / 10"
        list.removeAllViews()
        if (games.isEmpty()) {
            list.add(tx("Belum ada game. Tekan \"Tambah +\" lalu pilih Free Fire.", 13f, Pal.MUTED), t = 8)
        }
        for (pkg in games) list.add(gameCard(pkg), t = 12)
    }

    private fun gameCard(pkg: String): View {
        val pm = packageManager
        val name = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        val icon = try { drawableToBitmap(pm.getApplicationIcon(pkg)) } catch (e: Exception) { null }

        val f = FrameLayout(this).apply {
            background = shape(Pal.CARD, dp(22).toFloat(), Pal.LINE, dp(1))
            clipToOutline = true
            setOnLongClickListener { confirmRemove(pkg, name); true }
        }
        val banner = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (icon != null) setImageBitmap(icon)
            alpha = 0.55f
            if (Build.VERSION.SDK_INT >= 31) setRenderEffect(RenderEffect.createBlurEffect(45f, 45f, Shader.TileMode.CLAMP))
        }
        f.addView(banner, FrameLayout.LayoutParams(MATCH, MATCH))
        f.addView(View(this).apply { setBackgroundColor(Color.argb(90, 4, 10, 7)) }, FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        col.add(tx("GAME", 10f, Pal.GREEN, true).apply { letterSpacing = 0.25f })
        col.add(tx(name, 22f, Pal.TEXT, true), t = 4)
        col.add(tx(pkg, 10f, Pal.MUTED), t = 2)
        col.add(View(this), 0, dp(26))
        col.add(btn("▶  Main") { openSpace(pkg) }, WRAP)
        f.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        if (icon != null) {
            f.addView(ImageView(this).apply {
                setImageBitmap(icon)
                background = shape(Pal.CARD, dp(18).toFloat(), Pal.GREEN, dp(2))
                clipToOutline = true
            }, FrameLayout.LayoutParams(dp(78), dp(78), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(18), dp(18), 0) })
        }
        return f
    }

    private fun openTikTok() {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/@inihazi"))) }
        catch (e: Exception) { toast("Tidak bisa membuka TikTok") }
    }

    private fun openSpace(pkg: String) {
        if (!Sz.ready(this)) { startActivity(Intent(this, OnboardActivity::class.java)); return }
        startActivity(Intent(this, GameSpaceActivity::class.java).putExtra("pkg", pkg))
    }

    private fun openFirst() {
        val g = store.games
        if (g.isEmpty()) toast("Tambah game dulu") else openSpace(g.first())
    }

    private fun addGame() {
        if (!Sz.ready(this)) { startActivity(Intent(this, OnboardActivity::class.java)); return }
        if (store.games.size >= 10) { toast("Maksimal 10 game"); return }
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName && it.first !in store.games }
            .sortedWith(
                compareByDescending<Pair<String, String>> { it.first.startsWith("com.dts.freefire") }
                    .thenBy { it.second.lowercase() }
            )
        if (apps.isEmpty()) { toast("Tidak ada aplikasi"); return }
        val names = apps.map { (if (it.first.startsWith("com.dts.freefire")) "★ " else "") + it.second }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pilih game")
            .setItems(names) { _, w ->
                store.games = store.games + apps[w].first
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmRemove(pkg: String, name: String) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Hapus $name dari perpustakaan?")
            .setPositiveButton("Hapus") { _, _ -> store.games = store.games - pkg; render() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
