package com.gzitools

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

/** Langkah 1: izin ubah pengaturan sistem. Langkah 2: aktivasi Shizuku. */
class OnboardActivity : Activity() {
    private lateinit var st1: TextView
    private lateinit var st2: TextView
    private lateinit var b1: TextView
    private lateinit var b2: TextView
    private lateinit var go: TextView
    private var act1: () -> Unit = {}
    private var act2: () -> Unit = {}

    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderL = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadL = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        root.add(tx("AKTIVASI", 11f, Pal.GREEN, true))
        root.add(tx("GZI TOOLS", 30f, Pal.TEXT, true), t = 4)
        root.add(tx("Selesaikan 2 langkah ini agar game bisa ditambahkan.", 13f, Pal.MUTED), t = 6, b = 20)

        val c1 = card()
        c1.add(tx("1  Izin ubah pengaturan sistem", 16f, Pal.TEXT, true))
        c1.add(tx("Wajib: \"Ubah pengaturan sistem\" dan \"Tampil di atas aplikasi lain\" (Xiaomi: aktifkan keduanya lalu kembali).", 12f, Pal.MUTED), t = 6)
        st1 = tx("", 13f, Pal.WARN, true); c1.add(st1, t = 10)
        b1 = btn("Beri Izin") { act1() }; c1.add(b1, t = 12)
        root.add(c1)

        val c2 = card()
        c2.add(tx("2  Aktivasi Shizuku", 16f, Pal.TEXT, true))
        c2.add(tx("Shizuku memberi akses shell untuk menerapkan tekstur. Buka Shizuku lalu Start (ADB nirkabel), kemudian beri izin untuk GZI TOOLS.", 12f, Pal.MUTED), t = 6)
        st2 = tx("", 13f, Pal.WARN, true); c2.add(st2, t = 10)
        b2 = btn("Buka Shizuku") { act2() }; c2.add(b2, t = 12)
        root.add(c2, t = 14)

        go = btn("LANJUTKAN") { finish() }
        root.add(go, t = 22)
        root.add(tx("Sumber: TikTok @inihazi", 11f, Pal.MUTED).apply { gravity = Gravity.CENTER }, t = 18)

        setContentView(ScrollView(this).apply { setBackgroundColor(Pal.BG); addView(root) })

        Shizuku.addRequestPermissionResultListener(permL)
        Shizuku.addBinderReceivedListener(binderL)
        Shizuku.addBinderDeadListener(deadL)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permL)
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeBinderDeadListener(deadL)
        super.onDestroy()
    }

    private fun refresh() {
        val canWrite = Sz.perms(this)
        if (canWrite) {
            st1.text = "Selesai"; st1.setTextColor(Pal.GREEN); b1.visibility = View.GONE
        } else {
            st1.text = if (!Settings.System.canWrite(this)) "Belum diizinkan: ubah pengaturan sistem" else "Belum diizinkan: tampil di atas aplikasi lain"; st1.setTextColor(Pal.WARN); b1.visibility = View.VISIBLE
            act1 = {
                val a = if (!Settings.System.canWrite(this)) Settings.ACTION_MANAGE_WRITE_SETTINGS
                else Settings.ACTION_MANAGE_OVERLAY_PERMISSION
                startActivity(Intent(a, Uri.parse("package:$packageName")))
            }
        }

        val installed = Sz.installed(this)
        val alive = Sz.alive()
        val granted = alive && Sz.granted()
        b2.visibility = View.VISIBLE
        when {
            granted -> {
                st2.text = "Selesai - Shizuku aktif"; st2.setTextColor(Pal.GREEN); b2.visibility = View.GONE
            }
            !installed -> {
                st2.text = "Shizuku belum terpasang"; st2.setTextColor(Pal.WARN); b2.text = "Unduh Shizuku"
                act2 = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) }
            }
            !alive -> {
                st2.text = "Shizuku belum dijalankan (Start dulu di app Shizuku)"; st2.setTextColor(Pal.WARN); b2.text = "Buka Shizuku"
                act2 = {
                    val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    if (i != null) startActivity(i) else toast("Tidak bisa membuka Shizuku")
                }
            }
            else -> {
                st2.text = "Shizuku jalan, belum diberi izin"; st2.setTextColor(Pal.WARN); b2.text = "Beri Izin Shizuku"
                act2 = {
                    try { Shizuku.requestPermission(100) } catch (e: Throwable) { toast("Gagal: ${e.message}") }
                }
            }
        }

        val ok = canWrite && granted
        go.alpha = if (ok) 1f else 0.35f
        go.isEnabled = ok
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
