plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gzitools"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gzitools"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.0.0"
    }

    signingConfigs {
        create("release") {
            storeFile = file("keystore/gzi-release.jks")
            storePassword = "Gzi2026Hazi!Lock"
            keyAlias = "gzirelease"
            keyPassword = "Gzi2026Hazi!Lock"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // ditandatangani dengan kunci rilis khusus GZI TOOLS (bukan debug key lagi)
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
