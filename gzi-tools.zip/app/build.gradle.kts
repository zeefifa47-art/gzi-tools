plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gzitools"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gzitools"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.0.0"
    }

    signingConfigs {
        create("release") {
            storeFile = file("keystore/gzi-release.jks")
            storePassword = "Gzi2026Hazi!Lock"
            keyAlias = "gzirelease"
            keyPassword = "Gzi2026Hazi!Lock"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // ditandatangani dengan kunci rilis khusus GZI TOOLS (bukan debug key lagi)
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-database")
}

// Plugin google-services BUTUH app/google-services.json (didapat dari console Firebase punyamu,
// project > Android app dengan package com.gzitools > download google-services.json > taruh
// persis di folder app/ ini). Baru di-apply KALAU file-nya ada, biar proyek tetap bisa di-build
// normal (badge "Pengguna Online" aja yang gak nongol) selama file ini belum ditaruh.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}
