# GZI TOOLS v2.0 (com.gzitools)
Boost game by @hazi (tema cyber hijau). TikTok @inihazi

## Build (GitHub Actions)
1. Upload `gzi-tools.zip` ke repo (branch `main`).
2. Tab **Actions** -> *Build GZI TOOLS* -> tunggu hijau -> unduh artifact `gzi-tools.apk`.

## Tempat file kamu
- Video intro  : `app/src/main/res/raw/intro.mp4`  (huruf kecil semua)
- Crosshair    : `app/src/main/assets/crosshair/crosshair1.png`, `crosshair2.png`, ... (nomor lanjut)
- QR donasi    : `app/src/main/assets/qris.jpg` (atau `qris.png`)

## Fitur
- Pixel Lab (Android 15+), Grafik Burik (Android 11+)
- Panel game: FPS, CPU, Audio, Kecerahan, Crosshair, Sensi X/Y, Refresh Rate
- Halaman Donasi (geser atau tombol di bawah)
