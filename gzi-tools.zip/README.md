# GZI TOOLS (com.gzitools)
Pixel Lab by @hazi (tema cyber hijau). Sumber ide: TikTok @inihazi

## Build (GitHub Actions)
1. Upload isi zip ini ke repo GitHub (branch `main`).
2. Tab **Actions** -> *Build GZI TOOLS* -> tunggu hijau.
3. Unduh artifact **gzi-tools** -> `gzi-tools.apk`.

## Cara pakai
1. Buka app -> beri izin "Ubah pengaturan sistem".
2. Install & jalankan **Shizuku** (Start via ADB nirkabel) -> beri izin untuk GZI TOOLS.
3. Home -> **Tambah +** -> pilih Free Fire -> **Main** -> **Tekstur Ringan**.
4. Pilih level / preset -> **Simpan** -> tekan **MAIN** (game dibuka ulang otomatis).
5. Saat bermain, geser dari tepi kiri layar untuk membuka Panel Game.

Grafik tekstur butuh Android 15+.
