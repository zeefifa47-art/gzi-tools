plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    // Dipakai buat baca google-services.json (badge "Pengguna Online" lewat Firebase).
    // apply false di sini, baru beneran di-apply di app/build.gradle.kts KALAU file-nya ada
    // (lihat komentar di sana) — biar build gak collapse total kalau file itu belum/kehapus.
    id("com.google.gms.google-services") version "4.4.2" apply false
}
